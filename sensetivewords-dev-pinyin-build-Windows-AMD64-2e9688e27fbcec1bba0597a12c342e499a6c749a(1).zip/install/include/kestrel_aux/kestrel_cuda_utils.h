#ifndef KESTREL_AUX_KESTREL_CUDA_UTILS_H
#define KESTREL_AUX_KESTREL_CUDA_UTILS_H

#if KESTREL_CUDA

#include <stdio.h>
#include <kestrel.h>
#include <cuda_runtime_api.h>

#define MAX_THREAD_IN_BLOCK (512)
#define THREAD_IN_BLOCK_X (32)
#define THREAD_IN_BLOCK_Y (MAX_THREAD_IN_BLOCK / THREAD_IN_BLOCK_X)

#define KESTREL_KERNEL_LOOP(i, n)                                                                \
        for (int32_t i = blockIdx.x * blockDim.x + threadIdx.x; (i) < (n);                       \
             (i) += blockDim.x * gridDim.x)

#define KESTREL_KERNEL_CFG(total)                                                                \
        (((total) + MAX_THREAD_IN_BLOCK - 1) / MAX_THREAD_IN_BLOCK), MAX_THREAD_IN_BLOCK

#define KESTREL_KERNEL_LOOP2D(xpos, ypos, cols, rows)                                            \
        int32_t xx = blockIdx.x * blockDim.x + threadIdx.x;                                      \
        int32_t yy = blockIdx.y * blockDim.y + threadIdx.y;                                      \
        for (int32_t ypos = yy; (ypos) < (rows); (ypos) += blockDim.y * gridDim.y)               \
                for (int32_t xpos = xx; (xpos) < (cols); (xpos) += blockDim.x * gridDim.x)

#define KESTREL_KERNEL_CFG2D(cols, rows)                                                         \
        dim3(((cols) + THREAD_IN_BLOCK_X - 1) / THREAD_IN_BLOCK_X,                               \
             ((rows) + THREAD_IN_BLOCK_Y - 1) / THREAD_IN_BLOCK_Y, 1),                           \
            dim3(THREAD_IN_BLOCK_X, THREAD_IN_BLOCK_Y)

// This will output the proper CUDA error strings in the event that a CUDA host call returns an
// error
#define KESTREL_CHECK(val)                                                                       \
        do {                                                                                     \
                cudaError_t err = (val);                                                         \
                if (err != cudaSuccess) {                                                        \
                        kestrel_log(KESTREL_ERROR, "CUDA error %d, %s.\n", err,                  \
                                    cudaGetErrorString(err));                                    \
                        exit(EXIT_FAILURE);                                                      \
                }                                                                                \
        } while (0)

#endif

#endif