#ifndef KESTREL_AUX_KESTREL_FRAME_UTILS_H
#define KESTREL_AUX_KESTREL_FRAME_UTILS_H

#include <kestrel.h>
#include "kestrel_aux/kestrel_frame_utils_struct.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @ingroup kestrel_aux
/// @defgroup kestrel_frame_utils Frame Utilities
/// @{

/// @brief Load frame from image file
/// @param[in] filename File name for load.
/// @return Frame pointer for succeed, otherwise NULL.
/// @note This API is just for debuging & testing.
/// @note Transparency channel will be removed.
/// @note Support JP[E]G/BMP/PNG.
KESTREL_API
kestrel_frame_t *kestrel_frame_load(const char *filename);

/// @brief Load frame from coded image data on memory
/// @param[in] buf Coded image memory buffer.
/// @param[in] len Length of buffer.
/// @return Frame pointer for succeed, otherwise NULL.
/// @note This API is just for debuging & testing.
/// @note Transparency channel will be removed.
/// @note Support JP[E]G/BMP/PNG.
KESTREL_API
kestrel_frame_t *kestrel_frame_load_from_memory(uint8_t *buf, int32_t len);

/// @brief Save frame
/// @param[in] in Frame which is going to be saved.
/// @param[in] filename File name for save out.
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note This API is just for debuging & testing.
/// @note YUV Frame will be converted into RGB Frame.
/// @note Support JP[E]G/BMP/PNG.
KESTREL_API
k_err kestrel_frame_save(const kestrel_frame_t *in, const char *filename);

/// @brief Encode a frame
/// @param[in] in Frame to be encoded.
/// @param[in] enc Encode format.
/// @param[in,out] buffer Output buffer resized to fit the compressed image.
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note buffer must be a kestrel_buffer(HOST) instance, not NULL.
/// @note YUV Frame will be converted into RGB Frame.
/// @note Support encode JP[E]G/BMP/PNG.
KESTREL_API
k_err kestrel_frame_encode(const kestrel_frame_t *in, kestrel_frame_enc_format_e enc,
                           kestrel_buffer buffer);
/**
 * @brief Crop frame ROI to output frame
 * @param[in] in Input frame going to crop
 * @param[out] out Target frame, If `*out` is NULL, a new frame will be return, else
 * `*out` should has enough capacity for output frame, `*out` must release by kestrel_frame_free()
 * @param[in] area Area of ROI, if area is out of frame, fill the outer with black pixels
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support RGB/BGR/NV12/NV21/YU12/GRAY
 */
KESTREL_API
k_err kestrel_frame_crop(const kestrel_frame_t *in, kestrel_frame_t **out, kestrel_area2d_t area);

/**
 * @brief batch crop frame ROI to output frame
 * @param[in] in Input frames going to crop, an array of (kestrel_frame_t*), must have the same
 * size/fmt/...
 * @param[in] batch batch number
 * @param[out] out Target frames, an array of (kestrel_frame_t*). Array size = batch number.
 * Either allocate all output frames or set all array element to null, in which case this api will
 * allocate all the output frames, user need to free them
 * @param[in] area pinter to array of kestrel_area2d_t, array size = batch number
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note currently only support cambricon
 */
KESTREL_API
k_err kestrel_frame_crop_batch(const kestrel_frame_t *const *in, size_t batch,
                               kestrel_frame_t **out, const kestrel_area2d_t *area);

/**
 * @brief Resize frame according to `size`
 * @param[in] in Input frame going to resize
 * @param[out] out Target frame, If `*out` is NULL, a new frame will be return, else
 * `*out` should has enough capacity for output frame, `*out` must release by kestrel_frame_free()
 * @param[in] size Destination size(width, height)
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support RGB/BGR/NV12/NV21/YU12/GRAY
 */
KESTREL_API
k_err kestrel_frame_resize(const kestrel_frame_t *in, kestrel_frame_t **out,
                           kestrel_size2d_t size);

/**
 * @brief Scale frame according to `scale`
 * @param[in] in Input frame going to scale
 * @param[out] out Target frame, If `*out` is NULL, a new frame will be return, else
 * `*out` should has enough capacity for output frame, `*out` must release by kestrel_frame_free()
 * @param[in] scale Scale ratio in float
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support RGB/BGR/NV12/NV21/YU12/GRAY
 */
KESTREL_API
k_err kestrel_frame_scale(const kestrel_frame_t *in, kestrel_frame_t **out, float scale);

/**
 * @brief Rotate frame according given kestrel_orientation_e
 * @param[in] in Input frame going to rotate
 * @param[out] out Target frame, If `*out` is NULL, a new frame will be return, else
 * `*out` should has enough capacity for output frame, `*out` must release by kestrel_frame_free()
 * @param[in] type Ratate orientation
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support RGB/BGR/NV12/NV21/YU12/GRAY
 */
KESTREL_API
k_err kestrel_frame_rotate(const kestrel_frame_t *in, kestrel_frame_t **out,
                           kestrel_orientation_e type);

/**
 * @brief Color space convert according given kestrel_video_format_e
 *
 * @param[in] in Input frame going to convert
 * @param[out] out Target frame, If `*out` is NULL, a new frame will be return, else
 * `*out` should has the same size as input frame, `*out` must release by kestrel_frame_free()
 * @param[in] type Color space convert type
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support RGB/BGR/NV12/NV21/YU12/GRAY
 */
KESTREL_API
k_err kestrel_frame_cvt_color(const kestrel_frame_t *in, kestrel_frame_t **out,
                              kestrel_video_format_e type);

/**
 * @brief Get similarity transform matrix
 * @param[in] src Source points
 * @param[in] dst Destination points
 * @param[out] mat Output similarity transform matrix
 * @param[out] inverse_mat Output inverse similarity transform matrix
 */
KESTREL_API
void kestrel_find_similarity_transform(const kestrel_point2df_t src[3],
                                       const kestrel_point2df_t dst[3], float mat[3][3],
                                       float inverse_mat[3][3]);

/**
 * @brief Get warp affine transform matrix
 * @param[in] src Source points
 * @param[in] dst Destination points
 * @param[out] mat Output warp affine transform matrix
 * @param[out] inverse_mat Output inverse warp affine transform matrix
 */
KESTREL_API
void kestrel_find_affine_transform(const kestrel_point2df_t src[3],
                                   const kestrel_point2df_t dst[3], float mat[3][3],
                                   float inverse_mat[3][3]);
/**
 * @brief Get rigid transform matrix
 * @param[in] src Source points
 * @param[in] dst Destination points
 * @param[in] num Points num
 * @param[out] mat Output rigid transform matrix
 */
KESTREL_API
void kestrel_find_rigid_transform(const kestrel_point2df_t src[], const kestrel_point2df_t dst[],
                                  int32_t num, float mat[3][3]);
/**
 * @brief Applies an affine transformation to an image.
 * @param[in] in Input frame going to transform
 * @param[out] out pointer to target kestrel_frame, created by user, make sure `*out` has
 * enough capacity for output frame
 * @param[in] mat \f$2 \times 3\f$ transformation matrix
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support RGB/BGR/NV12/NV21/YU12/GRAY
 */
KESTREL_API
k_err kestrel_frame_warpaffine_with_border(const kestrel_frame_t *in, kestrel_frame_t *out,
                                           float mat[2][3], uint8_t border_value);
KESTREL_API
k_err kestrel_frame_warpaffine(const kestrel_frame_t *in, kestrel_frame_t *out, float mat[2][3]);

/**
 * @brief Applies an perspective transformation to an image.
 * @param[in] in Input frame going to transform
 * @param[out] out pointer to target kestrel_frame, created by user, make sure `*out` has enough
 * capacity for output frame
 * @param[in] mat \f$3 \times 3\f$ transformation matrix
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support RGB/BGR/NV12/NV21/YU12/GRAY
 */
KESTREL_API
k_err kestrel_frame_warpperspective_with_border(const kestrel_frame_t *in, kestrel_frame_t *out,
                                                float mat[3][3], uint8_t border_value);
KESTREL_API
k_err kestrel_frame_warpperspective(const kestrel_frame_t *in, kestrel_frame_t *out,
                                    float mat[3][3]);

/**
 * @brief Equalizes the histogram of a grayscale image.
 * @param[in] src Input frame going to equalize hist
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be return, else
 * `*dst` should has enough capacity for output frame, `*dst` must release by kestrel_frame_free()
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support GRAY
 */
KESTREL_API
k_err kestrel_frame_equalize_hist(const kestrel_frame_t *src, kestrel_frame_t **dst);

/**
 * @brief Perform gamma correction on an image.
 * @param[in] src Input frame going to perform gamma correction
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be return, else
 * `*dst` should has enough capacity for output frame, `*dst` must release by kestrel_frame_free()
 * @param[in] gamma Non negative real number, gamma larger than 1 make the shadows darker, while
 * gamma smaller than 1 make dark regions lighter.
 * @param[in] gain The constant multiplier.
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Support GRAY
 */
KESTREL_API
k_err kestrel_frame_adjust_gamma(const kestrel_frame_t *src, kestrel_frame_t **dst, float gamma,
                                 float gain);

/**
 * @brief Adjust brightness
 * @param[in] src Input frame
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be return, else
 * `*dst` should has enough capacity for output frame, `*dst` must release by kestrel_frame_free()
 * @param[in] factor How much to adjust the brightness. Can be any non negative number.
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports BGR/RGB
 */
KESTREL_API
k_err kestrel_frame_adjust_brightness(const kestrel_frame_t *src, kestrel_frame_t **dst,
                                      float factor);

/**
 * @brief Adjust contrast
 * @param[in] src Input frame
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be return, else
 * `*dst` should has enough capacity for output frame, `*dst` must release by kestrel_frame_free()
 * @param[in] factor How much to adjust the contrast. Can be any non negative number.
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports BGR/RGB
 */
KESTREL_API
k_err kestrel_frame_adjust_contrast(const kestrel_frame_t *src, kestrel_frame_t **dst,
                                    float factor);

/**
 * @brief Adjust hue
 * @param[in] src Input frame
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be return, else
 * `*dst` should has enough capacity for output frame, `*dst` must release by kestrel_frame_free()
 * @param[in] factor How much to adjust hue. Must be in the intervel [-0.5, 0.5].
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports BGR/RGB
 */
KESTREL_API
k_err kestrel_frame_adjust_hue(const kestrel_frame_t *src, kestrel_frame_t **dst, float factor);

/**
 * @brief Adjust saturation
 * @param[in] src Input frame
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be return, else
 * `*dst` should has enough capacity for output frame, `*dst` must release by kestrel_frame_free()
 * @param[in] factor How much to adjust the saturation. Can be any non negative number.
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports BGR/RGB
 */
KESTREL_API
k_err kestrel_frame_adjust_saturation(const kestrel_frame_t *src, kestrel_frame_t **dst,
                                      float factor);

/**
 * @brief Flip an image.
 * @param[in] src Input frame
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be return, else
 * `*dst` should has enough capacity for output frame, `*dst` must release by kestrel_frame_free()
 * @param[in] flip_code, 0: flip around x-axis; positive value: flip around y-axis; negative
 * value: flip around both axes
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports GRAY/BGR/RGB/BGRA/ARGB
 */
KESTREL_API
k_err kestrel_frame_flip(const kestrel_frame_t *src, kestrel_frame_t **dst, int flip_code);

/**
 * @brief Pad an image.
 * @param[in] src Input frame
 * @param[out] dst Target frame, created by user, `*dst` should have enough capacity for output
 * frame
 * @param[in] border_type supports KESTREL_BORDER_CONSTANT/REPLICATE/REFLECT/REFLECT101
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports GRAY/BGR/RGB/BGRA/ARGB
 */
KESTREL_API
k_err kestrel_frame_pad(const kestrel_frame_t *src, kestrel_frame_t *dst,
                        kestrel_border_type_e border_type, uint8_t border_value);

/**
 * @brief Dilates an frame by using a specific structuring element
 * @param[in] src input frame
 * @param[in] kernel_size size of structuring element
 * @param[in] kernel_data data of structuring element, in row major order
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be returned, else
 * `*dst` should has enough capacity for output frame, `*dst` must be release by
 * kestrel_frame_free()
 * @param[in] border_type only support KESTREL_BORDER_CONSTANT
 * @param[in] border_value border value
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports GRAY/BGR/RGB/BGRA/ARGB
 */
KESTREL_API
k_err kestrel_frame_dilate(const kestrel_frame_t *src, kestrel_size2d_t kernel_size,
                           uint8_t *kernel_data, kestrel_frame_t **dst,
                           kestrel_border_type_e border_type, uint8_t border_value);

/**
 * @brief Dilates an frame by using a specific structuring element
 * @param[in] src input frame
 * @param[in] kernel_size size of structuring element
 * @param[in] kernel_data data of structuring element, in row major order
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be returned, else
 * `*dst` should has enough capacity for output frame, `*dst` must be release by
 * kestrel_frame_free()
 * @param[in] border_type only support KESTREL_BORDER_CONSTANT
 * @param[in] border_value border value
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports GRAY/BGR/RGB/BGRA/ARGB
 */
KESTREL_API
k_err kestrel_frame_erode(const kestrel_frame_t *src, kestrel_size2d_t kernel_size,
                          uint8_t *kernel_data, kestrel_frame_t **dst,
                          kestrel_border_type_e border_type, uint8_t border_value);

/**
 * @brief Calculates the weighted sum of two frames
 * @param[in] src1 first input frame
 * @param[in] alpha weight of first frame
 * @param[in] src2 second input frame
 * @param[in] beta weight of second frame
 * @param[in] gamma scalar added to each sum
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be returned, else
 * `*dst` should has enough capacity for output frame, `*dst` must be release by
 * kestrel_frame_free()
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports GRAY/BGR/RGB/BGRA/ARGB
 */
KESTREL_API
k_err kestrel_frame_add_weighted(const kestrel_frame_t *src1, float alpha,
                                 const kestrel_frame_t *src2, float beta, float gamma,
                                 kestrel_frame_t **dst);

/**
 * @brief Applies an adaptive threshold to an gray image
 * @param[in] src input frame
 * @param[in] max_value value assigned to the pixels for which the condition is satisfied
 * @param[in] adaptive_method adaptive thresholding algorithm to use:
 *            0: ADAPTIVE_THRESH_MEAN_C, 1: ADAPTIVE_THRESH_GAUSSIAN_C
 * @param[in] threshold_type thresholding type, 0: THRESH_BINARY, 1: THRESH_BINARY_INV
 * @param[in] block_size size of a pixel neighborhood that is used to calculate a threshold value
 * for the pixel, greater than 1 and up to 15.
 * @param[in] delta constant subtracted from the mean or weighted mean.
 * @param[in] border_type ways to deal with border, only KESTREL_BORDER_REPLICATE is supported
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be returned, else
 * `*dst` should has enough capacity for output frame, `*dst` must be release by
 * kestrel_frame_free()
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports GRAY
 */
KESTREL_API
k_err kestrel_frame_adaptive_threshold(const kestrel_frame_t *src, double max_value,
                                       int adaptive_method, int threshold_type, int block_size,
                                       double delta, kestrel_border_type_e border_type,
                                       kestrel_frame_t **dst);

/**
 * @brief Box Filter
 * @param[in] src input frame
 * @param[in] kernel_size size of filter
 * @param[in] normalize 0: don't normalize, non zero: normalize
 * @param[in] border_type ways to deal with border, only supports
 * KESTREL_BORDER_REFLECT/KESTREL_BORDER_REFLECT101
 * @param[out] dst Target frame, If `*dst` is NULL, a new frame will be returned, else
 * `*dst` should has enough capacity for output frame, `*dst` must be release by
 * kestrel_frame_free()
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports GRAY/BGR/RGB/BGRA/ARGB
 */
KESTREL_API
k_err kestrel_frame_box_filter(const kestrel_frame_t *src, kestrel_size2d_t kernel_size,
                               int normalize, kestrel_border_type_e border_type,
                               kestrel_frame_t **dst);

/**
 * @brief Calculates mean and standard deviation
 * @param[in] src input frame
 * @param[out] mean mean value of each channel
 * @param[out] stddev standard deviation value of each channel
 * @param[in] mask_stride stride of mask, 0 if no mask needed
 * @param[in] mask mask data, NULL if no mask needed
 * @param[in] channel_wise none zero: channel wise, 0: uniform
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note Supports GRAY/BGR/RGB/BGRA/ARGB
 */
KESTREL_API
k_err kestrel_frame_mean_stddev(const kestrel_frame_t *src, float *mean, float *stddev,
                                int mask_stride, const uint8_t *mask, int channel_wise);

/**
 * @brief find homography
 * @param[in] num_points the number of src and dst points
 * @param[in] src src keypoints data, each points has 2 float values (x, y)
 * @param[in] dst dst keypoints data, each points has 2 float values (x, y)
 * @param[in] is_affine whether to use affine transform, 0: no, none zero: yes
 * @param[out] mat output transform matrix
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 */
KESTREL_API
k_err kestrel_find_homography(int num_points, const float *src, const float *dst, int is_affine,
                              float mat[3][3]);

/**
 * @brief Finds contours in a binary image.
 * @param[in] src input frame, an 8-bit single-channel image.
 * @param[in] mode Contour retrieval mode.
 * @param[in] method Contour approximation method.
 * @param[in] offset Offset by which every contour point is shifted.
 * @param[out] contours Detected contours.
 * @param[out] hierarchy Optional output array, containing information about the image topology.
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 */
KESTREL_API
k_err kestrel_frame_find_contours(const kestrel_frame_t *src, kestrel_retrieval_mode_e mode,
                                  kestrel_contour_approximation_mode_e method,
                                  kestrel_point2d_t offset, kestrel_array_t **contours,
                                  kestrel_array_t **hierarchy);

/**
 * @deprecate since 1.4.0, instead of kestrel_frame_transform_to_tensor()
 * @brief Transform image to input tensor
 * @param[in,out] t Input tensor
 * @param[in] offset The offset of tensor, each image should be transformed to different position
 * @param[in] tensor_color Input tensor type: bgr/rgb/gray
 * @param[in] frame Origin frame
 * @param[in] means Means to substract
 * @param[in] stds Stds to divide
 * @param[in] paddings Default pixel filled in tensor, when frame is smaller than tensor, the
 * outer will be filled with paddings
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note the input tensor has only 3 kinds of type:
 *    GRAY_TENSOR needs RGB/BGR/GRAY frame,
 *    BGR_TENSOR and RGB_TENSOR need RGB/BGR frame
 */
KESTREL_API k_err kestrel_frame_to_tensor(kestrel_tensor_t *t, int32_t offset,
                                          kestrel_tensor_color_e tensor_color,
                                          const kestrel_frame_t *frame, kestrel_pixel_t means,
                                          kestrel_pixel_t stds, kestrel_pixel_t paddings);

/**
 * @deprecate since 1.4.0, instead of kestrel_frame_transform_to_tensor()
 * @brief Crop, resize and transform image to input tensor
 * @param[in,out] tensor Input tensor
 * @param[in] tensor_color Input tensor type: bgr/rgb/gray
 * @param[in] batch Number of frames and rois
 * @param[in] frames Origin frames
 * @param[in] rois Regions of interest in origin frames
 * @param[in] resize_param Type of resize: resize type: KEEP_RATIO/AUTO_RATIO
 * @param[in] means Means to substract
 * @param[in] stds Stds to divide
 * @param[in] paddings Fill the useless part of tensor with paddings, if NULL, fill with
 * (0, 0, 0)
 * @param[in,out] mem_cache Cache pool will dynamic(trigger: memory type or size) allocate in
 * this function. `mem_cache` must be released by kestrel_buffer_free()
 * @param[in,out] scale_height pointer to a `float*` object where the result will be stored, or a
 * null pointer (source_height / target_height)
 * @param[in,out] scale_width pointer to a `float*` object where the result will be stored, or a
 * null pointer (source_height / target_height) (source_width / target_width)
 * target_frame_size, buffer cnt must be larger than batch size for gpu resize: only use memory in
 * frame, buffer_size must be larger than (88 * batch size), buffer cnt must be larger than 1
 * @return k_err return KESTREL_OK for succeed, otherwise error code
 * @note the input tensor has only 3 kinds of type:
 *    GRAY_TENSOR needs RGB/BGR/GRAY frame.
 *    BGR_TENSOR and RGB_TENSOR need RGB/BGR frame
 */
KESTREL_API k_err kestrel_frame_transform_to_tensor_batch(
    kestrel_tensor_t *tensor, kestrel_tensor_color_e tensor_color, size_t batch,
    const kestrel_frame_t *const *frames, const kestrel_area2d_t *rois,
    kestrel_resize_param_e resize_param, kestrel_pixel_t means, kestrel_pixel_t stds,
    const kestrel_pixel_t paddings[], kestrel_buffer *mem_cache, float scale_height[],
    float scale_width[]);

KESTREL_API k_err kestrel_frame_transform_to_tensor(kestrel_frame_transform_param_t *param);

/// @brief Convert tensor to frames
/// @param[in] in t which is the tensor(nchw) of picture.
/// @param[in] tensor_color see `kestrel_tensor_color_e`.
/// @param[in] index frame index in tensor, which is `[0,n)`.
/// @param[out] frame,`*frame` is NULL, a new frame be return, `frame` must be released by
/// kestrel_frame_free()
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note This API is just for debuging & testing.
KESTREL_API
k_err kestrel_tensor_to_frames(kestrel_tensor_t *tensor, kestrel_tensor_color_e tensor_color,
                               size_t index, kestrel_frame_t **frame);

/// @brief Convert tensor to npy file
/// @param[in] tensor which is the tensor(nchw)
/// @param[in] filename, npy format file.
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note This API is just for debuging & testing. npy format. only support dtype `float32, uint8`
/// https://github.com/numpy/numpy/blob/master/numpy/lib/format.py
KESTREL_API
k_err kestrel_tensor_to_npy(kestrel_tensor_t *tensor, const char *filename);

/// @brief Create tensor from npy file
/// @param[in] filename npy format file
/// @param[in] tensor_name for construct `kestrel_tensor_t`
/// @param[in] mem_type expect tensor mem_type.
/// @return kestrel_tensor_t ptr for succeed, otherwise NULL.
/// @note This API is just for debuging & testing, only support dtype `float32, uint8`
KESTREL_API
kestrel_tensor_t *kestrel_tensor_from_npy(const char *filename, const char *tensor_name,
                                          kestrel_mem_type_e mem_type);

/// @}

#ifdef __cplusplus
}
#endif

#endif
