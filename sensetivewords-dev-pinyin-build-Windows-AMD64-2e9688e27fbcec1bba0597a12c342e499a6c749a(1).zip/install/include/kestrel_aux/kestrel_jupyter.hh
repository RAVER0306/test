#include <kestrel.hh>
#include <keson.hh>

#include <iostream>

#include "xtl/xbase64.hpp"
#include "xeus/xjson.hpp"
#include "xcpp/xdisplay.hpp"

xeus::xjson mime_bundle_repr(const kestrel_mem_type_e &a)
{
        auto bundle = xeus::xjson::object();
        bundle["text/plain"] = a == KESTREL_MEM_HOST ? "Host" : "Device";
        return bundle;
}

xeus::xjson mime_bundle_repr(const kestrel_point2d_t &a)
{
        auto bundle = xeus::xjson::object();
        char msg[1024] = { 0 };
        snprintf(msg, 1024,
                 "Point 2D (integer) @ %p\n"
                 "\t x : %d\n"
                 "\t y : %d\n",
                 &a, a.x, a.y);
        bundle["text/plain"] = std::string(msg);
        return bundle;
}

xeus::xjson mime_bundle_repr(const kestrel_point2df_t &a)
{
        auto bundle = xeus::xjson::object();
        char msg[1024] = { 0 };
        snprintf(msg, 1024,
                 "Point 2D (float) @ %p\n"
                 "\t x : %f\n"
                 "\t y : %f\n",
                 &a, a.x, a.y);
        bundle["text/plain"] = std::string(msg);
        return bundle;
}

xeus::xjson mime_bundle_repr(const kestrel_size2d_t &a)
{
        auto bundle = xeus::xjson::object();
        char msg[1024] = { 0 };
        snprintf(msg, 1024,
                 "Size 2D @ %p\n"
                 "\t width  : %d\n"
                 "\t height : %d\n",
                 &a, a.width, a.height);
        bundle["text/plain"] = std::string(msg);
        return bundle;
}

xeus::xjson mime_bundle_repr(const kestrel_area2d_t &a)
{
        auto bundle = xeus::xjson::object();
        char msg[1024] = { 0 };
        snprintf(msg, 1024,
                 "Area 2D @ %p\n"
                 "\t left   : %d\n"
                 "\t top    : %d\n"
                 "\t width  : %d\n"
                 "\t height : %d\n",
                 &a, a.left, a.top, a.width, a.height);
        bundle["text/plain"] = std::string(msg);
        return bundle;
}

xeus::xjson mime_bundle_repr(const kestrel_feature_t &a)
{
        auto bundle = xeus::xjson::object();
        char msg[1024] = { 0 };
        snprintf(msg, 1024,
                 "Feature @ %p\n"
                 "\t version    : %x\n"
                 "\t dimensions : %d\n",
                 &a, a.version, a.dims);
        bundle["text/plain"] = std::string(msg);
        return bundle;
}

xeus::xjson mime_bundle_repr(const kestrel_array_t &a)
{
        auto bundle = xeus::xjson::object();
        char msg[1024] = { 0 };
        snprintf(msg, 1024,
                 "Array @ %p\n"
                 "\t type code  : %d\n"
                 "\t item count : %zu\n",
                 &a, a.keson_code, a.element_count);
        bundle["text/plain"] = std::string(msg);
        return bundle;
}

xeus::xjson mime_bundle_repr(const kestrel_buffer &a)
{
        auto bundle = xeus::xjson::object();
        char msg[1024] = { 0 };
        snprintf(msg, 1024,
                 "Buffer @ %p\n"
                 "\t Data     : %p\n"
                 "\t Device   : %s:%d\n"
                 "\t Size     : %zu\n"
                 "\t Capacity : %zu\n"
                 "\t RefCount : %d\n",
                 a, kestrel_buffer_raw_pointer(a), kestrel_buffer_mem_device_name(a),
                 kestrel_buffer_mem_device_id(a), kestrel_buffer_size(a),
                 kestrel_buffer_capacity(a), kestrel_buffer_get_ref_cnt(a));
        bundle["text/plain"] = std::string(msg);
        return bundle;
}

xeus::xjson mime_bundle_repr(const kestrel_frame_t &f)
{
        auto bundle = xeus::xjson::object();
        kestrel_buffer buf = kestrel_buffer_alloc(0, KESTREL_MEM_HOST);
        kestrel_frame_encode(&f, KESTREL_ENC_FMT_PNG, buf);
        std::string imgData((const char *)kestrel_buffer_raw_pointer(buf),
                            kestrel_buffer_size(buf));
        bundle["image/png"] = xtl::base64encode(imgData);
        kestrel_buffer_free(&buf);
        return bundle;
}

namespace Kestrel
{

struct JLog {
        inline JLog(kestrel_log_meta_t &meta, const char *fmt, va_list vl)
        {
                std::string level;
                std::string color;

                switch (meta.level) {
                case KESTREL_LL_TRACE:
                        level = "[TRC]";
                        color = "color:#0f91ff;";
                        break;
                case KESTREL_LL_DEBUG:
                        level = "[DBG]";
                        color = "color:#0f91ff;";
                        break;
                case KESTREL_LL_INFO:
                        level = "[INF]";
                        color = "color:#0f91ff;";
                        break;
                case KESTREL_LL_WARNING:
                        level = "[WRN]";
                        color = "color:#ff9900;";
                        break;
                case KESTREL_LL_ERROR:
                        level = "[ERR]";
                        color = "color:#ff2f00;";
                        break;
                case KESTREL_LL_ESSENTIAL:
                        level = "[MSG]";
                        color = "";
                        break;
                default:
                        level = "[XXX]";
                        color = "";
                        break;
                }

                std::string label =
                    meta.label[0] == '\0' ? "" : "[" + std::string(meta.label) + "]";
                char msg[1024] = { 0 };
                vsnprintf(msg, 1024, fmt, vl);

                m_plain = level + label + msg;
                m_html = "<pre style=\"" + color + "font-family: Menlo, Consolas, monospace;\">" +
                         "<span style=\"font-weight: bolder;\">" + level + "</span>" +
                         "<span>[kestrel]" + label + " " + msg + "</span>" + "</pre>";
        }
        std::string m_html;
        std::string m_plain;
};

xeus::xjson mime_bundle_repr(const JLog &a)
{
        auto bundle = xeus::xjson::object();
        bundle["text/html"] = a.m_html;
        bundle["text/plain"] = a.m_plain;
        return bundle;
}

class Cling
{
public:
        static void Init()
        {
                kestrel_log_set_callback(
                    [](kestrel_log_meta_t meta, const char *fmt, va_list vl) {
                            xcpp::display(JLog(meta, fmt, vl));
                            return 0;
                    },
                    NULL);
        }
};

xeus::xjson mime_bundle_repr(const PluginInfo &a)
{
        auto bundle = xeus::xjson::object();
        char msg[1024] = { 0 };
        snprintf(msg, 1024,
                 "Plugin @ %p\n"
                 "\t Name     : %s\n"
                 "\t Type     : %d\n"
                 "\t Version  : %s\n"
                 "\t Revision : %s\n",
                 &a, a.Name().c_str(), a.Type(), a.Version().c_str(), a.Revision().c_str());
        bundle["text/plain"] = std::string(msg);
        return bundle;
}

xeus::xjson mime_bundle_repr(const Feature &a)
{
        kestrel_feature_t *f = a.Raw();
        if (f) {
                return mime_bundle_repr(*f);
        }

        auto bundle = xeus::xjson::object();
        bundle["text/plain"] = "Feature @ (nil)";
        return bundle;
}

xeus::xjson mime_bundle_repr(const Array &a)
{
        kestrel_array_t *arr = a.Raw();
        if (arr) {
                return mime_bundle_repr(*arr);
        }

        auto bundle = xeus::xjson::object();
        bundle["text/plain"] = "Array @ (nil)";
        return bundle;
}

xeus::xjson mime_bundle_repr(const Buffer &a)
{
        return mime_bundle_repr(a.Raw());
}

xeus::xjson mime_bundle_repr(const Frame &i)
{
        auto bundle = xeus::xjson::object();
        Buffer buf;
        FrameUtils::Encode(i, KESTREL_ENC_FMT_PNG, &buf);
        std::string imgData((const char *)buf.Data(), buf.Size());
        bundle["image/png"] = xtl::base64encode(imgData);
        return bundle;
}

} // namespace Kestrel