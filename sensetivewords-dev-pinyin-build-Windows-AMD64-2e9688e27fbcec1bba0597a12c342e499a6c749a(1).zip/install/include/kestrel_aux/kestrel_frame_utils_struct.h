
#ifndef KESTREL_FRAME_UTILS_STRUCT_H_
#define KESTREL_FRAME_UTILS_STRUCT_H_

/// @brief resize param
typedef enum kestrel_resize_param_e {
        KESTREL_KEEP_RATIO_RESIZE = 0, /**<keep ratio resize**/
        KESTREL_AUTO_RATIO_RESIZE = 1, /**<auto calculate resize ratio by dst row and dst col**/
} kestrel_resize_param_e;

/// @brief Kestrel frame rotation type for kestrel_frame_rotate()
typedef enum kestrel_orientation_e {
        KESTREL_CLOCKWISE_90, /**< Rotate frame clockwise 90 degree */
        KESTREL_CLOCKWISE_180, /**< Rotate frame clockwise 180 degree */
        KESTREL_CLOCKWISE_270 /**< Rotate frame clockwise 270 degree */
} kestrel_orientation_e;

/**
 * @brief Kestrel Tensor pixel color layout
 */
typedef enum kestrel_tensor_color_e {
        KESTREL_UNKNOWN_TENSOR = -1, /**< Unknown tensor param */
        KESTREL_BGR_TENSOR = 0, /**< BGR tensor */
        KESTREL_RGB_TENSOR = 1, /**< RGB tensor */
        KESTREL_GRAY_TENSOR = 2, /**< GRAY tensor */
} kestrel_tensor_color_e;

/**
 * @brief Kestrel frame encode format for kestrel_frame_encode()
 */
typedef enum kestrel_frame_enc_format_e {
        KESTREL_ENC_FMT_UNKNOWN, /**< Unknow encode format */
        KESTREL_ENC_FMT_JPG, /**< JPG encode */
        KESTREL_ENC_FMT_BMP, /**< BMP encode */
        KESTREL_ENC_FMT_PNG /**< PNG encode */
} kestrel_frame_enc_format_e;

/**
 * @brief Kestrel border type
 */
typedef enum kestrel_border_type_e {
        KESTREL_BORDER_CONSTANT,
        KESTREL_BORDER_REPLICATE,
        KESTREL_BORDER_REFLECT,
        KESTREL_BORDER_REFLECT101
} kestrel_border_type_e;

/**
 * @brief Mode of the contour retrieval algorithm
 */
typedef enum kestrel_retrieval_mode_e {
        RETR_EXTERNAL = 0,
        RETR_LIST = 1,
        RETR_CCOMP = 2,
        RETR_TREE = 3,
        RETR_FLOODFILL = 4
} kestrel_retrieval_mode_e;

/**
 * @brief The contour approximation algorithm
 */
typedef enum kestrel_contour_approximation_mode_e {
        CHAIN_APPROX_NONE = 0,
        CHAIN_APPROX_SIMPLE = 1,
        CHAIN_APPROX_TC89_L1 = 2,
        CHAIN_APPROX_TC89_KCOS = 3
} kestrel_contour_approximation_mode_e;

/**
 * @brief Kestrel pixel
 */
typedef struct kestrel_pixel_t {
        float r;
        float g;
        float b;
} kestrel_pixel_t;

// http://kestrel.sensetime.com/#/zh-cn/v1.0.0/API/Auxiliaries/Frame?id=to-tensor
#define KESTREL_FRAME_TO_TENSOR 0
#define KESTREL_RESIZE_TO_TENSOR 1
#define KESTREL_AFFINE_TO_TENSOR 2
#define KESTREL_PERSPECTIVE_TO_TENSOR 3

#define KESTREL_TO_TENSOR_MASK 0xF

#define KESTREL_CHANNEL_NORM (1 << 4)
#define KESTREL_HISTOGRAM (1 << 5)

typedef struct kestrel_frame_transform_param_t {
        kestrel_tensor_t *tensor; /** input tensor */
        kestrel_tensor_color_e tensor_color; /** Input tensor type: bgr/rgb/gray ref
                                                `kestrel_tensor_color_e` */
        uint32_t operators; /** preprocess combination */
        size_t batch; /** number of frames and rois */
        kestrel_frame_t **frames; /** frames */
        kestrel_area2d_t *rois; /** rois on frames*/
        kestrel_size2d_t *dst_sizes; /** resized frame */
        float (*mats)[3][3]; /** warpaffine/perspective transformation matrix */
        kestrel_pixel_t means; /** means to substract */
        kestrel_pixel_t stds; /** stds to divide */
        kestrel_pixel_t *paddings; /** default pixel filled in tensor, when frame is smaller than
                                      tensor, the outer will be filled with paddings */
        kestrel_buffer *buffer; /** cache pool will dynamic(trigger: memory type or size) allocate
                                 * in this function. `buffer` must be released by
                                 * kestrel_buffer_free()*/
} kestrel_frame_transform_param_t;

#endif // KESTREL_FRAME_UTILS_STRUCT_H_
