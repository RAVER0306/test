#ifndef KESTREL_AUX_KESTREL_QUOTAS_H_
#define KESTREL_AUX_KESTREL_QUOTAS_H_

#include <kestrel_core/kestrel_license.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @ingroup kestrel_aux
/// @defgroup kestrel_quotas Quotas
/// Kestrel Quotas Auxilary API
/// @{

///
/// License quota max name length
///
#define KESTREL_QUOTA_ITEM_NAME_LEN 64

///
/// Quota item definition, to send request to server, used for get quota info as well
///
typedef struct kestrel_license_quota_item_t {
        char name[KESTREL_QUOTA_ITEM_NAME_LEN];
        int value;
        int free_value;
} kestrel_license_quota_item_t;

KESTREL_API
k_err kestrel_quota_init(const char *product_name);

KESTREL_API
void kestrel_quota_set_udid_getter(kestrel_udid_getter getter);

KESTREL_API
void kestrel_quota_reset_udid_getter();

KESTREL_API
void kestrel_quota_set_product_version_getter(kestrel_product_version_getter getter);

KESTREL_API
void kestrel_quota_reset_product_version_getter();

KESTREL_API
k_err kestrel_quota_add_license(const char *license_str, const char *signed_code);

KESTREL_API
k_err kestrel_quota_set_server(const char *master_url, const char *slave_url);

KESTREL_API
void kestrel_quota_set_server_name_check(int32_t check);

KESTREL_API
k_err kestrel_quota_request(const kestrel_license_quota_item_t *quotas_array, int quota_array_len,
                            int async);

KESTREL_API
k_err kestrel_quota_current(kestrel_license_quota_item_t **quotas_array, int *quota_array_len,
                            int *free_active, unsigned long *time_stamp);

KESTREL_API
void kestrel_quota_release(kestrel_license_quota_item_t **quotas_array);

KESTREL_API
k_err kestrel_quota_heartbeat();

KESTREL_API
void kestrel_quota_deinit();

#ifdef __cplusplus
}
#endif

/// @}

#endif