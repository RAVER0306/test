#ifndef KESTREL_KESTREL_NN_DEF_H
#define KESTREL_KESTREL_NN_DEF_H

#include <kestrel_core/kestrel_plugin.h>
#include <kestrel_core/kestrel_model.h>
#include "kestrel_tensor.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_nn
/// @{

///
/// Netural network plug-in type
///
#define KESTREL_NN_PLUGIN (1)

///
/// Kestrel neutral network handle definition
///
typedef void *KESTREL_NN;

///
/// Kestrel neutral network prepare parameter
///
typedef void *kestrel_nn_transform_param;

///
/// Kestrel neutral network properties definition
///
typedef struct kestrel_nn_properties_t {
        int32_t is_input_reshapeable;
        int32_t is_batch_size_variable;
        int32_t cur_batch_size;
        int32_t max_batch_size;
        int32_t has_prepared;
} kestrel_nn_properties_t;

///
/// Neural Network interface definition
///
typedef struct kestrel_nn_api_t {
        /** Create neutral network from model */
        KESTREL_NN (*create)(void *h, kestrel_model m, const char *net, const char *extra_cfg);
        /** Extend some intermediate layer ass output */
        k_err (*extend_output)(KESTREL_NN nn, const char *tensor_name);
        /** Prepare neutral network for runing */
        k_err (*prepare)(KESTREL_NN nn);
        /** Perform pre-process according to given param */
        k_err (*preprocess)(KESTREL_NN nn, kestrel_nn_transform_param param);
        /** Get tensor info of current neutral network */
        k_err (*tensor_info)(KESTREL_NN nn, const char *name, kestrel_tensor_meta_t *tensor_info);
        /** Reshape tensor, tensor[name] should be input tensor */
        k_err (*reshape)(KESTREL_NN nn, const char *name, const kestrel_tensor_meta_t *in);
        /** Get specific tensor of current neutral network */
        k_err (*get_tensor)(KESTREL_NN nn, const char *name, kestrel_tensor_t **tensor);
        /** Set specific tensor from external tensor data */
        k_err (*set_tensor)(KESTREL_NN nn, const char *name, kestrel_tensor_t *tensor);
        /** Get NN backend properties */
        k_err (*get_properties)(KESTREL_NN nn, kestrel_nn_properties_t *prop);
        /** Forwading netural network */
        k_err (*forward)(KESTREL_NN nn);
        /** Forwading netural network asynchronously */
        k_err (*forward_async)(KESTREL_NN nn, kestrel_event *e);
        /** Await asynchronous forwading done */
        k_err (*forward_await)(KESTREL_NN nn, kestrel_event e);
        /** Destroy netural network */
        void (*destroy)(KESTREL_NN nn);
} kestrel_nn_api_t;

///
/// NN plug-in register sugar macro
///
#define REGISTER_NN(name)                                                                        \
        static kestrel_nn_api_t ___##name##_ppi___ = {                                           \
                name##_create,     name##_extend_output, name##_prepare,                         \
                name##_preprocess, name##_tensor_info,   name##_reshape,                         \
                name##_get_tensor, name##_set_tensor,    name##_get_properties,                  \
                name##_forward,    name##_forward_async, name##_forward_await,                   \
                name##_destroy                                                                   \
        };                                                                                       \
        REGISTER_PLUGIN(name, KESTREL_NN_PLUGIN, ___##name##_ppi___)

/// @}

#ifdef __cplusplus
}
#endif
#endif
