#ifndef KESTREL_CORE_KESTREL_BUFFER_H
#define KESTREL_CORE_KESTREL_BUFFER_H

#include <kestrel_core/kestrel_device.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_buffer
///
/// With the help of @ref kestrel_device, we abstract a set of API for heterogeneous memory
/// management.
///
/// All memory resource is divided into two categories: KESTREL_MEM_HOST & KESTREL_MEM_DEVICE. For
/// ease of use, we do not distinguish what device & which device a device memory belongs, but
/// depends on what device is bound at the present time. When user calls kestrel_buffer_alloc() or
/// kestrel_buffer_make() to construct a device memory buffer (means type argument is
/// KESTREL_MEM_DEVICE), we assume the memory is managed on current bound device (returns error if
/// no device bound on current thread), at the same time, corresponding deallocate function is
/// bound with this memory buffer, in order to release it correctly.
///
/// Reference @ref kestrel_device_api_t, we know a device plug-in provides transmission APIs to
/// implement memory transmission, including device to host, host to device and device to device.
/// Based on these design, Kestrel do not support memory transmission between different type
/// devices. If necessary, user could get memory bound device type & ID by calling
/// kestrel_buffer_mem_device_name() and kestrel_buffer_mem_device_id(), and implement a
/// specialized function for memory transmission from A type device to B type device.
///
/// @{

///
/// Kestrel buffer struct definition.
///
typedef struct kestrel_buffer_t *kestrel_buffer;

/// Custom finalizer function
/// @param[in] ud By pass from kestrel_buffer_make() parameter `finalizer_ud`
/// @param[in] buf Buffer handle about to be finalized
/// @note This finalizer callback only will be invoked on reference count reduces to 0.
/// @note Ordinarily, finalizer only need to free raw data of buffer, and as an auxiliary,
/// `kestrel_buffer` could provide more information via calling buffer APIs. Nevertheless, the
/// user should not call kestrel_buffer_free() in this finalizer.
typedef void (*kestrel_buf_finalizer)(void *ud, kestrel_buffer buf);

/// @brief Make a buffer form external memory pointer
/// @param[in] data Memory pointer.
/// @param[in] size Size of memory.
/// @param[in] type Memory type which indicates wether data is on device manage or host.
/// @param[in] finalizer Custom finalizer function, could be `NULL` which indicates do not free.
/// @param[in] finalizer_ud User data for finalizer function.
/// @return A buffer following provided parameters.
/// @note The buffer is auto refed, and ref count is `1`.
KESTREL_API
kestrel_buffer kestrel_buffer_make(void *data, size_t size, kestrel_mem_type_e type,
                                   kestrel_buf_finalizer finalizer, void *finalizer_ud);

/// @brief Allocate a buffer
/// @param[in] size Size of memory.
/// @param[in] type Memory type which indicates wether data is on device manage or host.
/// @return A buffer following provided parameters.
/// @note The buffer is auto refed, and ref count is 1.
KESTREL_API
kestrel_buffer kestrel_buffer_alloc(size_t size, kestrel_mem_type_e type);

/// @brief Get buffer memory type
/// @param[in] buf Memory buffer handle
/// @return Buffer memory type
KESTREL_API
kestrel_mem_type_e kestrel_buffer_mem_type(kestrel_buffer buf);

/// @brief Get buffer memory binded device name
/// @param[in] buf Memory buffer handle
/// @return Buffer memory binded device name
KESTREL_API
const char *kestrel_buffer_mem_device_name(kestrel_buffer buf);

/// @brief Get buffer memory binded device ID
/// @param[in] buf Memory buffer handle
/// @return Buffer memory binded device ID
KESTREL_API
kestrel_dev_id kestrel_buffer_mem_device_id(kestrel_buffer buf);

/// @brief Set all data in buffer
/// @param[in] buf Memory buffer handle.
/// @param[in] val Reset value.
/// @return `KESTREL_OK` for successful, otherwise return error code.
KESTREL_API
k_err kestrel_buffer_set(kestrel_buffer buf, uint8_t val);

/// @brief Map a buffer to opposite device type
/// @param[in] buf Source buffer.
/// @return A new buffer which is a map buffer form buffer `in`, the mapped buffer also should be
/// freed using kestrel_buffer_free().
/// @note Mapped buffer shares data memory with origin buffer, but has different device type.
/// @note This API requires current binding device supports map/unmap operation, otherwise, it
/// does not work, and returns NULL.
KESTREL_API
kestrel_buffer kestrel_buffer_map(kestrel_buffer buf);

/// @brief Return a reference of sliced buffer
/// @param[in] src Source memory buffer handle.
/// @param[in] offset Slice buffer offset.
/// @param[in] len Slice buffer length.
/// @return A reference of sliced src, or `NULL` if error occurred.
KESTREL_API
kestrel_buffer kestrel_buffer_slice(kestrel_buffer src, size_t offset, size_t len);

/// @brief Duplicate a buffer
/// @param[in] src Source memory buffer handle.
/// @return A duplication of src, or `NULL` if error occurred.
KESTREL_API
kestrel_buffer kestrel_buffer_duplicate(kestrel_buffer src);

/// @brief Copy src buffer to dst buffer
/// @param[in] src Source memory buffer handle.
/// @param[in] dst Destination memory buffer handle.
/// @return `KESTREL_OK` for successful, otherwise return error code.
/// @note If the destination buffer memory category is different with the source, and one of them
/// is `KESTREL_MEM_HOST` buffer, this function will do memory transmission automatically.
KESTREL_API
k_err kestrel_buffer_copy(kestrel_buffer src, kestrel_buffer dst);

/// @brief Copy a 2d area of src buffer to dst buffer
/// @param[in] src Source memory buffer handle.
/// @param[in] src_x X coordinate of copying area.
/// @param[in] src_y Y coordinate of copying area.
/// @param[in] src_stride Stride size(in bytes) of source memory buffer.
/// @param[in] dst Destination memory buffer handle.
/// @param[in] dst_x X coordinate of copying area.
/// @param[in] dst_y Y coordinate of copying area.
/// @param[in] dst_stride Stride size(in bytes) of destination memory buffer.
/// @param[in] linesize Linesize of copying area in bytes.
/// @param[in] height Height of copying area.
/// @return `KESTREL_OK` for successful, otherwise return error code.
/// @note If the destination buffer memory category is different with the source, and one of them
/// is `KESTREL_MEM_HOST` buffer, this function will do memory transmission automatically.
KESTREL_API
k_err kestrel_buffer_copy2D(kestrel_buffer src, size_t src_x, size_t src_y, size_t src_stride,
                            kestrel_buffer dst, size_t dst_x, size_t dst_y, size_t dst_stride,
                            size_t linesize, size_t height);

/// @brief Copy src buffer to dst buffer asynchronously
/// @param[in] src Source memory buffer handle.
/// @param[in] dst Destination memory buffer handle.
/// @param[out] e Event handle for kestrel_buffer_copy_await().
/// @return `KESTREL_OK` for successful, otherwise return error code.
/// @note If the destination buffer memory category is different with the source, and one of them
/// is `KESTREL_MEM_HOST` buffer, this function will do memory transmission automatically.
KESTREL_API
k_err kestrel_buffer_copy_async(kestrel_buffer src, kestrel_buffer dst, kestrel_event *e);

/// @brief Copy a 2d area of src buffer to dst buffer
/// @param[in] src Source memory buffer handle.
/// @param[in] src_x X coordinate of copying area.
/// @param[in] src_y Y coordinate of copying area.
/// @param[in] src_stride Stride size(in bytes) of source memory buffer.
/// @param[in] dst Destination memory buffer handle.
/// @param[in] dst_x X coordinate of copying area.
/// @param[in] dst_y Y coordinate of copying area.
/// @param[in] dst_stride Stride size(in bytes) of destination memory buffer.
/// @param[in] linesize Linesize of copying area in bytes.
/// @param[in] height Height of copying area.
/// @param[out] e Event handle for kestrel_buffer_copy_await().
/// @return `KESTREL_OK` for successful, otherwise return error code.
/// @note If the destination buffer memory category is different with the source, and one of them
/// is `KESTREL_MEM_HOST` buffer, this function will do memory transmission automatically.
KESTREL_API
k_err kestrel_buffer_copy2D_async(kestrel_buffer src, size_t src_x, size_t src_y,
                                  size_t src_stride, kestrel_buffer dst, size_t dst_x,
                                  size_t dst_y, size_t dst_stride, size_t linesize, size_t height,
                                  kestrel_event *e);

/// @brief Copy a 2d area of src buffer to dst buffer
/// @param[in] e Event handle created by kestrel_buffer_copy_async() or
/// kestrel_buffer_copy2D_async().
/// @param[out] dst Destination memory buffer handle output, could be `NULL`, if do not need to
/// get destination buffer at moment.
/// @return `KESTREL_OK` for successful, otherwise return error code.
KESTREL_API
k_err kestrel_buffer_copy_await(kestrel_event e, kestrel_buffer *dst);

/// @brief Get buffer data pointer
/// @param[in] buf Memory buffer handle.
/// @return Pointer to buffer raw data if successful, otherwise return NULL.
KESTREL_API
uint8_t *kestrel_buffer_raw_pointer(kestrel_buffer buf);

/// @brief Reference a buffer
/// @param[in] buf Memory buffer handle.
/// @return Input buffer self.
KESTREL_API
kestrel_buffer kestrel_buffer_ref(kestrel_buffer buf);

/// @brief Get reference count of buffer
/// @param[in] buf Memory buffer handle.
/// @return Reference count of buffer.
KESTREL_API
int32_t kestrel_buffer_get_ref_cnt(kestrel_buffer buf);

/// @brief Get buffer size
/// @param[in] buf Memory buffer handle.
/// @return Size of buffer in bytes.
KESTREL_API
size_t kestrel_buffer_size(kestrel_buffer buf);

/// @brief Resize buffer
/// @param[in] buf Memory buffer handle.
/// @param[in] size Destinate memory buffer resize.
/// @return `KESTREL_OK` for successful, otherwise return error code.
/// @note If size greater than buffer capacity, it will realloc a memory block, and update into
/// the buffer, else just modify the size field simply.
KESTREL_API
k_err kestrel_buffer_resize(kestrel_buffer buf, size_t size);

/// @brief Shrink buffer capacity to current size
/// @param[in] buf Memory buffer handle.
/// @return `KESTREL_OK` for successful, otherwise return error code.
/// @note After invoking, buffer bound memory might be changed, and old memory chunk should not
/// be used anymore.
KESTREL_API
k_err kestrel_buffer_shrink(kestrel_buffer buf);

/// @brief Append a buffer data to destination buffer
/// @param[in] buf Destination buffer which going to be append data to.
/// @param[in] append Source buffer which includes appending data.
/// @return `KESTREL_OK` for successful, otherwise return error code.
/// @note If destination buffer memory category is different with source, and one of them is
/// `KESTREL_MEM_HOST` buffer, this function will do memory transmission automatically.
KESTREL_API
k_err kestrel_buffer_append(kestrel_buffer buf, kestrel_buffer append);

/// @brief Fairly similary with kestrel_buffer_append(), but free appended buffer after successful
/// invoke
/// @param[in] buf Destination buffer which going to be append data to.
/// @param[in,out] append Pointer to source buffer which includes appending data.
/// @return `KESTREL_OK` for successful, otherwise return error code.
/// @note If `KESTREL_OK` returned, `*append` will be freed, and reset to `NULL`. Otherwise,
/// neither `buf` nor `*append` will be touched.
KESTREL_API
k_err kestrel_buffer_append_and_free(kestrel_buffer buf, kestrel_buffer *append);

/// @brief Append an external memory data into buffer
/// @param[in] buf Destination buffer which going to be append data to.
/// @param[in] data Pointer to appending data, developer should guarantee it has same memory
/// category with `buf`.
/// @param[in] len Length of appending data.
/// @return `KESTREL_OK` for successful, otherwise return error code.
KESTREL_API
k_err kestrel_buffer_append_data(kestrel_buffer buf, void *data, size_t len);

/// @brief Get buffer capacity
/// @param[in] buf Memory buffer handle.
/// @return Capacity of buffer in bytes.
KESTREL_API
size_t kestrel_buffer_capacity(kestrel_buffer buf);

/// @brief Free a buffer
/// @param[in,out] buf Pointer of memory buffer handle, after invoke, will be set to `NULL`.
/// @return Reference count after invoking, the buffer is destroyed only if returned value equals
/// 0, all other values (including negative value) indicates actural destroy routine not trigger.
/// @note If the buffer is still be referenced, `buf` is not a dangling pointer, because memory
/// block is actually freed (by invoking custom finalizer or `mem_free()` which is kept in device
/// handle) only when reference count reduces to `0`.
KESTREL_API
int32_t kestrel_buffer_free(kestrel_buffer *buf);

KESTREL_API
const kestrel_dev_hdl_t *kestrel_buffer_dev_hdl(kestrel_buffer buf);

/// @}

#ifdef __cplusplus
}
#endif

#endif
