#ifndef KESTREL_KESTREL_KESON_H
#define KESTREL_KESTREL_KESON_H

#include <kestrel_core/kestrel_define.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_keson
/// @{

///
/// Keson struct definition
///
typedef struct kJSON *keson;

///
/// Keson serializing string definition
///
typedef char *keson_string;

#define KESON_INVALID (0)

///
/// Keson extension node type definition
///
typedef struct keson_ext_t {
        /** Extension node type, should be unique for each extension type */
        uint8_t keson_type;
        /** Extension node type name, for better human-readable only */
        const char *name;
        /** Extension node packing operator */
        keson (*pack_fx)(void *data);
        /** Extension node unpacking operator */
        k_err (*unpack_fx)(keson obj, void **data);
        /** Extension node duplication operator */
        keson (*duplicate_fx)(keson src);
        /** Extension node delete operator */
        void (*delete_fx)(keson obj);
        /** Extension node print readable operator called `keson_print` */
        k_err (*readable_fx)(keson obj, keson *out);
        /** Extension node parse readable operator called `keson_parse` */
        k_err (*parse_fx)(keson obj, keson *out);
} keson_ext_t;

KESTREL_API
void keson_set_hooks(void *(*malloc_fn)(size_t sz), void (*free_fn)(void *ptr));

KESTREL_API
void keson_reset_hooks();

KESTREL_API
k_err keson_register_extend_type(keson_ext_t meta);

KESTREL_API
keson_ext_t keson_get_extend_handle(int32_t keson_type);

KESTREL_API
keson_ext_t keson_set_extend_handle(keson_ext_t meta);

KESTREL_API
void keson_unregister_extend_type(int32_t keson_type);

KESTREL_API
void keson_unregister_all_extend_type();

/// @brief Render a Keson to text for transfer/storage.
/// @param[in] node Keson node.
/// @param[in] pretty_format Print format.
/// @return text for keson, the text can be used as char *, but has to be freed using
/// keson_free_string().
KESTREL_API
keson_string keson_print(keson node, int32_t pretty_format);

/// @brief Free the result of keson_print().
/// @param[in,out] string String which is going to be freed.
KESTREL_API
void keson_free_string(keson_string *string);

/// @brief Parse string to Keson, without extend
/// @param[in] str String in format of JSON.
/// @return parsed keson, if `str` is not a legal json string, `NULL` will be returned.
KESTREL_API
keson keson_parse_shallow(const char *str);

/// @brief Extend ext nodes in input shallow Keson
/// @param[in] shallow_keson Shallow Keson parse from string by keson_parse_shallow()
/// @return Extended keson
/// @note This API extends node in-place
KESTREL_API
void keson_parse_extend(keson shallow_keson);

/// @brief Parse string to Keson with ext node extended, equivalent to keson_parse_shallow() +
/// keson_parse_extend()
/// @param[in] str String in format of JSON.
/// @return parsed keson, if `str` is not a legal json string, `NULL` will be returned.
KESTREL_API
keson keson_parse(const char *str);

/// @brief Get the name of Keson
/// @param[in] node Keson node.
/// @return name of keson_node, no need to free.
/// @note Usually the node shoule be one child of Object Keson node. A child of Array Keson node
/// does not has it's key
KESTREL_API
const char *keson_key(keson node);

/// @brief Get the first child of the given Object or Array Keson node.
/// @param node Keson node.
/// @return the first child of `node`, if `node` has no child, `NULL` will be returned. No need to
/// free.
KESTREL_API
keson keson_child(keson node);

/// @brief Get the next brother node of the given node
/// @param node Keson node.
/// @return the next brother of `node`, if `node` has no brother, `NULL` will be returned. No need
/// to free.
KESTREL_API
keson keson_next(keson node);

/// @brief Check whether node is Empty, size is 0
/// @param[in] node Keson node.
/// @return 1 if `node` is empty, else 0.
KESTREL_API
int32_t keson_empty(keson node);

/// @brief Get the size of Object or Array Keson node
/// @param[in] node Keson node.
/// @return node size.
/// @note This api can be used to get the size of both Object and Array Keson node.
KESTREL_API
int32_t keson_array_size(keson array);

/// @brief Get a item of Array Keson node
/// @param[in] array Array Keson node.
/// @param[in] index Index of array.
/// @return the nth child of `array`. If index is negative or out of `array`'s size, `NULL` will
/// be returned. No need to free.
KESTREL_API
keson keson_get_array_item(keson array, int32_t index);

/// @brief Get a item of Object Keson node
/// @param object Object Keson node.
/// @param name Name.
/// @return the child with required name of `object`. If `object` has no child with `name`, `NULL`
/// will be returned. No need to free.
KESTREL_API
keson keson_get_object_item(keson object, const char *name);

/// @brief Get ext data of Ext Keson node.
/// @param node Keson node.
/// @param data Output data.
/// @return KESTREL_OK for succeed, otherwise failure.
KESTREL_API
k_err keson_get_ext_data(keson node, void **data);

KESTREL_API
const char *keson_error_info();

/// @brief Check whether node is False
/// @param[in] node Keson node.
/// @return 1 if `node` is False, else 0
KESTREL_API
int32_t keson_is_false(keson node);

/// @brief Check whether node is True
/// @param[in] node Keson node.
/// @return 1 if `node` is True, else 0
KESTREL_API
int32_t keson_is_true(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is a Boolean Keson node, else 0.
KESTREL_API
int32_t keson_is_bool(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is a Null Keson node, else 0.
/// @note `NULL` is a C pointer, not a Null Keson node.
KESTREL_API
int32_t keson_is_null(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is a Double or Int Keson node, else 0.
KESTREL_API
int32_t keson_is_number(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is a Double Keson node, else 0.
KESTREL_API
int32_t keson_is_double(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is a Int Keson node, else 0.
KESTREL_API
int32_t keson_is_int(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is a Binary Keson node, else 0.
KESTREL_API
int32_t keson_is_binary(keson node);

/// @brief Get int data of Int/Double Keson node.
/// @param[in] node Keson node.
/// @return int64 val of `node`. if `node` is a Double Keson node, the val will be casted to
/// int64. 0 will be returned if node type not match.
KESTREL_API
int64_t keson_get_int(keson node);

/// @brief Get double data of Double/Int Keson node.
/// @param[in] node Keson node.
/// @return double val of `node`. if `node` is a Int Keson node, the val will be casted to
/// double. 0.0 will be returned if node type not match.
KESTREL_API
double keson_get_double(keson node);

/// @brief Get binary type of Binary Keson node.
/// @param[in] node Keson node.
/// @return Binary type. 0 will be returned if node type not match.
KESTREL_API
uint8_t keson_get_binary_type(keson node);

/// @brief Get length of Binary Keson node.
/// @param[in] node Keson node.
/// @return Data length in bytes. 0 will be returned if node type not match.
KESTREL_API
size_t keson_get_binary_length(keson node);

/// @brief Get data of Binary Keson node.
/// @param[in] node Keson node.
/// @return Data of `node`. `NULL` will be returned if node type not match.
KESTREL_API
void *keson_get_binary_data(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is a String Keson node, else 0.
KESTREL_API
int32_t keson_is_string(keson node);

/// @brief Get string data of String Keson node.
/// @param[in] node Keson node.
/// @return String data of `node`. `NULL` will be returned if node type not match.
/// @note The returned string shares then same memory of `node`, do NOT free it.
KESTREL_API
char *keson_get_string(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is an Array Keson node, else 0.
KESTREL_API
int32_t keson_is_array(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is an Object Keson node, else 0.
KESTREL_API
int32_t keson_is_object(keson node);

/// @brief Check the type of node
/// @param[in] node Keson node.
/// @return 1 if `node` is an Extension Keson node, else 0.
KESTREL_API
int32_t keson_is_ext_object(keson node);

/// @brief Create a Null Keson node
/// @return Null Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_null();

/// @brief Create a Boolean Keson node with val as True
/// @return Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_true();

/// @brief Create a Boolean Keson node with val as False
/// @return Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_false();

/// @brief Create a Boolean Keson node
/// @param[in] boolean Boolean.
/// @return if boolean is not 0, True Keson node will be returned, if boolean is 0, False Keson
/// node will be returned. should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_bool(int32_t boolean);

/// @brief Create a Double Keson node.
/// @param[in] num Double value.
/// @return Double Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_double(double num);

/// @brief Create a Int Keson node.
/// @param[in] num Int64 value.
/// @return Int Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_int(int64_t num);

/// @brief Create a Binary Keson node.
/// @param type Binary type. You can find the definition of `type` in `kestrel/kestrel_struct.h`.
/// @param data Data which is going to be stored.
/// @param length Data length in bytes.
/// @return Binary Keson node. If `data` is `NULL`, an uninitialized Binary Keson node with
/// required capacity will be returned. The result should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_binary(uint8_t type, void *data, size_t length);

/// @brief Create a String Keson node.
/// @param[in] string String.
/// @return String Keson node, should be freed using keson_deep_delete(). The input string will be
/// duplicated and stored by Keson node.
KESTREL_API
keson keson_create_string(const char *string);

/// @brief Create a Const String Keson node.
/// @param[in] string String.
/// @return String Keson node, should be freed using keson_deep_delete(). The input string will be
/// referenced by Keson node. When node is freed, it will NOT release the referenced string.
/// Please manage the memory carefully.
KESTREL_API
keson keson_create_const_string(const char *string);

/// @brief Create a Array Keson node.
/// @return Empty Array Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_array();

/// @brief Create a Object Keson node.
/// @return Empty Object Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_object();

/// @brief Create a Extension Keson node.
/// @param type Keson type.
/// @param data Data.
/// @return Extension Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_create_ext_object(uint8_t type, void *data);

/// @brief Get type of a Extension Keson node.
/// @param node Ext Keson node.
/// @return Keson type
KESTREL_API
uint8_t keson_get_ext_type(keson node);

/// @brief Check child existance
/// @param node Keson node.
/// @param name Name.
/// @return 1 if child exists, else 0.
KESTREL_API
int32_t keson_has_child(keson node, const char *name);

/// @brief Duplicate Keson node
/// @param node Keson node.
/// @param recurse Recurse.
/// @return Duplicated Keson node, should be freed using keson_deep_delete(). If `recurse` is 1,
/// full duplicated Keson will be returned, if `recurse` is 0, only current node will be
/// duplicated, exclude it's children.
KESTREL_API
keson keson_duplicate(keson node, int32_t recurse);

/// @brief Add item to Array Keson node
/// @param[in] array Array Keson node.
/// @param[in] node Keson node which is going to be added to the tail of `array`. When added,
/// no need to free `node`.
KESTREL_API
void keson_add_item_to_array(keson array, keson node);

/// @brief Add item to Object Keson node
/// @param[in] object Object Keson node.
/// @param[in] name Name.
/// @param[in] node Keson node which is going to be added to the `object`. When added,
/// no need to free `node`.
/// @note The name will be duplicated and stored.
/// @note if `name` already exists in `object`, `node` will also be added into `object`, but
/// cannot be found by keson_get_object_item(). Please do NOT make such an operation.
KESTREL_API
void keson_add_item_to_object(keson object, const char *name, keson node);

/// @brief Add item to Object Keson node
/// @param[in] object Object Keson node.
/// @param[in] name Name.
/// @param[in] node Keson node which is going to be added to the `object`. When added,
/// no need to free `node`.
/// @note This api will not store the name itself, please make sure the lifecycle of `name`.
/// @note if `name` already exists in `object`, `node` will also be added into `object`, but
/// cannot be found by keson_get_object_item(). Please do NOT make such an operation.
KESTREL_API
void keson_add_item_to_object_with_const_name(keson object, const char *name, keson node);

/// @brief Detach an item via pointer
/// @param[in] parent Parent Keson node.
/// @param[in] node Keson node which is going to be detached.
/// @return Detached Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_detach_item_via_ptr(keson parent, keson node);

/// @brief Detach an item of Array
/// @param[in] array Parent Keson node.
/// @param[in] which Index.
/// @return Detached Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_detach_from_array(keson array, int32_t which);

/// @brief Delete an item of Array
/// @param[in] array Parent Keson node.
/// @param[in] which Index.
KESTREL_API
void keson_delete_item_from_array(keson array, int32_t which);

/// @brief Detach an item of Object
/// @param[in] object Parent Keson node.
/// @param[in] name Name.
/// @return Detached Keson node, should be freed using keson_deep_delete(). If no node found,
/// return `NULL`.
KESTREL_API
keson keson_detach_item_from_object(keson object, const char *name);

/// @brief Delete an item of Object
/// @param[in] object Parent Keson node.
/// @param[in] name Name.
KESTREL_API
void keson_delete_item_from_object(keson object, const char *name);

/// @brief Insert item to Array Keson node
/// @param[in] array Array Keson node.
/// @param[in] which Index.
/// @param[in] node Keson node which is going to be added to the tail of `array`. When added,
/// no need to free `node`.
KESTREL_API
void keson_insert_item_in_array(keson array, int32_t which, keson node);

KESTREL_API
void keson_shallow_delete(keson *node);

/// @brief Delete Keson node
/// @param data Keson node.
/// @note This api will delete node and it's children recursively.
KESTREL_API
void keson_deep_delete(keson *node);

/// @brief Replace node
/// @param parent Parent Keson node.
/// @param node Src Keson node.
/// @param replacement Dst Keson node.
/// @return 1 for succeed, otherwise failure.
/// @note After this operation, `node` will be freed inside, and `replacement` will now point to
/// new position in `parent`, no need to free.
KESTREL_API
int32_t keson_replace_item_via_ptr(keson parent, keson node, keson replacement);

/// @brief Build Keson Schema
/// @param schema_str Schema string.
/// @return Schame Keson node, should be freed using keson_deep_delete().
KESTREL_API
keson keson_schema_build(const char *schema_str);

/// @brief Validate Keson by Schema
/// @param[in] schema Schema Keson node.
/// @param[in] in Keson node which is going to be validated.
/// @return KESTREL_OK for succeed, otherwise failure.
KESTREL_API
k_err keson_schema_validate(keson schema, keson in);

/// @}

#ifdef __cplusplus
}
#endif

#endif
