#ifndef KESTREL_KESTREL_ENV_H
#define KESTREL_KESTREL_ENV_H

#include <kestrel_core/kestrel_define.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_env
///
/// Kestrel uses thread-specific data to simplify resource management, each thread maintains an
/// individual @ref kestrel_device binding data, by doing like this, prevent part of resource
/// competition.
///
/// Especially, there is a primary global handle which binds a built-in host device, for all
/// thread (including main thread) that not bind any device, uses the primary global handle as a
/// fallback. Once invoke kestrel_device_bind() in one thread, an advanced handle created, and
/// bind the device handle into it. On the contrary, after invoking kestrel_device_unbind(), the
/// device handle unbinds form current thread, and kestrel_device thread-specific data removed,
/// downgrading using the primary global handle.
///
/// @{

/// @example env_example.c
/// This example shows usage of environment API.

/// @brief Initial Kestrel environment
/// @param[in] product Product name to initialize
/// @return KESTREL_OK for succeed, other for error
/// @note Kestrel limits that each OS process can only bind with one product. Multi invoke
/// kestrel_init() with different product name will return an error.
/// @note  Multi invoke kestrel_init() with same product name is allowed, nevertheless, the user
/// just needs call kestrel_deinit() once on exit process.
/// @note Thread in which this API called, defined as primary thread, and kestrel_deinit() is
/// allowed be called in the primary thread only.
KESTREL_API
k_err kestrel_init(const char *product);

/// @brief Get current product name
/// @return Product name if succeed, NULL for error
KESTREL_API
const char *kestrel_product_name();

/// @brief De-initial Kestrel environment
/// @note **Only allowed** call on primary thread
/// @note All plug-ins will be auto unload after call.
/// @note The user should guarantee that all non-primary thread terminated.
KESTREL_API
void kestrel_deinit();

/// @}

#ifdef __cplusplus
}
#endif

#endif
