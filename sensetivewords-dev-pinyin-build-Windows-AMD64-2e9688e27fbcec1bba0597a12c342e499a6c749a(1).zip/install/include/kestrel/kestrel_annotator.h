#ifndef KESTREL_KESTREL_ANNOTATOR_H
#define KESTREL_KESTREL_ANNOTATOR_H

#include <kestrel/kestrel_keson.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_annotator
/// @{

///
/// Kestrel annotator handle definition
///
typedef struct kestrel_annotator_t *kestrel_annotator;

/// @brief Create an instance of plugin `annotator`
/// @param[in] annotator Plugin name to create instance
/// @param[in] config Plugin configuration
/// @return Handle of plugin instance, or NULL for fail
/// @note This API will try to load `<annotator>.kep` if it not been loaded yet
KESTREL_API
kestrel_annotator kestrel_annotator_open(const char *annotator, const char *config);

/// @brief Get plugin creation configuration json schema
/// @param[in] name Name of plugin
/// @return Creation configuration json schema
KESTREL_API
const char *kestrel_annotator_get_config_schema(const char *name);

/// @brief Get plugin processing configuration json schema
/// @param[in] name Name of plugin
/// @return Processing configuration json schema
KESTREL_API
const char *kestrel_annotator_get_params_schema(const char *name);

/// @brief Get plugin result json schema
/// @param[in] name Name of plugin
/// @return Result json schema
KESTREL_API
const char *kestrel_annotator_get_result_schema(const char *name);

/// @brief Startup routines before process
/// @param[in] h Handle of plugin instance
/// @param[in] in Input parameter KeSON
/// @param[out] out Output result KeSON, should be released by keson_delete()
/// @return `KPLUGIN_OK` for succeed, other for error
KESTREL_API
k_err kestrel_annotator_startup(kestrel_annotator h, keson in, keson *out);

/// @brief Run plugin processing interface
/// @param[in] h Input context handle
/// @param[in] in Input parameter KeSON
/// @param[out] out Output result KeSON, should be released by keson_delete()
/// @return `KPLUGIN_OK` for succeed, other for error
KESTREL_API
k_err kestrel_annotator_process(kestrel_annotator h, keson in, keson *out);

/// @brief Terminate routines before process
/// @param[in] h Handle of plugin instance
/// @param[in] in Input parameter KeSON
/// @param[out] out Output result KeSON, should be released by keson_delete()
/// @return `KPLUGIN_OK` for succeed, other for error
KESTREL_API
k_err kestrel_annotator_terminate(kestrel_annotator h, keson in, keson *out);

/// @brief Close plugin instance
/// @param[in,out] h Handle of plugin instance
KESTREL_API
void kestrel_annotator_close(kestrel_annotator *h);

/// @}

#ifdef __cplusplus
}
#endif

#endif
