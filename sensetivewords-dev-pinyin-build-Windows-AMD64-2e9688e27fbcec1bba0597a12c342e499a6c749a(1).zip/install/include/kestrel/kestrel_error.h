#ifndef KESTREL_KESTREL_ERROR_H
#define KESTREL_KESTREL_ERROR_H

#include <kestrel_core/kestrel_define.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_error
/// @{

/// @brief Convert error code to human readable message
/// @param[in] errcode Error code going to be parse
/// @return Error message string
KESTREL_API
const char *kestrel_error_info(k_err errcode);

/// @}

#ifdef __cplusplus
}
#endif

#endif
