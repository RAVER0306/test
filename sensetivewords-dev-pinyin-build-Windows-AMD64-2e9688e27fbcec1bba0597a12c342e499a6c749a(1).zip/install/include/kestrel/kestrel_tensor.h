#ifndef KESTREL_KESTREL_TENSOR_H
#define KESTREL_KESTREL_TENSOR_H

#include <kestrel/kestrel_buffer.h>
#include <kestrel/kestrel_struct.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_tensor
/// @{

///
/// Kestrel primitive type
///
typedef enum {
        /// obscure bytes (e.g. encoded JPEG)
        KESTREL_BYTE = 0,
        /// boolean (1-byte)
        KESTREL_BOOL = 1,
        /// 8-bit signed integer
        KESTREL_INT8 = 11,
        /// 8-bit signed integer
        KESTREL_INT8x2 = 12,
        /// 8-bit signed integer
        KESTREL_INT8x3 = 13,
        /// 8-bit signed integer
        KESTREL_INT8x4 = 14,
        /// 16-bit signed integer
        KESTREL_INT16 = 21,
        /// 16-bit signed integer
        KESTREL_INT16x2 = 22,
        /// 16-bit signed integer
        KESTREL_INT16x3 = 23,
        /// 16-bit signed integer
        KESTREL_INT16x4 = 24,
        /// 32-bit signed integer
        KESTREL_INT32 = 31,
        /// 32-bit signed integer
        KESTREL_INT32x2 = 32,
        /// 32-bit signed integer
        KESTREL_INT32x3 = 33,
        /// 32-bit signed integer
        KESTREL_INT32x4 = 34,
        /// 64-bit signed integer
        KESTREL_INT64 = 4,
        /// 8-bit unsigned integer
        KESTREL_UINT8 = 51,
        /// 8-bit unsigned integer
        KESTREL_UINT8x2 = 52,
        /// 8-bit unsigned integer
        KESTREL_UINT8x3 = 53,
        /// 8-bit unsigned integer
        KESTREL_UINT8x4 = 54,
        /// 16-bit unsigned integer
        KESTREL_UINT16 = 61,
        /// 16-bit unsigned integer
        KESTREL_UINT16x2 = 62,
        /// 16-bit unsigned integer
        KESTREL_UINT16x3 = 63,
        /// 16-bit unsigned integer
        KESTREL_UINT16x4 = 64,
        /// 32-bit unsigned integer
        KESTREL_UINT32 = 71,
        /// 32-bit unsigned integer
        KESTREL_UINT32x2 = 72,
        /// 32-bit unsigned integer
        KESTREL_UINT32x3 = 73,
        /// 32-bit unsigned integer
        KESTREL_UINT32x4 = 74,
        /// 64-bit unsigned integer
        KESTREL_UINT64 = 8,
        /// 16-bit floating point real number
        KESTREL_FLOAT16 = 91,
        /// 16-bit floating point real number
        KESTREL_FLOAT16x2 = 92,
        /// 16-bit floating point real number
        KESTREL_FLOAT16x3 = 93,
        /// 16-bit floating point real number
        KESTREL_FLOAT16x4 = 94,
        /// 32-bit floating point real number
        KESTREL_FLOAT32 = 101,
        /// 32-bit floating point real number
        KESTREL_FLOAT32x2 = 102,
        /// 32-bit floating point real number
        KESTREL_FLOAT32x3 = 103,
        /// 32-bit floating point real number
        KESTREL_FLOAT32x4 = 104,
        /// 64-bit floating point real number
        KESTREL_FLOAT64 = 111,
        /// 64-bit floating point real number
        KESTREL_FLOAT64x2 = 112,
        /// 64-bit floating point real number
        KESTREL_FLOAT64x3 = 113,
        /// 64-bit floating point real number
        KESTREL_FLOAT64x4 = 114,
        /// 32-bit complex number
        KESTREL_COMPLEX32 = 121,
        /// 32-bit complex number
        KESTREL_COMPLEX32x2 = 122,
        /// 32-bit complex number
        KESTREL_COMPLEX32x3 = 123,
        /// 32-bit complex number
        KESTREL_COMPLEX32x4 = 124,
        /// 64-bit complex number
        KESTREL_COMPLEX64 = 141,
        /// 128-bit complex number
        KESTREL_COMPLEX128 = 151
} kestrel_data_type_e;

///
/// Max length of tensor name
///
#define TENSOR_NAME_MAX_LEN (63)

///
/// Max dimensions of tensor
///
#define TENSOR_MAX_NDIMS (6)

///
/// Kestrel tensor meta information struct definition
///
typedef struct kestrel_tensor_meta_t {
        /** Tensor element type */
        kestrel_data_type_e elem_type;
        /** Number of dimension */
        size_t dims_num;
        /** Dimension array, order: n,c,h,w */
        size_t dims[TENSOR_MAX_NDIMS];
        /** Stride size for each dimension, call kestrel_tensor_generate_contiguous_shape() for
         * contiguous tensor */
        size_t strides[TENSOR_MAX_NDIMS];
} kestrel_tensor_meta_t;

///
/// Kestrel tensor struct definition
///
typedef struct kestrel_tensor_t {
        /** Tensor name */
        char name[TENSOR_NAME_MAX_LEN + 1];
        /** Tensor meta info */
        kestrel_tensor_meta_t meta;
        /** Raw tensor data, pointer to somewhere in buffer */
        uint8_t *data;
        /** Payload buffer */
        kestrel_buffer buffer;
} kestrel_tensor_t;

/// @brief Calculate tensor strides as a contiguous shape
/// @param[in] elem_type Tensor element type
/// @param[in] dims_num Tensor dimension number
/// @param[in] dims Tensor dimensions
/// @return Contiguous tensor shape
KESTREL_API
kestrel_tensor_meta_t kestrel_tensor_generate_contiguous_shape(kestrel_data_type_e elem_type,
                                                               size_t dims_num,
                                                               const size_t *dims);

/// @brief Get data type element size
/// @param[in] t Data element type
/// @return Size of data type element in terms of bytes
KESTREL_API
size_t kestrel_data_type_size(kestrel_data_type_e t);

/// @brief Get tensor element count
/// @param[in] shape Meta information of tensor
/// @return Tensor element count, or 0 for error
KESTREL_API
size_t kestrel_tensor_count(const kestrel_tensor_meta_t *shape);

/// @brief Get tensor buffer capacity in terms of byte
/// @param[in] shape Meta information of tensor
/// @return Tensor buffer capacity, or 0 for error
KESTREL_API
size_t kestrel_tensor_capacity(const kestrel_tensor_meta_t *shape);

/// @brief Construct a tensor according to given tensor meta info and external data
/// @param[in] name Name of tensor
/// @param[in] shape Meta information of tensor
/// @param[in] data External data pointer
/// @param[in] type Shadow memory on device or host.
/// @param[in] finalizer Custom finalizer function.
/// @param[in] finalizer_ud User data for finalizer function.
/// @return Tensor structure pointer
KESTREL_API
kestrel_tensor_t *kestrel_tensor_make(const char *name, kestrel_tensor_meta_t shape, void *data,
                                      kestrel_mem_type_e type, kestrel_buf_finalizer finalizer,
                                      void *finalizer_ud);

/// @brief Alloc a tensor according to given tensor meta info
/// @param[in] name Name of tensor
/// @param[in] shape Meta information of tensor
/// @param[in] type Allocate tensor memory on device or host.
/// @return Tensor structure pointer
KESTREL_API
kestrel_tensor_t *kestrel_tensor_alloc(const char *name, kestrel_tensor_meta_t shape,
                                       kestrel_mem_type_e type);

/// @brief Get tensor memory type
/// @param[in] tensor Pointer to tensor going to inspect.
/// @return Buffer memory type
KESTREL_API
kestrel_mem_type_e kestrel_tensor_mem_type(const kestrel_tensor_t *tensor);

/// @brief Copy tensor
/// @param[in] src Tensor to be copied
/// @param[in] dst Dst tensor which will copy to
/// @return KESTREL_OK for succeed, otherwise return error code
KESTREL_API
k_err kestrel_tensor_copy(const kestrel_tensor_t *src, kestrel_tensor_t *dst);

/// @brief Reference a tensor
/// @param[in] t Tensor to be ref
/// @return Ref tensor structure pointer
KESTREL_API
kestrel_tensor_t *kestrel_tensor_ref(kestrel_tensor_t *t);

/// @brief Reference a tensor
/// @param[in] in Source tensor.
/// @param[in] range_num Num of range.
/// @param[in] ranges Ranges.
/// @return A new tensor which has a reference frame data buffer form tensor `in`, the ROIed
/// tensor also should be freed using kestrel_tensor_free().
/// @note ROIed tensor is referenced from origin frame, and careful if you are going to modify its
/// data
KESTREL_API
kestrel_tensor_t *kestrel_tensor_roi(kestrel_tensor_t *t, int32_t range_num,
                                     const kestrel_range_t ranges[]);

KESTREL_API
k_err kestrel_tensor_reset(kestrel_tensor_t *t, int8_t val);

/// @brief Reshape tensor
/// @param[in] t Tensor to be reshape
/// @param[in] shape Tensor destination shape
/// @return KESTREL_OK for succeed, otherwise return error code
KESTREL_API k_err kestrel_tensor_reshape(kestrel_tensor_t *t, kestrel_tensor_meta_t shape);

/// @brief Calculate data offset position in tensor
/// @param[in] shape Tensor shape
/// @param[in] n Number dims indices
/// @param[in] c Channel dims indices
/// @param[in] h Height dims indices
/// @param[in] w Width dims indices
/// @return Offset of specified position data, in terms of element type
KESTREL_API
size_t kestrel_tensor_calc_offset(const kestrel_tensor_meta_t *shape, size_t n, size_t c,
                                  size_t h, size_t w);

/// @brief Calculate data offset position in tensor from full indices
/// @param[in] shape Tensor shape
/// @param[in] indices Indices array
/// @return Offset of specified position data, in terms of element type
KESTREL_API
size_t kestrel_tensor_calc_offset_ex(const kestrel_tensor_meta_t *shape,
                                     const size_t indices[TENSOR_MAX_NDIMS]);

/// @brief Get specified data address in tensor
/// @param[in] t Tensor to inspect
/// @param[in] n Number dims indices
/// @param[in] c Channel dims indices
/// @param[in] h Height dims indices
/// @param[in] w Width dims indices
/// @return Pointer of specified tensor data, should be used as
/// an element type pointer, NULL for error
KESTREL_API
void *kestrel_tensor_data_at(const kestrel_tensor_t *t, size_t n, size_t c, size_t h, size_t w);

/// @brief Get specified data address in tensor from calculated offset
/// @param[in] t Tensor to inspect
/// @param[in] offset Data offset, in terms of element type
/// @return Pointer of specified tensor data, should be used as
/// an element type pointer, NULL for error
KESTREL_API
void *kestrel_tensor_data_at_ex(const kestrel_tensor_t *t, size_t offset);

/// @brief Check tensor shape is contiguous or not
/// @param[in] shape Tensor shape
/// @return 1 for contiguous, 0 for not
KESTREL_API
int32_t kestrel_tensor_is_contiguous(const kestrel_tensor_meta_t *shape);

/// @brief Convert input tensor to contiguous tensor
/// @param[in] t Tensor to be converted
/// @return KESTREL_OK for succeed, otherwise return error code
KESTREL_API
k_err kestrel_tensor_contiguous(kestrel_tensor_t *t);

/// @brief Get data pointer of tensor
/// @param[in] t Tensor to be inspect
/// @return Pointer of tensor data, NULL for error
KESTREL_API
void *kestrel_tensor_raw_pointer(const kestrel_tensor_t *t);

/// @brief Duplicate tensor
/// @param[in] src Tensor to be duplicated
/// @param[in] dst_mem_type Is duplicate to device memory or not
/// @return Pointer of tensor data, NULL for error
KESTREL_API
kestrel_tensor_t *kestrel_tensor_duplicate(const kestrel_tensor_t *src,
                                           kestrel_mem_type_e dst_mem_type);

/// @brief Release a tensor
/// @param[in,out] tensor Pointer to tensor going to release.
KESTREL_API
void kestrel_tensor_free(kestrel_tensor_t **tensor);

/// @}

#ifdef __cplusplus
}
#endif

#endif
