#ifndef KESTREL_KESTREL_PACKET_H
#define KESTREL_KESTREL_PACKET_H

#include <kestrel/kestrel_buffer.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_packet
/// @{

///
/// Packet flag which indicates the packet contains a keyframe
///
#define KESTREL_PKT_FLAG_KEY 0x0001

///
/// Packet flag used to indicate packets that contain frames that can be discarded by the decoder
/// I.e. Non-reference frames
///
#define KESTREL_PKT_FLAG_DISPOSABLE 0x0010

///
/// Kestrel packet struct definition
///
typedef struct kestrel_packet_t {
        /** Raw packet data */
        uint8_t *data;
        /** Raw packet data size in terms of byte */
        int32_t size;
        /** Frame source stream ID */
        int32_t stream_id;
        /**
         * Presentation timestamp in Stream->time_base units; the time at which
         * the decompressed packet will be presented to the user.
         */
        int64_t pts;
        /**
         * Decompression timestamp in Stream->time_base units; the time at which
         * the packet is decompressed.
         */
        int64_t dts;
        /** A combination of KESTREL_PKT_FLAG_XXX values */
        int32_t flags;
        /** Actural data carrier */
        kestrel_buffer buffer;
} kestrel_packet_t;

/// @brief Allocate a packet
/// @param[in] size Packet data size in terms of byte
/// @param[in] stream_id Stream ID of packet
/// @param[in] pts Presentation timestamp
/// @param[in] dts Decompression timestamp
/// @param[in] flags A combination of KESTREL_PKT_FLAG_XXX values
/// @return A packet following provided parameters, should be freed using kestrel_packet_free().
KESTREL_API
kestrel_packet_t *kestrel_packet_alloc(int32_t size, int32_t stream_id, int64_t pts, int64_t dts,
                                       int32_t flags);

/// @brief Make a packet with existed memory
/// @param[in] data Memory pointer.
/// @param[in] size Packet data size in terms of byte
/// @param[in] stream_id Stream ID of packet
/// @param[in] pts Presentation timestamp
/// @param[in] dts Decompression timestamp
/// @param[in] flags A combination of KESTREL_PKT_FLAG_XXX values
/// @param[in] finalizer Custom finalizer function, could be `NULL` which indicates do not
/// free.
/// @param[in] ud User data for finalizer function.
/// @return A packet following provided parameters, should be freed using
/// kestrel_packet_free().
KESTREL_API
kestrel_packet_t *kestrel_packet_make(uint8_t *data, int32_t size, int32_t stream_id, int64_t pts,
                                      int64_t dts, int32_t flags, kestrel_buf_finalizer finalizer,
                                      void *ud);

/// @brief Reference a packet
/// @param[in] in Source packet.
/// @return A new packet which has a reference packet data buffer form packet `in`, the referenced
/// packet also should be freed using kestrel_packet_free().
/// @note Referenced packet shares data memory with origin packet, usually we won't modify the
/// packet data.
KESTREL_API
kestrel_packet_t *kestrel_packet_ref(kestrel_packet_t *in);

/// @brief Get packet's reference count
/// @param[in] in Source packet.
/// @return Reference count of packet.
KESTREL_API
int32_t kestrel_packet_get_ref_cnt(kestrel_packet_t *in);

/// @brief Release packet
/// @param[in,out] packet Packet which is going to be freed.
KESTREL_API
void kestrel_packet_free(kestrel_packet_t **packet);

/// @}

#ifdef __cplusplus
}
#endif

#endif
