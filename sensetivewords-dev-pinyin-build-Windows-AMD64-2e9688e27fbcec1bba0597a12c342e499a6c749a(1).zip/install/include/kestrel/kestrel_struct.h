#ifndef KESTREL_KESTREL_STRUCT_H
#define KESTREL_KESTREL_STRUCT_H

#include <kestrel_core/kestrel_define.h>
#include <kestrel/kestrel_buffer.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_struct
/// @{

///
/// Max string length of fourcc string
///
#define KESTREL_FOURCC_MAX_STRING_SIZE (32)

///
/// FOURCC maker
///
#define KESTREL_MAKEFOURCC(a, b, c, d) ((a) | ((b) << 8) | ((c) << 16) | ((unsigned)(d) << 24))

#define KESTREL_INVALID_FOURCC (0)

// keson_type
// 0
#define KESON_EXT_TYPE_BEGIN 1

#define KESON_FEATURE 1
#define KESON_BUFFER 2
#define KESON_PACKET 3
#define KESON_FRAME 4
#define KESON_TENSOR 5
#define KESON_MODEL 6
#define KESON_PLUGIN 7
#define KESON_POINT2I 8
#define KESON_POINT2F 9
#define KESON_SIZE2D 10
#define KESON_AREA2D 11
#define KESON_ARRAY 12
#define KESON_WSTRING 13

#define KESON_EXT_TYPE_END 64

// 64
#define KESON_BASIC_TYPE_BEGIN 64

#define KESON_POINTER 64
#define KESON_INT8 65
#define KESON_INT16 66
#define KESON_INT32 67
#define KESON_INT64 68
#define KESON_UINT8 69
#define KESON_UINT16 70
#define KESON_UINT32 71
#define KESON_UINT64 72
#define KESON_FLOAT16 73
#define KESON_FLOAT32 74
#define KESON_FLOAT64 75

#define KESON_BASIC_TYPE_END 76

// 128 - 254
// User Defined Data Type

///
/// Keson wchar definition
///
#ifdef KESTREL_OS_WINDOWS
typedef uint16_t kestrel_wchar_t;
#else
typedef uint32_t kestrel_wchar_t;
#endif

///
/// Kestrel range struct definition
///
typedef struct kestrel_range_t {
        int32_t start;
        int32_t end;
} kestrel_range_t;

///
/// Kestrel integer 2D point struct definition
///
typedef struct kestrel_point2d_t {
        /** X coordinate */
        int32_t x;
        /** Y coordinate */
        int32_t y;
} kestrel_point2d_t;

///
/// Kestrel float 2D point struct definition
///
typedef struct kestrel_point2df_t {
        /** X coordinate */
        float x;
        /** Y coordinate */
        float y;
} kestrel_point2df_t;

///
/// Kestrel 2D size struct definition
///
typedef struct kestrel_size2d_t {
        /** Area width */
        int32_t width;
        /** Area Height */
        int32_t height;
} kestrel_size2d_t;

///
/// Kestrel 2D area struct definition
///
typedef struct kestrel_area2d_t {
        /** Area start coordination X */
        int32_t left;
        /** Area start coordination Y */
        int32_t top;
        /** Area width */
        int32_t width;
        /** Area Height */
        int32_t height;
} kestrel_area2d_t;

typedef void (*kestrel_array_data_finalizer)(void *ud);
///
/// Kestrel Array struct definition
///
typedef struct kestrel_array_t {
        /** Keson code */
        uint8_t keson_code;
        /** Number of elements */
        size_t element_count;
        /** size of element */
        size_t element_size;
        /** Pointer to somewhere in buffer */
        uint8_t *data;
        /** Payload buffer */
        kestrel_buffer buffer;
} kestrel_array_t;

///
/// Kestrel feature struct definition
///
typedef struct kestrel_feature_t {
        /** Feature version */
        int32_t version;
        /** Feature dims */
        int32_t dims;
        /** Raw feature data, pointer to somewhere in buffer */
        float *feature;
        /** Payload buffer */
        kestrel_buffer buffer;
} kestrel_feature_t;

/// @brief Create a feature with data size
/// @param[in] dims Data size in bytes
/// @return Created feature with any type or NULL
KESTREL_API
kestrel_feature_t *kestrel_feature_alloc(size_t dims);

KESTREL_API
kestrel_feature_t *kestrel_feature_make(size_t dims, float *data, kestrel_buf_finalizer finalizer,
                                        void *ud);

/// @brief Reference a kestrel_feature
/// @param[in] in Source frame.
/// @return A new kestrel_feature which has a reference kestrel_feature data buffer form
/// kestrel_feature `in`'s, the referenced kestrel_feature also should be freed using
/// kestrel_feature_free().
/// @note Referenced kestrel_feature shares data memory with origin kestrel_feature, be
/// careful if you are going to modify its payload data.
KESTREL_API
kestrel_feature_t *kestrel_feature_ref(kestrel_feature_t *in);

KESTREL_API
kestrel_feature_t *kestrel_feature_duplicate(kestrel_feature_t *in);

/// @brief Free a feature created by kestrel_feature_alloc()
/// @param[in,out] feature Feature pointer going to be freed
KESTREL_API
void kestrel_feature_free(kestrel_feature_t **feature);

/// @brief Get feature dimension
/// @param[in] feature Feature going to be inspected
/// @return Feature dimension or -1
KESTREL_API
int32_t kestrel_feature_dimension(kestrel_feature_t *feature);

/// @brief Get feature magnitude
/// @param[in] feature Feature going to be inspected
/// @return Feature magnitude or 0.0F
KESTREL_API
float kestrel_feature_magnitude(kestrel_feature_t *feature);

/// @brief Calculate two features distance
/// @param[in] feature1 First input feature
/// @param[in] feature2 Second input feature
/// @return Feature distance, negative value indicates error
/// @note Any input feature is NULL, or two feature has different dimension will returns error
/// @note Comparing two features with different version, it returns normally, but output a warning
KESTREL_API
float kestrel_feature_distance(kestrel_feature_t *feature1, kestrel_feature_t *feature2);

/// @brief Calculate two normalized features distance
/// @param[in] feature1 First input normalized feature
/// @param[in] feature2 Second input normalized feature
/// @return Feature distance, negative value indicates error
/// @note Any input feature is NULL, or two feature has different dimension will returns error
/// @note Comparing two features with different version, it returns normally, but output a warning
/// @note The user should guarantee two input features is normalized, since function do not check
/// it
KESTREL_API
float kestrel_feature_distance_normalized(kestrel_feature_t *feature1,
                                          kestrel_feature_t *feature2);

/// @brief Create a kestrel array with data size
/// @param[in] keson_code keson ext value code
/// @param[in] element_size Element size
/// @param[in] element_count Element count
/// @return Created kestrel_array_t* or NULL
/// @note This function allocate a kestrel_array,
KESTREL_API
kestrel_array_t *kestrel_array_alloc(uint8_t keson_code, size_t element_size,
                                     size_t element_count);

/// @brief create a kestrel array with data
KESTREL_API
kestrel_array_t *kestrel_array_make(uint8_t keson_code, size_t element_size, size_t element_count,
                                    void *data, kestrel_buf_finalizer finalizer, void *ud);

/// @brief Reference a kestrel_array
/// @param[in] in Source frame.
/// @return A new kestrel_array which has a reference kestrel_array data buffer form kestrel_array
/// `in`'s, the referenced kestrel_array also should be freed using kestrel_array_free().
/// @note Referenced kestrel_array shares data memory with origin kestrel_array, be careful if you
/// are going to modify its payload data.
KESTREL_API
kestrel_array_t *kestrel_array_ref(kestrel_array_t *in);

KESTREL_API
kestrel_array_t *kestrel_array_duplicate(kestrel_array_t *in);

/// @brief Free a kestrel_array created by kestrel_array_alloc()
/// @param[in,out] array kestrel_array pointer going to be freed
KESTREL_API
void kestrel_array_free(kestrel_array_t **array);

/// @brief Get length of zero terminated wstring, Similar to strlen(), wcslen()
/// @param[in] wstring
/// @return[in] the number of units in wstring
KESTREL_API
size_t kestrel_wstring_strlen(const kestrel_wchar_t *wstring);

/// @brief Convert an wstring to an UTF-8 string.
/// Encoding of the wstring must be UTF-16 on windows, UTF-32 on other platforms
/// @param[in] wstring wstring
/// @param[in] wstring_len input wstring length(number of kestrel_wchar_t s)
/// @param[out] u8 UTF-8 string buffer, if NULL, will `malloc()` a buffer.
/// @param[in,out] u8_len UTF-8 string buffer size, stores bytes written on return
/// @return returns output buffer on success or NULL on failure
KESTREL_API
uint8_t *kestrel_wsting_to_u8(const kestrel_wchar_t *wstring, size_t wstring_len, uint8_t *u8,
                              size_t *u8_len);

/// @brief Convert an UTF-8 string to an wstring.
/// @param[in] u8 input zero terminated UTF-8 string
/// @param[in] u8_len input UTF-8 string length(number of bytes)
/// @param[out] wstring wstring buffer, if NULL, will `malloc()` a buffer
/// @param[in,out] wstring_len wstring output buffer size, stores kestrel_wchar_t written on
/// return
/// @return returns output buffer on success or NULL on failure
KESTREL_API
kestrel_wchar_t *kestrel_u8_to_wstring(const uint8_t *u8, size_t u8_len, kestrel_wchar_t *wstring,
                                       size_t *wstring_len);

/// @}

#ifdef __cplusplus
}
#endif

#endif
