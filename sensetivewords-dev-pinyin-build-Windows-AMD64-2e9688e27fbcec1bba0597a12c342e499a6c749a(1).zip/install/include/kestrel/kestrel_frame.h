#ifndef KESTREL_KESTREL_FRAME_H
#define KESTREL_KESTREL_FRAME_H

#include <kestrel/kestrel_buffer.h>
#include <kestrel/kestrel_mempool.h>
#include <kestrel/kestrel_struct.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_frame
/// @{

///
/// Automatic image stride computing, align to `1`
///
#define KESTREL_AUTO_STEP (0)

///
/// Frame type definition
///
typedef enum kestrel_frame_type_e {
        /** Flush frame for EOF */
        KESTREL_FLUSH_FRAME = -2,
        /** Unknow frame type */
        KESTREL_UNKNOWN_FRAME = -1,
        /** Video frame type */
        KESTREL_VIDEO_FRAME,
        /** Audio frame type */
        KESTREL_AUDIO_FRAME
} kestrel_frame_type_e;

///
/// frame format enumerations
///
typedef enum kestrel_video_format_e {
        /** Unknown pixel format type */
        KESTREL_VIDEO_NONE = KESTREL_INVALID_FOURCC,
        /** Gray pixel format */
        KESTREL_VIDEO_GRAY = KESTREL_MAKEFOURCC('G', 'R', 'E', 'Y'),
        /** BGR pixel format */
        KESTREL_VIDEO_BGR = KESTREL_MAKEFOURCC('B', 'G', 'R', 24),
        /** BGRA pixel format */
        KESTREL_VIDEO_BGRA = KESTREL_MAKEFOURCC('B', 'G', 'R', 'A'),
        /** RGB pixel format */
        KESTREL_VIDEO_RGB = KESTREL_MAKEFOURCC('R', 'G', 'B', 24),
        /** ARGB pixel format */
        KESTREL_VIDEO_ARGB = KESTREL_MAKEFOURCC('A', 'R', 'G', 'B'),
        /** YUV pixel format */
        KESTREL_VIDEO_YU12 = KESTREL_MAKEFOURCC('Y', 'U', '1', '2'),
        /** NV12 pixel format */
        KESTREL_VIDEO_NV12 = KESTREL_MAKEFOURCC('N', 'V', '1', '2'),
        /** NV21 pixel format */
        KESTREL_VIDEO_NV21 = KESTREL_MAKEFOURCC('N', 'V', '2', '1'),
        /** GREY16, big-endian */
        KESTREL_VIDEO_GRAY16LE = KESTREL_MAKEFOURCC('Y', '1', 0, 16),
        /** GREY16, little-endian */
        KESTREL_VIDEO_GRAY16BE = KESTREL_MAKEFOURCC(16, 0, '1', 'Y'),
        /** ARM lossless image compression protocol */
        KESTREL_VIDEO_AFBC = KESTREL_MAKEFOURCC('A', 'F', 'B', 'C')
} kestrel_video_format_e;

///
/// Audio format enumerations
///
typedef enum kestrel_audio_format_e {
        /** Unknown pixel format type */
        KESTREL_AUDIO_NONE = -1,
        /** Audio frame format signed 16 bits */
        KESTREL_AUDIO_S16
} kestrel_audio_format_e;

///
/// Video parameter definition
///
typedef struct kestrel_video_param_t {
        /** Video frame format */
        kestrel_video_format_e fmt;
        /** Width of frame in pixel */
        int32_t width;
        /** Height of frame in pixel */
        int32_t height;
        /** Stride of frame in bytes */
        int32_t stride[4];
} kestrel_video_param_t;

///
/// Audio parameter definition
///
typedef struct kestrel_audio_param_t {
        /** Audio frame format */
        kestrel_audio_format_e fmt;
        /** Audio sample rate */
        int32_t sample_rate;
        /** Audio channel number */
        int32_t channels;
        /** Audio sample number of each channel */
        int32_t samples_per_channel;
        /** Audio sample depth in bit */
        int32_t sample_bits;
} kestrel_audio_param_t;

///
/// Frame parameter definition
///
typedef struct kestrel_codec_param_t {
        /** Frame type */
        kestrel_frame_type_e type;
        /** Video frame parameters */
        kestrel_video_param_t video;
        /** Audio frame parameters */
        kestrel_audio_param_t audio;
} kestrel_codec_param_t;

///
/// Kestrel frame struct definition
///
typedef struct kestrel_frame_t {
        /** Frame type */
        kestrel_frame_type_e type;
        /** Video frame parameters */
        kestrel_video_param_t video;
        /** Audio frame parameters */
        kestrel_audio_param_t audio;
        /** Number of plane */
        size_t plane_num;
        /** Pointer to somewhere in frame.buffer */
        uint8_t *plane[4];
        /** Frame source stream ID */
        int64_t stream_id;
        /** Timestamp */
        int64_t pts;
        /** Frame buffer */
        kestrel_buffer buffer;
        /** Extra Info */
        kestrel_buffer extra_info;
} kestrel_frame_t;

/// @brief Get pixel size of given format
/// @param[in] fmt Frame format, KESTREL_VIDEO_XXX.
/// @return Pixel size in bytes
KESTREL_API
size_t kestrel_frame_pixel_size(kestrel_video_format_e fmt);

/// @brief Get plane number of given format
/// @param[in] fmt Frame format, KESTREL_VIDEO_XXX.
/// @return Plane number
KESTREL_API
size_t kestrel_frame_plane_num(kestrel_video_format_e fmt);

/// @brief Convert a pixel format type to string
/// @param[in] fmt Frame format, KESTREL_VIDEO_XXX.
/// @return Fmt string, literal values no free
KESTREL_API
const char *kestrel_frame_pixfmt_to_string(kestrel_video_format_e fmt);

/// @brief Convert string to pixel format type
/// @param[in] fourcc Pixel format in line with FourCC.
/// @return Pixel format type
KESTREL_API
kestrel_video_format_e kestrel_frame_string_to_pixfmt(const char *fourcc);

/// @brief Allocate a frame
/// @param[in] type Memory type which indicates wether data is on device manage or host.
/// @param[in] fmt Frame format, KESTREL_VIDEO_XXX.
/// @param[in] w Frame width.
/// @param[in] h Frame Height.
/// @param[in] strides Frame strides in bytes, if `KESTREL_AUTO_STEP`, stride will compute inner.
/// @param[in] pts Frame timestamp.
/// @return A frame following provided parameters, should be freed using kestrel_frame_free().
/// @note The frame raw data might be padded, use stride for data retrieve.
/// @note For YUV frame (NV12, NV21, YU12), chromas' stride may different from luminance, like:
/// ```
/// NV12 or NV21
/// |----- luminance stride -----|
/// ----------------------+-------
/// | YYY...              |      |
/// |                     |      |
/// |                     |      |
/// |                     |      |
/// ----------------------+-------
/// | UVUVUV...           |   |
/// |                     |   |
/// ----------------------+----
/// |----- chroma stride -----|
///
/// YU12
/// |----- luminance stride -----|
/// ----------------------+-------
/// | YYY...              |      |
/// |                     |      |
/// |                     |      |
/// |                     |      |
/// ----------------------+-------
/// | UUU...   |   |
/// |          |   |
/// -----------+----
/// |-- U stride --|
/// -----------+------
/// | VVV...   |     |
/// |          |     |
/// -----------+------
/// |--- V stride ---|
///
/// ```
KESTREL_API
kestrel_frame_t *kestrel_frame_alloc(kestrel_mem_type_e type, kestrel_video_format_e fmt,
                                     int32_t w, int32_t h, const int32_t strides[4], int64_t pts);

/// @brief Make a frame with existed memory
/// @param[in] type Memory type which indicates wether data is on device manage or host.
/// @param[in] fmt Frame format, KESTREL_VIDEO_XXX.
/// @param[in] data Frame raw data
/// @param[in] w Frame width.
/// @param[in] h Frame Height.
/// @param[in] strides Frame strides in bytes, if `KESTREL_AUTO_STEP`, stride will compute inner.
/// @param[in] pts Frame timestamp.
/// @param[in] finalizer Custom finalizer function, could be `NULL` which indicates do not
/// free.
/// @param[in] ud User data for finalizer function.
/// @return A frame following provided parameters, should be freed using kestrel_frame_free().
/// @note For multi-plane image (NV12, NV21, YU12), each plane must be contiguous.
KESTREL_API
kestrel_frame_t *kestrel_frame_make(kestrel_mem_type_e type, kestrel_video_format_e fmt,
                                    uint8_t *data, int32_t w, int32_t h, const int32_t strides[4],
                                    int64_t pts, kestrel_buf_finalizer finalizer, void *ud);

/// @brief Get memory type of a frame
/// @param[in] frame Frame pointer going to inspect.
/// @return Buffer memory type
KESTREL_API
kestrel_mem_type_e kestrel_frame_mem_type(const kestrel_frame_t *frame);

/// @brief Attach a data section with frame
/// @param[in] frame Source frame which is going to attach extra information.
/// @param[in] buf Attaching data buffer.
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note Attached buffer will be referenced.
/// @note Frames which have attached extra information, could not attach again, unless you
/// detach current extra information first.
/// @note The attached buffer will also be referenced  when kestrel_frame_ref(), and be duplicated
/// when kestrel_frame_copy() / kestrel_frame_copy_async() / kestrel_frame_upload()
/// /kestrel_frame_upload_async() / kestrel_frame_download() / kestrel_frame_download_async().
/// @note The attached buffer as a side-data of a frame, won't be auto upload/download, when
/// calling frame upload/download APIs, do it manually if necessary.
KESTREL_API
k_err kestrel_frame_attach_extra_info(kestrel_frame_t *frame, kestrel_buffer buf);

/// @brief Get attaching data buffer
/// @param[in] frame Source frame which is going to get attached extra information.
/// @return Attached buffer.
KESTREL_API
kestrel_buffer kestrel_frame_get_extra_info(const kestrel_frame_t *frame);

/// @brief Detach a data buffer with frame
/// @param[in] frame Source frame which is going to detach extra information.
/// @return Attached buffer.
KESTREL_API
kestrel_buffer kestrel_frame_detach_extra_info(kestrel_frame_t *frame);

/// @brief infer frame buffer size
/// @param[in] fmt Frame format, KESTREL_VIDEO_XXX.
/// @param[in] w Frame width.
/// @param[in] h Frame Height.
/// @param[in] strides Frame strides in bytes, if `KESTREL_AUTO_STEP`, stride will compute inner.
/// @return Inferred size in bytes.
KESTREL_API
size_t kestrel_frame_inferred_size(kestrel_video_format_e fmt, int32_t w, int32_t h,
                                   const int32_t strides[4]);

/// @brief frame size
/// @param[in] frame Source frame.
/// @return frame size in bytes.
/// @note frame size calculated by height and stride
KESTREL_API
size_t kestrel_frame_size(const kestrel_frame_t *frame);

/// @brief Check frame planes is contiguous or not
/// @param[in] frame
/// @return 1 for contiguous, 0 for not
KESTREL_API
int32_t kestrel_frame_is_contiguous(const kestrel_frame_t *frame);

/// @brief Reset frame to specific value
/// @param[in] frame Source frame.
/// @param[in] val Reset value, should be 0~255.
/// @return KESTREL_OK for succeed, otherwise failure.
KESTREL_API
k_err kestrel_frame_reset(kestrel_frame_t *frame, uint8_t val);

/// @brief Reference a frame
/// @param[in] frame Source frame.
/// @return A new frame which has a reference frame data buffer form `frame`'s, the
/// referenced frame also should be freed using kestrel_frame_free().
/// @note Referenced frame shares image data memory with origin frame, be careful if you are going
/// to modify its image data.
KESTREL_API
kestrel_frame_t *kestrel_frame_ref(const kestrel_frame_t *frame);

/// @brief Map a frame to opposite device type
/// @param[in] frame Source frame.
/// @return A new frame which is a map frame form `frame`, the mapped frame also should be
/// freed using kestrel_frame_free().
/// @note Mapped frame shares image data memory with origin frame, but has different device type.
/// @note This API requires current binding device supports map/unmap operation, otherwise, it
/// does not work, and returns NULL.
KESTREL_API
kestrel_frame_t *kestrel_frame_map(const kestrel_frame_t *frame);

/// @brief Reference a frame
/// @param[in] frame Source frame.
/// @param[in] roi Range of interest.
/// @return A new frame which has a reference frame data buffer form `frame`, the ROIed
/// frame also should be freed using kestrel_frame_free().
/// @note ROIed frame is referenced from origin frame, and careful if you are going to modify its.
/// ROIed frame may not be equal to the input roi when frame format is YUV or AFBC format (left
/// , top, width, height is even number) image data
KESTREL_API
kestrel_frame_t *kestrel_frame_roi(const kestrel_frame_t *frame, kestrel_area2d_t roi);

/// @brief Get frame's reference count
/// @param[in] frame Source frame.
/// @return Reference count of frame.
KESTREL_API
int32_t kestrel_frame_get_ref_cnt(const kestrel_frame_t *frame);

/// @brief Copy a frame deeply
/// @param[in] src Source frame.
/// @param[in,out] dst Destination frame. If `*dst` is NULL, a new frame will be returned, else if
/// `*dst` is a frame with enough memory, reform first and copy data from src to dst.
/// @note Heterogeneous memory triggers transition automatically
/// @return KESTREL_OK for succeed, otherwise failure.
KESTREL_API
k_err kestrel_frame_copy(const kestrel_frame_t *src, kestrel_frame_t **dst);

/// @brief Duplicate a frame deeply
/// @param[in] src Source frame.
/// @return Duplicated frame.
KESTREL_API
kestrel_frame_t *kestrel_frame_duplicate(const kestrel_frame_t *src);

KESTREL_API
k_err kestrel_frame_copy_async(const kestrel_frame_t *src, kestrel_frame_t **dst,
                               kestrel_event *e);

/// @brief Download a device frame to host frame
/// @param[in] src Source frame on device.
/// @param[in,out] dst Destination host frame. If `*dst` is NULL, a new frame will be return, else
/// `*dst` must be a host frame in same size and format with `src`, and data buffer is ready.
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note In case of `*dst == NULL`, it will try to map a frame form source frame, if failed, do
/// data transmission as a fallback.
KESTREL_API
k_err kestrel_frame_download(const kestrel_frame_t *src, kestrel_frame_t **dst);

/// @brief Download a device frame to host frame asynchronously
/// Similar with kestrel_frame_download, but asynchronous
/// @param[in] src Source frame on device.
/// @param[in,out] dst Destination host frame. If `*dst` is NULL, a new frame will be return, else
/// `*dst` must be a host frame in same size and format with `src`, and data buffer is ready.
/// @param[out] e Event handle
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note In case of `*dst == NULL`, it will try to map a frame form source frame, if failed, do
/// data transmission as a fallback.
KESTREL_API
k_err kestrel_frame_download_async(const kestrel_frame_t *src, kestrel_frame_t **dst,
                                   kestrel_event *e);

/// @brief Upload a host frame to device frame
/// @param[in] src Source frame on host.
/// @param[in,out] dst Destination frame on device. If `*dst` is NULL, a new frame will be return,
/// else `*dst` must be a device frame in same size and format with `src`, and data buffer is
/// ready.
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note In case of `*dst == NULL`, it will try to map a frame form source frame, if failed, do
/// data transmission as a fallback.
KESTREL_API
k_err kestrel_frame_upload(const kestrel_frame_t *src, kestrel_frame_t **dst);

/// @brief Upload a host frame to device frame asynchronously
/// Similar with kestrel_frame_upload, but asynchronous
/// @param[in] src Source frame on host.
/// @param[in,out] dst Destination frame on device. If `*dst` is NULL, a new frame will be return,
/// else `*dst` must be a device frame in same size and format with `src`, and data buffer is
/// ready.
/// @param[out] e Event handle
/// @return KESTREL_OK for succeed, otherwise failure.
/// @note In case of `*dst == NULL`, it will try to map a frame form source frame, if failed, do
/// data transmission as a fallback.
KESTREL_API
k_err kestrel_frame_upload_async(const kestrel_frame_t *src, kestrel_frame_t **dst,
                                 kestrel_event *e);

/// @brief Wait for done of an asynchronous event
/// @param[in] e Event handle
/// @param[out] dst Destination frame
/// @return KESTREL_OK for succeed, otherwise failure.
KESTREL_API
k_err kestrel_frame_copy_await(kestrel_event e, kestrel_frame_t **dst);

/// @brief Release frame
/// @param[in,out] frame Frame which is going to be freed.
KESTREL_API
void kestrel_frame_free(kestrel_frame_t **frame);

///
/// Frame pool
///
typedef struct kestrel_frame_pool_t *kestrel_frame_pool;

/// @brief Create frame pool
/// @param[in] mem_type memory type
/// @param[in] param frame param
/// @param[in] capacity max frame limit count
/// @return frame pool handle
/// ```
/// +------------------------------------------------+
/// |             pool_size / capacity               |
/// +------------------------------------------------+
/// |          allocated                |            |
/// +------------------------------------------------+
/// |      usage        |               |            |
/// +------------------------------------------------+
/// ```
///
KESTREL_API
kestrel_frame_pool kestrel_frame_pool_alloc(kestrel_mem_type_e mem_type,
                                            kestrel_video_param_t param, size_t capacity);

/// @brief Get a frame from frame_pool
/// @param[in] fp frame pool handle
/// @return frame when fp has enough memory, or will return NULL
KESTREL_API
kestrel_frame_t *kestrel_frame_pool_get(kestrel_frame_pool fp);

/// @brief Get frame pool capacity
/// @param[in] fp frame pool handle
/// @return frame pool capacity, definition in kestrel_frame_pool_alloc
KESTREL_API
size_t kestrel_frame_pool_capacity(kestrel_frame_pool fp);

/// @brief Get frame pool allocated frame count
/// @param[in] fp frame pool handle
/// @return frame pool allocated frame count, definition in kestrel_frame_pool_alloc
KESTREL_API
size_t kestrel_frame_pool_allocated(kestrel_frame_pool fp);

/// @brief Get frame pool used frame count
/// @param[in] fp frame pool handle
/// @return frame pool used frame count, definition in kestrel_frame_pool_alloc
KESTREL_API
size_t kestrel_frame_pool_usage(kestrel_frame_pool fp);

/// @brief Get frame pool memory type
/// @param[in] fp frame pool handle
/// @return frame pool memory type
KESTREL_API
kestrel_mem_type_e kestrel_frame_pool_mem_type(kestrel_frame_pool fp);

/// @brief Get frame pool video param
/// @param[in] fp frame pool handle
/// @return frame pool video param
KESTREL_API
kestrel_video_param_t kestrel_frame_pool_video_param(kestrel_frame_pool fp);

/// @brief Destroy frame pool
/// @param[in,out] fp frame pool handle
KESTREL_API
void kestrel_frame_pool_free(kestrel_frame_pool *fp);

/// @brief Get a frame from mem_pool
/// @param pool mem pool handle
/// @param[in] fmt Frame format, KESTREL_VIDEO_XXX.
/// @param[in] w Frame width.
/// @param[in] h Frame Height.
/// @param[in] strides Frame strides in bytes, if `KESTREL_AUTO_STEP`, stride will compute inner.
/// @param[in] pts Frame pts.
/// @return frame when pool has enough memory, or will return NULL
KESTREL_API
kestrel_frame_t *kestrel_mempool_get_frame(kestrel_mempool pool, kestrel_video_format_e fmt,
                                           int32_t w, int32_t h, int32_t strides[4], int64_t pts);

/// @}

#ifdef __cplusplus
}
#endif

#endif
