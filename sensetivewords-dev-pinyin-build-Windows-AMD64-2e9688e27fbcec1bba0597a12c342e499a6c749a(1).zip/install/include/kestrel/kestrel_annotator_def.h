#ifndef KESTREL_KESTREL_ANNOTATOR_DEF_H
#define KESTREL_KESTREL_ANNOTATOR_DEF_H

#include <kestrel_core/kestrel_plugin.h>
#include <kestrel/kestrel_keson.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_annotator
/// @{

///
/// Annotator plug-in type
///
#define KESTREL_ANNOTATOR_PLUGIN (3)

///
/// Kestrel annotator handle definition
///
typedef void *KESTREL_ANNOTATOR;

///
/// Annotator plug-in interface definition
///
typedef struct kestrel_annotator_api_t {
        /** Annotator configuration schema of open_fx */
        const char *config_schema;
        /** Annotator parameter schema of process_fx */
        const char *params_schema;
        /** Annotator result schema of process_fx */
        const char *result_schema;

        /** Open annotator */
        KESTREL_ANNOTATOR (*open_fx)(void *h, const char *config);

        /** Startup configura */
        k_err (*startup_fx)(KESTREL_ANNOTATOR hdl, keson in, keson *out);

        /** Do annotator */
        k_err (*process_fx)(KESTREL_ANNOTATOR hdl, keson in, keson *out);

        /** Destroy context */
        k_err (*terminate_fx)(KESTREL_ANNOTATOR hdl, keson in, keson *out);

        /** Close annotator */
        void (*close_fx)(KESTREL_ANNOTATOR hdl);
} kestrel_annotator_api_t;

#define _CONSTRUCT_API(name)                                                                     \
        static kestrel_annotator_api_t ___##name##_ppi___ = { name##_config,    name##_params,   \
                                                              name##_result,    name##_open,     \
                                                              name##_startup,   name##_process,  \
                                                              name##_terminate, name##_close };

///
/// Annotator plug-in register sugar macro
///
#define REGISTER_ANNOTATOR(name)                                                                 \
        _CONSTRUCT_API(name)                                                                     \
        REGISTER_PLUGIN_WITH_NAME(name, name, KESTREL_ANNOTATOR_PLUGIN, ___##name##_ppi___)

///
/// Annotator plug-in register sugar macro
///
#define REGISTER_ANNOTATOR_WITH_NAME(name, plg_name)                                             \
        _CONSTRUCT_API(name)                                                                     \
        REGISTER_PLUGIN_WITH_NAME(name, plg_name, KESTREL_ANNOTATOR_PLUGIN, ___##name##_ppi___)
/// @}

#ifdef __cplusplus
}
#endif

#endif
