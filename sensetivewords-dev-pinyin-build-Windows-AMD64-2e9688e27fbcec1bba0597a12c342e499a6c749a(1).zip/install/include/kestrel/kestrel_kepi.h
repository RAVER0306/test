#ifndef KESTREL_KESTREL_KEPI_H
#define KESTREL_KESTREL_KEPI_H

#include "kestrel_keson.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_kepi
/// @{
///
/// Kestrel uses Kepi (Kestrel Extension Plug-in Invoke) protocol as data exchange format. It is
/// based on @ref kestrel_keson "KesON".
///
/// # Request
///
/// The Request is a single KesON that has the following members:
///
/// - **id**
///
///   An identifier established by the Caller that **MUST** contain a String or Number value if
///   included. If it is not included it is assumed to be a notification. The value **MUST NOT**
///   be null and Numbers **SHOULD NOT** contain fractional parts. The Plug-in **MUST** reply with
///   the same value in the Response if included. This member is used to correlate the context
///   between the two KesONs.
///
/// ## Notification
///
/// A Notification is a Request without an `id` member. A Notification signifies the Caller's lack
/// of interest in the corresponding Response, and as such no Response needs to be eturned to the
/// caller. The Plug-in **MAY** reply to a Notification, but Kestrel will ignore it.
///
/// Notifications are not confirmable by definition, since they do not have a Response to be
/// returned. As such, the Caller would not be aware of any errors (e.g. "Invalid
/// params"/"Internal error").
///
/// # Response
///
/// When a Kepi call is made, the Plug-in **MUST** reply with a Response. The Response is
/// expressed as a single KesON, with the following members:
///
/// - **result**
///
///   This member is **REQUIRED** on success. This member **MUST NOT** exist if there was an error
///   invoking the method. The value of this member is determined by the Plug-in.
///
/// - **error**
///
///   This member is **REQUIRED** on error. This member **MUST NOT** exist if there was no error
///   triggered during invocation. The value for this member **MUST** be an KesON as defined in
///   subpage `Error Object` that will be mentioned below.
///
/// - **id**
///
///   This member is **REQUIRED** if Request is not a Notification. It **MUST** be the same as the
///   value of the id member in the Request. This member **MUST NOT** exist if Request is a
///   Notification, and Kestrel will discard these Response. If there was an error in detecting
///   the id in the Request (e.g. Invalid Request), Kestrel responses a Error with `id` is null.
///
/// > Either the `result` or `error` member **MUST** be included, but both members **MUST NOT** be
/// > included.
///
/// ## Error Object
///
/// When a Kepi call encounters an error, the Response **MUST** contains an error member which is
/// a KesON with the following members:
///
/// - **code**
///
///   A Number that indicates the error type that occurred. This **MUST** be an integer.
///
/// - **message**
///
///   A String providing a short description of the error. The message **SHOULD** be limited to a
///   concise single sentence.
///
/// The error codes from and including -32768 to -32000 are reserved for pre-defined errors. Any
/// code within this range, but not defined explicitly below is reserved for future use. The error
/// codes are nearly the same as those suggested for
/// [XML-RPC](http://xmlrpc-epi.sourceforge.net/specs/rfc.fault_codes.php):
///
/// | code             | message         | meaning                                             |
/// | :--------------- | :-------------- | :-------------------------------------------------- |
/// | -32600           | Invalid Request | The Kepi sent is not a valid Request.         |
/// | -32602           | Invalid params  | Invalid method parameter(s).                        |
/// | -32603           | Internal error  | Internal error.                                     |
/// | -32000 to -32099 | Plug-in error   | Reserved for implementation-defined plug-in errors. |
///
/// The remainder of the space is available for application defined errors.
///
/// # Batch
///
/// To send several Requests at the same time, the Caller **MAY** send an KesON Array filled with
/// Requests.
///
/// The Plug-in should respond with an KesON Array containing the corresponding Responses, after
/// all of the batch Requests have been processed. A Response **SHOULD** exist for each Request,
/// except that there **SHOULD NOT** be any Response for notifications. The Plug-in **MAY**
/// process a batch Kepi call as a set of concurrent tasks, processing them in any order and with
/// any width of parallelism.
///
/// The Responses being returned from a batch call **MAY** be returned in any order within the
/// KesON Array. The Caller **SHOULD** match contexts between the set of Requests and the
/// resulting set of Responses based on the id member within them.
///
/// If the batch Kepi call itself fails to be recognized as an valid KesON or as an Array with at
/// least one value, Kestrel responses a single Response. If there are no Responses contained
/// within the Response array as it is to be sent to the caller, Kestrel returns nothing at all.
///
/// # Examples
///
/// Syntax:
///
/// ```py
/// --xxx-> Request to Kestrel Plug-in xxx
/// <-xxx-- Response from Kestrel
/// ```
///
/// Kepi call without parameters:
///
/// ```py
/// --version-> {"id": 1}
/// <-version-- {"result": {"version": "1.0.0", "revision": "cd8712b8e5"}, "id": 1}
/// ```
///
/// Kepi call with primitive type parameters:
///
/// ```py
/// --inc-> {"params": 1, "id": 1}
/// <-inc-- {"result": 1, "id": 1}
/// ```
///
/// Kepi call with array parameters:
///
/// ```py
/// --sum-> {"params": [3, 2], "id": 2}
/// <-sum-- {"result": 5, "id": 2}
/// ```
///
/// Kepi call with structured parameters:
///
/// ```py
/// --subtract-> {"subtrahend": 23, "minuend": 42, "id": 3}
/// <-subtract-- {"result": 19, "id": 3}
///
/// --subtract-> {"minuend": 42, "subtrahend": 23, "id": 4}
/// <-subtract-- {"result": 19, "id": 4}
/// ```
///
/// a Notification:
///
/// ```py
/// --update-> {}
/// --update-> {"user": "Kepi"}
/// ```
///
/// Kepi call with invalid KesON:
///
/// ```py
/// --foobar-> {"params": "bar", "baz]
/// <-foobar-- {"error": {"code": -32600, "message": "Invalid Request"}, "id": null}
/// ```
///
/// Kepi call with invalid Request KesON:
///
/// ```py
/// --xxx-> {"array": [1, 2, 3], "id": [dsa]}
/// <-xxx-- {"error": {"code": -32600, "message": "Invalid Request"}, "id": null}
/// ```
///
/// Kepi call Batch, invalid KesON:
///
/// ```py
/// --sum-> [
///   {"params": [1024, 256], "id": "1"},
///   {"params"
/// ]
/// <-sum-- {"error": {"code": -32600, "message": "Invalid Request"}, "id": null}
/// ```
///
/// Kepi call with an empty Array:
///
/// ```py
/// --xxx-> []
/// <-xxx-- {"error": {"code": -32600, "message": "Invalid Request"}, "id": null}
/// ```
///
/// Kepi call with an invalid Batch (but not empty):
///
/// ```py
/// --xxx-> [1]
/// <-xxx-- [
///   {"error": {"code": -32600, "message": "Invalid Request"}, "id": null}
/// ]
/// ```
///
/// Kepi call with invalid Batch:
///
/// ```py
/// --xxx-> [1,2,3]
/// <-xxx-- [
///   {"error": {"code": -32600, "message": "Invalid Request"}, "id": null},
///   {"error": {"code": -32600, "message": "Invalid Request"}, "id": null},
///   {"error": {"code": -32600, "message": "Invalid Request"}, "id": null}
/// ]
/// ```
///
/// Kepi call Batch:
///
/// ```py
/// --echo-> [
///         {"params": "Hello"},
///         {"params": "Kestrel", "id": "1"},
///         {"foo": "boo"},
///         {"array": [1, 2, 3], "id": "5"}
///     ]
/// <-echo-- [
///         {"result": "Kestrel", "id": "1"},
///         {"error": {"code": -32600, "message": "Invalid Request"}, "id": null},
///         {"error": {"code": -32600, "message": "Invalid Request"}, "id": 5},
///     ]
/// ```
///
/// Kepi call Batch (all notifications):
///
/// ```py
/// --update-> [
///         {"params": 1},
///         {"params": 2}
///     ]
/// <-update-- # Nothing is returned for all notification batches
/// ```
///
/// @}

///
/// Parse error, Invalid Keson was received
///
#define KEPI_E_PARSE (-32700)

///
/// Invalid Request, The input Keson is not a valid Request object
///
#define KEPI_E_INVALID_REQ (-32600)

///
/// The method does not exist / is not available
///
#define KEPI_E_METHOD_NOT_FOUND (-32601)

///
/// Invalid parameter(s)
///
#define KEPI_E_INVALID_ARG (-32602)

///
/// Internal error
///
#define KEPI_E_INTERNAL (-32603)

KESTREL_API
void kepi_error(keson req, keson resp, int32_t code, const char *msg);

KESTREL_API
void kepi_error_ex(keson req, keson resp, int32_t code, keson msg_node);

KESTREL_API
void kepi_resp(keson req, keson resp);

#ifdef __cplusplus
}
#endif

#endif