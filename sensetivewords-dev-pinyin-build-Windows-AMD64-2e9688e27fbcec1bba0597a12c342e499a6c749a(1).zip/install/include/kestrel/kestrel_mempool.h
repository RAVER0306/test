#ifndef KESTREL_KESTREL_MEMPOOL_H
#define KESTREL_KESTREL_MEMPOOL_H

#include <kestrel/kestrel_buffer.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_mempool
///
/// Based on @ref kestrel_buffer, Kestrel provides a set of memory pool API, these APIs are
/// thread-safe.
///
/// @{

///
/// Kestrel memory pool structure
///
typedef struct kestrel_mempool_t *kestrel_mempool;

///
/// Default memory pool flags
///
#define KESTREL_MP_FLAG_DEFAULT 0x0

///
/// Enable memory pool thread safe guard
///
#define KESTREL_MP_FLAG_THREAD_SAFE 0x01

/// @brief Allocate a memory pool
/// @param[in] type Allocate pool memory on device or host.
/// @param[in] pool_capacity Total capacity in bytes, if not multiple of granularity, round up.
/// @param[in] granularity Memory patch granularity size.
/// @param[in] flags Memory pool bitmask flags made of the combination of KESTREL_MP_FLAG_XXX
/// @return A memory pool handle, NULL for error.
KESTREL_API
kestrel_mempool kestrel_mempool_alloc(kestrel_mem_type_e type, size_t pool_capacity,
                                      size_t granularity, uint32_t flags);

/// @brief Get memory type of a memory pool
/// @param[in] mempool A memory pool handle create by kestrel_mempool_alloc().
/// @return Buffer memory type
KESTREL_API
kestrel_mem_type_e kestrel_mempool_mem_type(kestrel_mempool mempool);

/// @brief Get memory capacity of a memory pool
/// @param[in] mempool A memory pool handle create by kestrel_mempool_alloc().
/// @return Memory pool capacity in bytes.
KESTREL_API
size_t kestrel_mempool_capacity(kestrel_mempool mempool);

/// @brief Get memory pool granularity
/// @param[in] mempool A memory pool handle create by kestrel_mempool_alloc().
/// @return Memory pool granularity.
KESTREL_API
size_t kestrel_mempool_granularity(kestrel_mempool mempool);

/// @brief Get memory pool usage
/// @param[in] mempool A memory pool handle create by kestrel_mempool_alloc().
/// @return Memory pool usage in bytes
KESTREL_API
size_t kestrel_mempool_usage(kestrel_mempool mempool);

/// @brief Get memory pool idle space
/// @param[in] mempool A memory pool handle create by kestrel_mempool_alloc().
/// @return Memory pool idle in bytes.
KESTREL_API
size_t kestrel_mempool_idle(kestrel_mempool mempool);

/// @brief Get max chunk size in memory pool
/// @param[in] mempool A memory pool handle create by kestrel_mempool_alloc().
/// @return Max chunk size.
KESTREL_API
size_t kestrel_mempool_max_chunk(kestrel_mempool mempool);

/// @brief Get a memory chunk from memory pool
/// @param[in] mempool A memory pool handle create by kestrel_mempool_alloc().
/// @param[in,out] size Required memory chunk size, after invoke, becomes real reqired
/// memory size, in terms of byte.
/// @return A memory pointer, NULL for error.
KESTREL_API
void *kestrel_mempool_get(kestrel_mempool mempool, size_t *size);

/// @brief Put a memory chunk back to memory pool
/// @param[in] mempool A memory pool handle create by kestrel_mempool_alloc().
/// @param[in] mem Memory pointer get by kestrel_mempool_get().
/// @return KESTREL_OK for succeed, otherwise return an error code.
KESTREL_API
k_err kestrel_mempool_put(kestrel_mempool mempool, void *mem);

/// @brief Get a buffer from provided pool
/// @param[in] pool Memory pool handle create by kestrel_mempool_alloc()
/// @param[in] size Buffer size
/// @return A buffer following provided parameters.
/// @note The buffer could be treated as a ordinary buffer, and should be freed by
/// kestrel_buffer_free().
KESTREL_API
kestrel_buffer kestrel_mempool_get_buffer(kestrel_mempool pool, size_t size);

/// @brief Free a memory pool
/// @param[in,out] mempool Pointer to a memory pool handle create by kestrel_mempool_alloc().
/// @note After invoking, mempool is set to `NULL`.
KESTREL_API
void kestrel_mempool_free(kestrel_mempool *mempool);

/// @}

#ifdef __cplusplus
}
#endif

#endif
