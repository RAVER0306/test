#ifndef KESTREL_KESTREL_NN_H
#define KESTREL_KESTREL_NN_H

#include <kestrel_core/kestrel_model.h>
#include "kestrel_nn_def.h"
#include "kestrel_tensor.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_nn
/// @{

///
/// Kestrel neural network backend handle definition
///
typedef struct kestrel_nn_t *kestrel_nn;

/// @brief Create a neural network backend
/// @param[in] nn Neural network backend name to create instance
/// @param[in] m Neural network model file
/// @param[in] net Network package name
/// @param[in] extra_cfg Extra configuration for Network
/// @return A kestrel network handle, or NULL for fail
/// @note This API will try to load `<nn>.kep` if it not been loaded yet
KESTREL_API
kestrel_nn kestrel_nn_create(const char *nn, kestrel_model m, const char *net,
                             const char *extra_cfg);

/// @brief Extend output tensor list of neural network
/// @param[in] nn Kestrel neural network handle
/// @param[in] tensor_name Tensor name of extending blob
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_extend_output(kestrel_nn nn, const char *tensor_name);

/// @brief Prepare neural network
/// @param[in] nn Kestrel neural network handle
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_prepare(kestrel_nn nn);

/// @brief Perform pre-process according to given param
/// @param[in] nn Kestrel neural network handle
/// @param[in] param pre-process parameter
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_preprocess(kestrel_nn nn, kestrel_nn_transform_param param);

/// @brief Get properies of backend instant
/// @param[in] nn Kestrel neural network handle
/// @param[out] properties A user provide pointer to output properties
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_get_properties(kestrel_nn nn, kestrel_nn_properties_t *properties);

/// @brief Get tensor shape by specific name
/// @param[in] nn Kestrel neural network handle
/// @param[in] name Tensor name going to inspect shape
/// @param[out] tensor_info Pointer where output result to, should be writable
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_tensor_info(kestrel_nn nn, const char *name, kestrel_tensor_meta_t *tensor_info);

/// @brief Reshape input tensor by specific name
/// @param[in] nn Kestrel neural network handle
/// @param[in] name Tensor name going to reshape
/// @param[in] in Pointer of config shape, should be readable
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_reshape(kestrel_nn nn, const char *name, const kestrel_tensor_meta_t *in);

/// @brief Get tensor by specific name
/// @param[in] nn Kestrel neural network handle
/// @param[in] name Tensor name going to get
/// @param[out] tensor Pointer to a tensor struct, filled by function after invoke
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_get_tensor(kestrel_nn nn, const char *name, kestrel_tensor_t **tensor);

/// @brief Run neural network forward
/// @param[in] nn Kestrel neural network handle
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_forward(kestrel_nn nn);

/// @brief Run neural network forward asynchronously
/// @param[in] nn Kestrel neural network handle
/// @param[out] e Kestrel event handle
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_forward_async(kestrel_nn nn, kestrel_event *e);

/// @brief Wait neural network forward done
/// @param[in] nn Kestrel neural network handle
/// @param[in] e Kestrel event handle of neural network forward task
/// @return `KPLUGIN_OK` for succeed, otherwise return a error code
KESTREL_API
k_err kestrel_nn_forward_await(kestrel_nn nn, kestrel_event e);

/// @brief Destroy a Kestrel neural network handle
/// @param[in,out] nn Kestrel neural network handle
KESTREL_API
void kestrel_nn_destroy(kestrel_nn *nn);

/// @}

#ifdef __cplusplus
}
#endif

#endif
