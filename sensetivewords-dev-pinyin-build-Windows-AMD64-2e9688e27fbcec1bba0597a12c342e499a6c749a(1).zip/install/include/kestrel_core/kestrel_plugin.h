#ifndef KESTREL_CORE_KESTREL_PLUGIN_H
#define KESTREL_CORE_KESTREL_PLUGIN_H

#include "kestrel_define.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_plugin
///
/// Kestrel plug-in APIs take responsibility for extension plug-in's load/unload/inspect/retrival
/// etc.
///
/// There are two types of plug-ins, shared plug-in & static plug-in:
/// - **Shared plug-in**: Substantially a shared library (ELF for UNIX-like, PE for Windows),
/// use kestrel_plugin_load() to load it into kestrel environment.
/// - **Static plug-in**: Analogously is a static library, could be statically linked into target
/// libraries or application programs, but still need explicit setup before use,
/// kestrel_plugin_setup_builtin() do setup routines.
///
/// The plug-in structure designed with an opaque extensible pointer `ppi`, whereby, the user can
/// extend any interface into without modifying kestrel_core.
///
/// Especially, Kestrel Core predefines a type of plug-in: @ref kestrel_device
///
/// @{

#define KESTREL_E_PLUGIN 0x1

#define KPLUGIN_OK KESTREL_OK
#define KPLUGIN_E_AGAIN CV_ERR_PACK(KESTREL_ERR, KESTREL_E_PLUGIN, 0x0001)
#define KPLUGIN_E_EOF CV_ERR_PACK(KESTREL_ERR, KESTREL_E_PLUGIN, 0x0002)
#define KPLUGIN_E_INTERNAL CV_ERR_PACK(KESTREL_ERR, KESTREL_E_PLUGIN, 0x0003)

///
/// Unknown plug-in type
///
#define KESTREL_UNKNOWN_PLUGIN_TYPE (-1)

#define KESTREL_PRIVATE_PLUGIN (0x40000000)

///
/// Max length of plug-in name
///
#define MAX_PLUGIN_NAME_LEN (127)

///
/// Kestrel plug-in interface definition
///
typedef struct kestrel_plugin_t {
        /** Plug-in name */
        char plugin_name[MAX_PLUGIN_NAME_LEN + 1];
        /** Plug-in type, for customer plug-in, must in range of [1, 0x40000000) */
        int32_t type;

        /** Plug-in version get function */
        const char *(*version)(void);
        /** Plug-in revision get function */
        const char *(*revision)(void);
        /** Plug-in install function */
        void *(*install_fx)();
        /** Plug-in uninstall function */
        void (*uninstall_fx)(void *);

        void *ppi;
} kestrel_plugin_t;

#ifdef __cplusplus
#define VERSION_FUNC(name) extern "C" const char *name##_version(void);
#define REVISION_FUNC(name) extern "C" const char *name##_revision(void);
#else
#define VERSION_FUNC(name) extern const char *name##_version(void);
#define REVISION_FUNC(name) extern const char *name##_revision(void);
#endif

///
/// Plug-in register sugar macro
///
#define REGISTER_PLUGIN_WITH_NAME(name, plg_name, plg_type, interface)                           \
        VERSION_FUNC(plg_name)                                                                   \
        REVISION_FUNC(plg_name)                                                                  \
        static kestrel_plugin_t ___##name##___;                                                  \
        KESTREL_API const kestrel_plugin_t *register_plugin_##plg_name()                         \
        {                                                                                        \
                if (strlen(#name) <= MAX_PLUGIN_NAME_LEN) {                                      \
                        kestrel_plugin_t *p = &___##name##___;                                   \
                        memset(p, 0, sizeof(kestrel_plugin_t));                                  \
                        strncpy(p->plugin_name, #plg_name, MAX_PLUGIN_NAME_LEN);                 \
                        p->type = plg_type;                                                      \
                        p->version = plg_name##_version;                                         \
                        p->revision = plg_name##_revision;                                       \
                        p->install_fx = name##_install;                                          \
                        p->uninstall_fx = name##_uninstall;                                      \
                        p->ppi = (void *)(&(interface));                                         \
                        return p;                                                                \
                }                                                                                \
                return NULL;                                                                     \
        }

///
/// Plug-in register sugar macro
///
#define REGISTER_PLUGIN(name, plg_type, interface)                                               \
        REGISTER_PLUGIN_WITH_NAME(name, name, plg_type, interface)
///
/// Plug-in declare static plugin registry sugar macro
///
#define DECLARE_PLUGIN(name) KESTREL_API const kestrel_plugin_t *register_plugin_##name();

///
/// Plug-in static plugin register sugar macro
///
#define SETUP_BUILTIN_PLUGIN(name, signature)                                                    \
        kestrel_plugin_setup_builtin(register_plugin_##name(), signature);

/// @brief Load an builtin plugin
/// @param[in] p Plugin API
/// @param[in] signature Plug-in signature string, computed according license
/// @return KESTREL_OK for succeed, other for error
/// @note Load an exist plugin again, it will return KESTREL_OK, but do nothing except print a
/// warning
KESTREL_API
k_err kestrel_plugin_setup_builtin(const kestrel_plugin_t *p, const char *signature);

/// @brief Load an external plugin
/// @param[in] file Plugin file
/// @param[in] signature Plug-in signature string, computed according license
/// @return Plug-in name for succeed, NULL for error
/// @note Load an exist plugin again, it will return plug-in name normally, but do nothing except
/// print a warning
KESTREL_API
const char *kestrel_plugin_load(const char *file, const char *signature);

/// @brief Get plug-in type
/// @param[in] name Plug-in name
/// @return Kestrel plug-in type enum value
KESTREL_API
int32_t kestrel_plugin_get_type(const char *name);

/// @brief Check if a plug-in already registered or not
/// @param[in] name Plug-in name
/// @return 1 for exist, 0 for not
KESTREL_API
int32_t kestrel_plugin_exist(const char *name);

/// @brief Find plug-in info
/// @param[in] name Plug-in name
/// @param[out] plugin_hdl Output plug-in global handle, could be `NULL` if not care
/// @return Info structure of found plug-in, or NULL for end
KESTREL_API
const kestrel_plugin_t *kestrel_plugin_find(const char *name, void **plugin_hdl);

/// @brief Find plug-in info, if not find will try load `name.kep`
/// @param[in] name Plug-in name
/// @param[out] plugin_hdl Output plug-in global handle, could be `NULL` if not care
/// @return Info structure of found plug-in, or NULL for end
KESTREL_API
const kestrel_plugin_t *kestrel_plugin_find_if_not_exist_try_load(const char *name,
                                                                  void **plugin_hdl);

/// @brief Enumerate plug-ins
/// @param[in] name Current plug-in name, NULL for first get
/// @param[out] plugin_hdl Output plug-in global handle, could be `NULL` if not care
/// @return Info structure of next plug-in, or NULL for end
KESTREL_API
const kestrel_plugin_t *kestrel_plugin_get_next(const char *name, void **plugin_hdl);

/// @brief Print plug-in version information
/// @param[in] name Plug-in name
/// @return Version string for succeed, NULL for error
KESTREL_API
const char *kestrel_plugin_version(const char *name);

/// @brief Print plug-in revision information
/// @param[in] name Plug-in name
/// @return Revision string for succeed, NULL for error
KESTREL_API
const char *kestrel_plugin_revision(const char *name);

/// @brief Unload a plug-in
/// @param[in] name Plug-in name
/// @note Only allowed call on primary thread
KESTREL_API
void kestrel_plugin_unload(const char *name);

/// @}

#ifdef __cplusplus
}
#endif

#endif
