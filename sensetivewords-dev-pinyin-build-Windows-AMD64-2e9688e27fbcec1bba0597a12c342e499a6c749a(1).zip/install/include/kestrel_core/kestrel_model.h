#ifndef KESTREL_CORE_KESTREL_MODEL_H
#define KESTREL_CORE_KESTREL_MODEL_H

#include "kestrel_define.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_model
///
/// These APIs handle STEF (SenseTime Encrypted Format) models, also work for decipher model type.
/// Besides, Kestrel provides an extend capability:
///
/// Model register API let user register a model as a registered resource, which could be load
/// using kestrel_model_load() with model OID as a model identification. Model register operation
/// is ref-counted, so user should call kestrel_model_unregister() for each
/// kestrel_model_register(). At last, all registered models will be unload when
/// kestrel_env_deinit(), explicit unregister APIs also provided as supplement:
/// kestrel_model_force_unregister() & kestrel_model_unregister_all() .
///
/// @{

///
/// Kestrel model struct
///
typedef struct kestrel_model_t *kestrel_model;

/// @brief Load model from file
/// @param[in] model_file Path to model file, or Model Object ID like `moid://<Model-OID-string>`
/// @param[out] model Handle of model, release it using kestrel_model_unload()
/// @return KESTREL_OK for succeed, otherwise return error code
KESTREL_API
k_err kestrel_model_load(const char *model_file, kestrel_model *model);

/// @brief Reference an existed model handle
/// @param[in] model Exist model handle
/// @return Model handle which equal with input, and ref count has increased
KESTREL_API
kestrel_model kestrel_model_ref(kestrel_model model);

/// @brief Map model from memory data
/// @param[in] data Model data pointer address
/// @param[in] data_size Size of model data in bytes
/// @param[in] finalizer Custom finalizer function.
/// @param[in] finalizer_ud User data for finalizer function.
/// @param[out] model Handle of model, release it using kestrel_model_unload()
/// @return KESTREL_OK for succeed, otherwise return error code
KESTREL_API
k_err kestrel_model_map_from_memory(uint8_t *data, size_t data_size,
                                    void (*finalizer)(void *ud, void *data), void *finalizer_ud,
                                    kestrel_model *model);

/// @brief Get Model version represented as a single integer
/// @param[in] m Handle of model
/// @return Version number in format major * 10^4 + minor * 10^2 + patch, -1 for error
KESTREL_API
int32_t kestrel_model_version(kestrel_model m);

/// @brief Get Model type
/// @param[in] m Handle of model
/// @return Model type string, reference, no need to free
KESTREL_API
const char *kestrel_model_type(kestrel_model m);

/// @brief Get Model OID
/// @param[in] m Handle of model
/// @return Model OID string, should be a SHA256 hash of which length is 65 bytes (64 bytes for
/// hash, and an extra byte for '\0'), NULL for error.
KESTREL_API
const char *kestrel_model_oid(kestrel_model m);

/// @brief Get **public** model file data length form model
/// @param[in] m Handle of model
/// @param[in] file File name in the model
/// @return Target file length in bytes, return 0 in case of error
/// @note For compatible with SenseTime model format, kestrel also supports get file form
/// sub-model, which could be a tar or zip format, with merely different: File name should be a
/// string which concatenates each path of sub-models with a single vertical bar ("|") as the
/// delimiter.
KESTREL_API
size_t kestrel_model_file_size(kestrel_model m, const char *file);

/// @brief Get **public** model file data form model
/// @param[in] m Handle of model
/// @param[in] file File name in the model
/// @param[in] buf Buffer pointer for getting file, must not be NULL
/// @param[in,out] buf_len Buffer length of buffer, must enough for kestrel_model_file_size(),
/// after invoke, it is actual size of file
/// @return KESTREL_OK for successful, otherwise return error code
/// @note For compatible with SenseTime model format, kestrel also supports get file form
/// sub-model, which could be a tar or zip format, with merely different: File name should be a
/// string which concatenates each path of sub-models with a single vertical bar ("|") as the
/// delimiter.
/// @note At present, `meta.json`, `meta.conf`, `params.json`, `parameters.json` and directory
/// `public/` are public files only, all other files are private.
KESTREL_API
k_err kestrel_model_get_file(kestrel_model m, const char *file, uint8_t *buf, size_t *buf_len);

/// Kestrel shibboleth function for getting private files
/// @param[in] input Random input binary code
/// @param[out] output Output shibboleth code
typedef void (*kestrel_shibboleth_fx)(const uint8_t input[16], uint8_t output[16]);

/// Callback function proto for kestrel_model_run_cb_with_file()
/// @param[in] ud User data bypass from kestrel_model_run_cb_with_file()'s parameter `ud`
/// @param[in] buf Buffer start pointer of requst file
/// @param[in] buf_len Buffer length of requst file
/// @return KESTREL_OK for successful, otherwise return error code
typedef k_err (*kestrel_model_file_cb)(void *ud, const uint8_t *const buf, size_t buf_len);

/// @brief Run callback function with a **private** model file data
/// @param[in] m Handle of model
/// @param[in] file File name in the model
/// @param[in] shibboleth Shibboleth check function, should be non-NULL for getting private file
/// @param[in] cb Callback function going to run
/// @param[in] ud User data pointer for callback function
/// @return KESTREL_OK for successful, otherwise return error code
/// @note Shibboleth checking is ineffective now.
KESTREL_API
k_err kestrel_model_run_cb_with_file(kestrel_model m, const char *file,
                                     kestrel_shibboleth_fx shibboleth, kestrel_model_file_cb cb,
                                     void *ud);

/// @brief Unload model
/// @param[in,out] m Handle of model
/// @return KESTREL_OK for succeed, otherwise return error code
/// @note Since the model is managed using reference count, the release operation is triggered
/// only when the reference count is reduced to 0
KESTREL_API
k_err kestrel_model_unload(kestrel_model *m);

/// @brief Register a model from memory
/// @param[in] m Handle of model going to regist,
/// @return Model Object ID string, user could use `moid://<Model-OID-string>` as a URI for
/// kestrel_model_load() to open associated model. NULL if error occurred.
/// @note All registered model will be auto-unloaded in kestrel_env_deinit().
/// @note The input model is allowed and should call kestrel_model_unload() to release it at an
/// appropriate moment, although kestrel_env_deinit() will force release all registered model
/// @note If have to unregister it manually, call kestrel_model_unregister()
/// @note Multiple registrations the same model is allowed, and kestrel_model_unregister()
/// should be called equal number of times to release it
KESTREL_API
const char *kestrel_model_register(kestrel_model m);

/// @brief Unregister a model from global environment
/// @param[in] oid Model Object ID returned by kestrel_model_register().
/// called
/// @return KESTREL_OK for successful, otherwise return error code.
KESTREL_API
k_err kestrel_model_unregister(const char *oid);

/// @brief Force unregister a model from global environment, regardless how many
/// kestrel_model_register() has called
/// @param[in] oid Model Object ID returned by kestrel_model_register().
/// @return KESTREL_OK for successful, otherwise return error code.
KESTREL_API
k_err kestrel_model_force_unregister(const char *oid);

/// @brief Register all registered models from global environment
/// @note On invoking kestrel_env_deinit(), kestrel_model_unregister_all() will be invoked
/// automatically, to unregister all models
KESTREL_API
void kestrel_model_unregister_all();

/// @}

#ifdef __cplusplus
}
#endif

#endif
