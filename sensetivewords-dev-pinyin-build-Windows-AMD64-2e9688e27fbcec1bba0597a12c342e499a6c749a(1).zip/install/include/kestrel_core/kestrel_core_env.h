#ifndef KESTREL_CORE_KESTREL_ENV_H
#define KESTREL_CORE_KESTREL_ENV_H

#include "kestrel_define.h"

#ifdef __cplusplus
extern "C" {
#endif

KESTREL_API
k_err kestrel_env_init(const char *product);

KESTREL_API
const char *kestrel_env_product_name();

KESTREL_API
void kestrel_env_deinit();

#ifdef __cplusplus
}
#endif

#endif
