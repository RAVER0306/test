#ifndef KESTREL_KESTREL_ANNOTATOR_DEF_H
#define KESTREL_KESTREL_ANNOTATOR_DEF_H

#include <kestrel_core/kestrel_plugin.h>

#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_aspect
/// @{

///
/// Annotator plug-in type
///
#define KESTREL_ASPECT_PLUGIN (KESTREL_PRIVATE_PLUGIN | 4)

#define MAX_POINTCUT_CATEGORY_LEN 15
#define MAX_POINTCUT_TAG_LEN 63

///
/// Aspect pointcut information definition
///
typedef struct kestrel_aspect_info_t {
        char module_tag[MAX_PLUGIN_NAME_LEN + 1];
        char pointcut_tag[MAX_POINTCUT_TAG_LEN + 1];
        uint64_t micro_sec;
        uint64_t module_id;
        uint32_t thread_id;
        char type;
        char scope;
} kestrel_aspect_info_t;

///
/// Aspect plug-in interface definition
///
typedef struct kestrel_aspect_api_t {

        /** Startup configura */
        k_err (*startup_fx)(void *hdl, const char *cfg); // hdl created by install_fx

        /** Do pointcut */
        void (*pointcut_fx)(void *hdl, kestrel_aspect_info_t *cpi);

        /** Destroy context */
        void (*terminate_fx)(void *hdl);
} kestrel_aspect_api_t;

///
/// Annotator plug-in register sugar macro
///
#define REGISTER_ASPECT(name)                                                                    \
        static kestrel_aspect_api_t ___##name##_ppi___ = { name##_startup, name##_pointcut,      \
                                                           name##_terminate };                   \
        REGISTER_PLUGIN(name, KESTREL_ASPECT_PLUGIN, ___##name##_ppi___)

/// @}

#ifdef __cplusplus
}
#endif

#endif
