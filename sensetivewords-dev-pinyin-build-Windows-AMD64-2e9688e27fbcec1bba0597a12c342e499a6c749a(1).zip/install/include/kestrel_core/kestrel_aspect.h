#ifndef KESTREL_ASPECT_H
#define KESTREL_ASPECT_H

#include <kestrel_core/kestrel_define.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_aspect
/// @{

#define KESTREL_ASPECT_TYPE_BEGIN 'B'
#define KESTREL_ASPECT_TYPE_END 'E'
#define KESTREL_ASPECT_TYPE_INSTANT 'I'

#define KESTREL_ASPECT_SCOPE_GLOBAL 'g'
#define KESTREL_ASPECT_SCOPE_PROCESS 'p'
#define KESTREL_ASPECT_SCOPE_THREAD 't'
#define KESTREL_ASPECT_SCOPE_DEFAULT KESTREL_ASPECT_SCOPE_THREAD

/// @brief Mark a pointcut
/// @param[in] type Pointcut type, should be one of `KESTREL_ASPECT_TYPE_XXX`
/// @param[in] scope Pointcut scope, should be one of `KESTREL_ASPECT_SCOPE_XXX`
/// @param[in] module_tag Module tag of pointcut belonging
/// @param[in] module_id Module ID of pointcut belonging
/// @param[in] pointcut_tag Cut point tag
KESTREL_API
void kestrel_pointcut(char type, char scope, const char *module_tag, uint64_t module_id,
                      const char *pointcut_tag);

/// @}

#ifdef __cplusplus
}
#endif

#endif
