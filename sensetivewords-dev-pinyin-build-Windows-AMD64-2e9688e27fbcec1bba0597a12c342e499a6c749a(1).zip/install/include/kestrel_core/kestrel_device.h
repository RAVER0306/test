#ifndef KESTREL_CORE_KESTREL_DEVICE_H
#define KESTREL_CORE_KESTREL_DEVICE_H

#include "kestrel_device_def.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_device
///
/// Kestrel device is a type of @ref kestrel_plugin, which occupies plug-in type ID 0, and
/// contract PPI like @ref kestrel_device_api_t. Furthermore, Kestrel also abstracts host memory
/// management as a device plug-in, named `host`. The `host` device plug-in is auto setup as a
/// built-in plugin in kestrel_init().
///
/// Following above-mentioned design, plug-in type ID 0, and plug-in name `host` occupied.
///
/// Kestrel device bind/unbind operate thread-specific data, which means each thread should
/// bind device individually, and it will be unbound when thread terminating, explicit unbind is
/// also allowed.
///
/// @{

typedef struct kestrel_dev_hdl_t {
        const kestrel_plugin_t *dev_plugin;
        void *dev_hdl;
        kestrel_dev_id dev_id;
        char *config;
} kestrel_dev_hdl_t, *kestrel_dev_hdl;

///
/// Memory category enum definition.
///
typedef enum kestrel_mem_type_e {
        /** Unknown memory type */
        KESTREL_MEM_UNKNOWN = -1,
        /** Host memory type */
        KESTREL_MEM_HOST = 0,
        /** Device memory type */
        KESTREL_MEM_DEVICE = 1
} kestrel_mem_type_e;

/// @brief Binding specific device with current thread
/// @param[in] device Device type name to create instance
/// @param[in] config Device configuration
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_device_bind(const char *device, const char *config);

/// @brief Attach binded device to current thread
/// @param[in] h Exist device handle
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_device_attach(kestrel_dev_hdl h);

///
/// @brief Detach device with current thread
///
KESTREL_API
void kestrel_device_detach();

///
///@brief Unbind device with current thread
///
KESTREL_API
void kestrel_device_unbind();

/// @brief Get device name of a device instance
/// @return Device type name if successful, or NULL for fail
/// @note Returned string do not need to free
KESTREL_API
const char *kestrel_device_get_name();

/// @brief Get device type of a device instance
/// @return Device type if successful, or KESTREL_MEM_UNKNOWN for fail
KESTREL_API
kestrel_mem_type_e kestrel_device_get_type();

/// @brief Get device binding device ID
/// @return Device binding Device ID, -1 indicates error
KESTREL_API
int32_t kestrel_device_get_id();

/// @brief Get user device handle of current device
/// @return User defined device handle, NULL for error
KESTREL_API
kestrel_dev_hdl kestrel_device_get_handle();

/// @brief Get host handle
/// @return Host device handle, NULL for error
KESTREL_API
kestrel_dev_hdl kestrel_device_get_host();

/// [deprecated] instead `kestrel_device_get_handle`
KESTREL_API
kestrel_dev_hdl kestrel_current_hdl();

/// [deprecated] instead `kestrel_device_get_host`
KESTREL_API
kestrel_dev_hdl kestrel_primary_hdl();

/// @}

#ifdef __cplusplus
}
#endif

#endif
