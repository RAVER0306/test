#ifndef KESTREL_CORE_KESTREL_DEVICE_DEF_H
#define KESTREL_CORE_KESTREL_DEVICE_DEF_H

#include "kestrel_plugin.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_device
/// @{

///
/// DEVICE plug-in type
///
#define KESTREL_DEVICE_PLUGIN (0)

///
/// Kestrel device handle definition.
///
typedef int32_t kestrel_dev_id;

///
/// Invalid DEVICE type
///
#define KESTREL_DEV_INVALID (-1)

///
/// Memory transmission category enum definition.
///
typedef enum kestrel_mem_trans_e {
        /** Unknown memory transmission type */
        KESTREL_MEM_TRANSMISSION_UNKNOWN,
        /** Memory transimssion form host to device */
        KESTREL_MEM_HOST_TO_DEVICE,
        /** Memory transmission form device to host */
        KESTREL_MEM_DEVICE_TO_HOST,
        /** Memory transmission form device to device */
        KESTREL_MEM_DEVICE_TO_DEVICE,
        /** Memory transmission auto detect */
        KESTREL_MEM_TRANSMISSION_AUTO
} kestrel_mem_trans_e;

///
/// Device plug-in interface definition.
///
typedef struct kestrel_device_api_t {
        /** Device open API, to bind a device to current thread */
        kestrel_dev_id (*open_fx)(void *h, const char *config);
        /** Allocates a block of size bytes of memory, returning a pointer to the beginning of the
         * block */
        void *(*mem_alloc)(void *h, kestrel_dev_id device, size_t size);
        /** Allocates a block of memory for an array of num elements, and initializes all its bits
         * to zero */
        void *(*mem_calloc)(void *h, kestrel_dev_id device, size_t num, size_t size);
        /** Changes the size of the memory block pointed to by ptr */
        void *(*mem_realloc)(void *h, kestrel_dev_id device, void *ptr, size_t size);
        /** Sets the first num bytes of the block of memory pointed by ptr to the specified value
         * (interpreted as an unsigned char) */
        k_err (*mem_set)(void *h, kestrel_dev_id device, void *ptr, uint8_t value, size_t num);
        /** Copies the values of num bytes from the location pointed to by source directly to the
         * memory block pointed to by destination */
        k_err (*mem_copy)(void *h, kestrel_dev_id src_dev, void *src, kestrel_dev_id dst_dev,
                          void *dst, size_t num, kestrel_mem_trans_e t);
        /** Similar with mem_copy, but generate a event handle for async process */
        k_err (*mem_copy_async)(void *h, kestrel_dev_id src_dev, void *src,
                                kestrel_dev_id dst_dev, void *dst, size_t num,
                                kestrel_mem_trans_e t, kestrel_event *e);
        /** Copies the values in specific 2D range from the location pointed to by source directly
         * to the memory block pointed to by destination */
        k_err (*mem_copy2d)(void *h, kestrel_dev_id src_dev, void *src, size_t src_pitch,
                            kestrel_dev_id dst_dev, void *dst, size_t dst_pitch, size_t width,
                            size_t height, kestrel_mem_trans_e t);
        /** Similar with mem_copy2d, but generate a event handle for async process */
        k_err (*mem_copy2d_async)(void *h, kestrel_dev_id src_dev, void *src, size_t src_pitch,
                                  kestrel_dev_id dst_dev, void *dst, size_t dst_pitch,
                                  size_t width, size_t height, kestrel_mem_trans_e t,
                                  kestrel_event *e);
        /** Sync by a event handle */
        k_err (*mem_copy_await)(void *h, kestrel_dev_id device, kestrel_event event);
        /** Deallocate memory block */
        k_err (*mem_free)(void *h, kestrel_dev_id device, void *ptr);
        /** Device close API, to unbind a device to current thread */
        void (*close_fx)(void *h, kestrel_dev_id device);
        /** Memory map */
        void *(*map_fx)(void *h, void *ptr);
        /** Memory unmap */
        void (*unmap_fx)(void *h, void *ptr);
} kestrel_device_api_t;

///
/// Device plug-in register sugar macro
///
#define REGISTER_DEVICE(name, map_fx, unmap_fx)                                                  \
        static kestrel_device_api_t ___##name##_ppi___ = { name##_open,                          \
                                                           name##_mem_alloc,                     \
                                                           name##_mem_calloc,                    \
                                                           name##_mem_realloc,                   \
                                                           name##_mem_set,                       \
                                                           name##_mem_copy,                      \
                                                           name##_mem_copy_async,                \
                                                           name##_mem_copy2d,                    \
                                                           name##_mem_copy2d_async,              \
                                                           name##_mem_copy_await,                \
                                                           name##_mem_free,                      \
                                                           name##_close,                         \
                                                           map_fx,                               \
                                                           unmap_fx };                           \
        REGISTER_PLUGIN(name, KESTREL_DEVICE_PLUGIN, ___##name##_ppi___)

/// @}

#ifdef __cplusplus
}
#endif

#endif
