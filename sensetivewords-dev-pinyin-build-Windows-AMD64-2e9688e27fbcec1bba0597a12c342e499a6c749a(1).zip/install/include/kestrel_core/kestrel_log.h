#ifndef KESTREL_CORE_KESTREL_LOG_H_
#define KESTREL_CORE_KESTREL_LOG_H_

#include "kestrel_define.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <stdarg.h>

/// @addtogroup kestrel_log
/// @{

///
/// log level enum definition.
///
typedef enum kestrel_log_level_e {
        /** Trace log for detail debug */
        KESTREL_LL_TRACE = 0,
        /** log for debug */
        KESTREL_LL_DEBUG = 1,
        /** log for info */
        KESTREL_LL_INFO = 2,
        /** log for warning */
        KESTREL_LL_WARNING = 3,
        /** log for error */
        KESTREL_LL_ERROR = 4,
        /** log for essential info */
        KESTREL_LL_ESSENTIAL = 999
} kestrel_log_level_e;

///
/// Enable log color
///
#define KESTREL_LOG_CFG_COLOR 0x01

///
/// Enable log meta output
///
#define KESTREL_LOG_CFG_LABEL 0x02

///
/// Enable log line number output
///
#define KESTREL_LOG_CFG_LINENO 0x04

///
/// Enable log date output
///
#define KESTREL_LOG_CFG_DATE 0x08

///
/// Enable log time output
///
#define KESTREL_LOG_CFG_TIME 0x10

///
/// Enable log nanosecond output
///
#define KESTREL_LOG_CFG_NANOSECOND 0x20

///
/// Enable log thread id
///
#define KESTREL_LOG_CFG_THREADID 0x40

///
/// Max string length of log label
///
#define KESTREL_LOG_LABEL_MAX_LEN 15

///
/// Log label string
///
#ifndef KESTREL_LOG_LABEL
#define KESTREL_LOG_LABEL ""
#endif

///
/// Log meta structure
///
typedef struct kestrel_log_meta_t {
        /** Log level */
        kestrel_log_level_e level;
        /** Log label */
        char label[KESTREL_LOG_LABEL_MAX_LEN + 1];
        /** Log line number */
        int32_t line_no;
} kestrel_log_meta_t;

/// @brief Make a log meta
/// @param[in] level Log level
/// @param[in] label Label string
/// @param[in] line_no Line number
/// @return A log meta
KESTREL_API
kestrel_log_meta_t kestrel_log_meta_make(kestrel_log_level_e level, const char *label,
                                         int32_t line_no);

///
/// Trace log meta define
///
#if defined(__cplusplus) && defined(_MSC_VER)
#define KESTREL_TRACE                                                                            \
        {                                                                                        \
                KESTREL_LL_TRACE, KESTREL_LOG_LABEL, __LINE__                                    \
        }
#else
#define KESTREL_TRACE ((kestrel_log_meta_t){ KESTREL_LL_TRACE, KESTREL_LOG_LABEL, __LINE__ })
#endif

///
/// Debug log meta define
///
#if defined(__cplusplus) && defined(_MSC_VER)
#define KESTREL_DEBUG                                                                            \
        {                                                                                        \
                KESTREL_LL_DEBUG, KESTREL_LOG_LABEL, __LINE__                                    \
        }
#else
#define KESTREL_DEBUG ((kestrel_log_meta_t){ KESTREL_LL_DEBUG, KESTREL_LOG_LABEL, __LINE__ })
#endif

///
/// Info log meta define
///
#if defined(__cplusplus) && defined(_MSC_VER)
#define KESTREL_INFO                                                                             \
        {                                                                                        \
                KESTREL_LL_INFO, KESTREL_LOG_LABEL, __LINE__                                     \
        }
#else
#define KESTREL_INFO ((kestrel_log_meta_t){ KESTREL_LL_INFO, KESTREL_LOG_LABEL, __LINE__ })
#endif

///
/// Warning log meta define
///
#if defined(__cplusplus) && defined(_MSC_VER)
#define KESTREL_WARNING                                                                          \
        {                                                                                        \
                KESTREL_LL_WARNING, KESTREL_LOG_LABEL, __LINE__                                  \
        }
#else
#define KESTREL_WARNING ((kestrel_log_meta_t){ KESTREL_LL_WARNING, KESTREL_LOG_LABEL, __LINE__ })
#endif

///
/// Error log meta define
///
#if defined(__cplusplus) && defined(_MSC_VER)
#define KESTREL_ERROR                                                                            \
        {                                                                                        \
                KESTREL_LL_ERROR, KESTREL_LOG_LABEL, __LINE__                                    \
        }
#else
#define KESTREL_ERROR ((kestrel_log_meta_t){ KESTREL_LL_ERROR, KESTREL_LOG_LABEL, __LINE__ })
#endif

///
/// Essential log meta define
///
#if defined(__cplusplus) && defined(_MSC_VER)
#define KESTREL_ESSENTIAL                                                                        \
        {                                                                                        \
                KESTREL_LL_ESSENTIAL, KESTREL_LOG_LABEL, __LINE__                                \
        }
#else
#define KESTREL_ESSENTIAL                                                                        \
        ((kestrel_log_meta_t){ KESTREL_LL_ESSENTIAL, KESTREL_LOG_LABEL, __LINE__ })
#endif

/// Log callback function type define
/// @param[in] meta Log meta information
/// @param[in] fmt Log format string contains some specifier, which follows printf()'s define
/// @param[in] vl A value identifying a variable arguments list initialized with `va_start`
/// @return Log message length, including EOS character
typedef int32_t (*kestrel_log_callback)(kestrel_log_meta_t meta, const char *fmt, va_list vl);

/// @brief Default log function
/// @param[in] meta Output log meta config.
/// @param[in] fmt A format specifier follows `printf` format.
/// @param[in] vl A value identifying a variable arguments list initialized with `va_start`
/// @return Log message length, including EOS character
KESTREL_API
int32_t kestrel_log_default(kestrel_log_meta_t meta, const char *fmt, va_list vl);

/// @brief Set log callback function
/// @param[in] cb Callback function
/// @param[out] old Return old callback function
KESTREL_API
void kestrel_log_set_callback(kestrel_log_callback cb, kestrel_log_callback *old);

///
/// Reset log callback default function
///
KESTREL_API
void kestrel_log_reset_callback();

/// @brief Set log output level
/// @param[in] level Output level, all log info that has higher level then it will output.
KESTREL_API
void kestrel_log_set_level(kestrel_log_level_e level);

/// @brief Get log config
/// @return Log config mixed by KESTREL_LOG_CFG_XXX.
/// @note Default is
/// `KESTREL_LOG_CFG_DATE | KESTREL_LOG_CFG_TIME | KESTREL_LOG_CFG_LABEL | KESTREL_LOG_CFG_COLOR`
KESTREL_API
int32_t kestrel_log_get_config();

/// @brief Set log config
/// @param[in] config Log config mixed by KESTREL_LOG_CFG_XXX.
KESTREL_API
void kestrel_log_set_config(int32_t config);

///
/// Reset log config to default value
///
KESTREL_API
void kestrel_log_reset_config();

/// @brief Get log output level
/// @return Current log output level
KESTREL_API
kestrel_log_level_e kestrel_log_get_level();

/// @brief Print a log
/// @param[in] meta Output log meta config.
/// @param[in] fmt A format specifier follows `printf` format.
/// @param[in] ... Depending on the format string, the function may expect a sequence of
/// additional arguments, each containing a value to be used to replace a format specifier in the
/// format string.
/// @return Log message length, including EOS character
KESTREL_API
int32_t kestrel_log(kestrel_log_meta_t meta, const char *fmt, ...);

/// @brief Similar with kestrel_log(), but receive a va_list as additional
/// arguments
/// @param[in] meta Output log meta config.
/// @param[in] fmt A format specifier follows `printf` format.
/// @param[in] vl Depending on the format string, the function may expect a va list of additional
/// arguments.
/// @return Log message length, including EOS character
KESTREL_API
int32_t kestrel_log_va(kestrel_log_meta_t meta, const char *fmt, va_list vl);

/// @}

#ifdef __cplusplus
}
#endif

#endif
