#ifndef KESTREL_CORE_KESTREL_ATOMIC_H
#define KESTREL_CORE_KESTREL_ATOMIC_H

#include "kestrel_define.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_atomic
/// @{

/// Add a value to atomic `a`, and obtains the previous value of the atomic
/// @param[in] a Pointer to atomic int
/// @param[in] value The value to add
/// @return The previous value of the atomic
KESTREL_API
int32_t kestrel_atomic_add(int32_t volatile *a, int32_t value);

/// Increase atomic `a`, and obtains the previous value of the atomic
/// @param[in] a Pointer to atomic int
/// @return The previous value of the atomic
KESTREL_API
int32_t kestrel_atomic_inc(int32_t volatile *a);

/// Reduce atomic `a`, and obtains the previous value of the atomic
/// @param[in] a Pointer to atomic int
/// @return The previous value of the atomic
KESTREL_API
int32_t kestrel_atomic_dec(int32_t volatile *a);

/// Set a value to atomic `a`, and obtains the previous value of the atomic
/// @param[in] a Pointer to atomic int
/// @param[in] newvalue The new value to set
/// @return The previous value of the atomic
KESTREL_API
void kestrel_atomic_set(int32_t volatile *a, int32_t newvalue);

/// Get value of atomic `a`
/// @param[in] a Pointer to atomic int
/// @return The value of the atomic
KESTREL_API
int32_t kestrel_atomic_get(int32_t volatile *a);

/// @}

#ifdef __cplusplus
}
#endif

#endif
