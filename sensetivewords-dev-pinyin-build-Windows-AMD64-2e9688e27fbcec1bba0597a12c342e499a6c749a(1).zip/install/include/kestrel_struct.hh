#ifndef KESTREL_STRUCT_HH
#define KESTREL_STRUCT_HH

#include <memory>
#include <algorithm>
#include <utility>
#include <vector>
#include <fstream>
#include <string>
#include <limits.h>

#include <kestrel.h>
#include <kestrel_core.hh>
#include <kestrel_aux/kestrel_frame_utils.h>

namespace Kestrel
{

static_assert(sizeof(kestrel_wchar_t) == sizeof(wchar_t),
              "sizeof kestrel_wchar_t != sizeof wchar_t");

typedef kestrel_point2d_t Point2Di;
typedef kestrel_point2df_t Point2Df;
typedef kestrel_size2d_t Size2D;
typedef kestrel_area2d_t Area2D;
typedef kestrel_pixel_t Pixel;

class Env;
static std::shared_ptr<Env> g_env;

class Env
{
public:
        static k_err Init(const std::string &product)
        {
                return kestrel_init(product.c_str());
        }

        static void Deinit()
        {
                kestrel_deinit();
        }

        static std::string ProductName()
        {
                const char *pn = kestrel_product_name();
                return pn != nullptr ? std::string(pn) : std::string();
        }
};

class Buffer
{
public:
        Buffer(kestrel_mem_type_e type = KESTREL_MEM_HOST)
        {
                kestrel_buffer b = kestrel_buffer_alloc(0, type);
                m_buffer.reset(b, deltor);
        }

        Buffer(kestrel_buffer b) : m_buffer(b, deltor)
        {
        }

        Buffer(size_t size, kestrel_mem_type_e type)
        {
                kestrel_buffer b = kestrel_buffer_alloc(size, type);
                m_buffer.reset(b, deltor);
        }

        Buffer(void *data, size_t size, kestrel_mem_type_e type,
               kestrel_buf_finalizer del = nullptr, void *ud = nullptr)
        {
                kestrel_buffer b = kestrel_buffer_make(data, size, type, del, ud);
                m_buffer.reset(b, deltor);
        }

        bool IsValid() const
        {
                return m_buffer != nullptr;
        }

        bool Reallocate(size_t size, kestrel_mem_type_e type)
        {
                if (IsValid() && type == this->MemType()) {
                        return this->Resize(size) == KESTREL_OK;
                }

                Buffer tmp = *this;
                this->~Buffer();
                new (this) Buffer(size, type);
                if (tmp.IsValid() && tmp.Size() > 0) {
                        if (tmp.Size() > size) {
                                tmp.Resize(size);
                        }
                        tmp.CopyTo(this);
                        this->Resize(size);
                }
                return IsValid();
        }

        bool Allocate(size_t size, kestrel_mem_type_e type = KESTREL_MEM_UNKNOWN)
        {
                if (!IsValid()) {
                        if (type == KESTREL_MEM_UNKNOWN) {
                                kestrel_log(
                                    KESTREL_ERROR,
                                    "Buffer::Allocate() requires to specify the memory type!\n");
                                return IsValid();
                        }
                        this->~Buffer();
                        new (this) Buffer(size, type);
                        return IsValid();
                }

                if (this->Size() != 0) {
                        kestrel_log(KESTREL_WARNING, "Buffer is initialized!\n");
                        return false;
                }

                return Reallocate(size, type == KESTREL_MEM_UNKNOWN ? this->MemType() : type);
        }

        void Free()
        {
                m_buffer.reset();
        }

        kestrel_buffer Raw() const
        {
                return m_buffer.get();
        }

        const char *BindedDeviceName() const
        {
                return kestrel_buffer_mem_device_name(m_buffer.get());
        }

        kestrel_dev_id BindedDeviceId() const
        {
                return kestrel_buffer_mem_device_id(m_buffer.get());
        }

        kestrel_mem_type_e MemType() const
        {
                return kestrel_buffer_mem_type(m_buffer.get());
        }

        k_err Set(uint8_t val)
        {
                return kestrel_buffer_set(m_buffer.get(), val);
        }

        uint8_t *Data() const
        {
                return kestrel_buffer_raw_pointer(m_buffer.get());
        }

        size_t Size() const
        {
                return kestrel_buffer_size(m_buffer.get());
        }

        k_err Resize(size_t size)
        {
                return kestrel_buffer_resize(m_buffer.get(), size);
        }

        k_err Shrink()
        {
                return kestrel_buffer_shrink(m_buffer.get());
        }

        size_t Capacity() const
        {
                return kestrel_buffer_capacity(m_buffer.get());
        }

        Buffer Slice(size_t offset, size_t len)
        {
                return Buffer(kestrel_buffer_slice(m_buffer.get(), offset, len));
        }

        Buffer Duplicate() const
        {
                return Buffer(kestrel_buffer_duplicate(m_buffer.get()));
        }

        k_err Append(const Buffer &buf)
        {
                return kestrel_buffer_append(m_buffer.get(), buf.m_buffer.get());
        }

        k_err AppendData(void *data, size_t len)
        {
                return kestrel_buffer_append_data(m_buffer.get(), data, len);
        }

        k_err CopyTo(Buffer *dst) const
        {
                return kestrel_buffer_copy(m_buffer.get(), dst->m_buffer.get());
        }

        k_err Copy2D(size_t src_x, size_t src_y, size_t src_stride, Buffer *dst, size_t dst_x,
                     size_t dst_y, size_t dst_stride, size_t linesize, size_t height) const
        {
                return kestrel_buffer_copy2D(m_buffer.get(), src_x, src_y, src_stride,
                                             dst->m_buffer.get(), dst_x, dst_y, dst_stride,
                                             linesize, height);
        }

        k_err CopyAsync(Buffer *dst, kestrel_event *e) const
        {
                return kestrel_buffer_copy_async(m_buffer.get(), dst->m_buffer.get(), e);
        }

        k_err Copy2DAsync(size_t src_x, size_t src_y, size_t src_stride, Buffer *dst,
                          size_t dst_x, size_t dst_y, size_t dst_stride, size_t linesize,
                          size_t height, kestrel_event *e) const
        {
                return kestrel_buffer_copy2D_async(m_buffer.get(), src_x, src_y, src_stride,
                                                   dst->m_buffer.get(), dst_x, dst_y, dst_stride,
                                                   linesize, height, e);
        }

        k_err CopyAwait(kestrel_event e) const
        {
                return kestrel_buffer_copy_await(e, NULL);
        }

private:
        std::shared_ptr<kestrel_buffer_t> m_buffer;
        static void deltor(kestrel_buffer p)
        {
                kestrel_buffer_free(&p);
        }
};

class Feature
{
public:
        Feature() : m_feature(nullptr)
        {
        }

        Feature(size_t dims, int32_t version = 0)
        {
                kestrel_feature_t *f = kestrel_feature_alloc(dims);
                m_feature.reset(f, deltor);
                this->Version(version);
        }

        Feature(size_t dims, float *data, int32_t version = 0,
                kestrel_buf_finalizer finalizer = nullptr, void *ud = nullptr)
        {
                kestrel_feature_t *f = kestrel_feature_make(dims, data, finalizer, ud);
                m_feature.reset(f, deltor);
                this->Version(version);
        }

        Feature(kestrel_feature_t *f) : m_feature(f, deltor)
        {
        }

        bool IsValid() const
        {
                return m_feature != nullptr;
        }

        bool Allocate(size_t dims, int32_t version = 0)
        {
                if (IsValid()) {
                        kestrel_log(KESTREL_ERROR,
                                    "Feature::Alloc() failed, need an empty Kestrel::Feature.\n");
                        return false;
                }
                this->~Feature();
                new (this) Feature(dims, version);
                return IsValid();
        }

        void Free()
        {
                m_feature.reset();
        }

        kestrel_feature_t *Raw() const
        {
                return m_feature.get();
        }

        size_t Dimension() const
        {
                return IsValid() ? m_feature->dims : 0;
        }

        float *Data() const
        {
                return IsValid() ? m_feature->feature : nullptr;
        }

        std::vector<float> RawFeature() const
        {
                if (IsValid()) {
                        std::vector<float> rf;
                        rf.assign(m_feature->feature, m_feature->feature + m_feature->dims);
                        return rf;
                }
                return std::vector<float>();
        }

        int32_t Version() const
        {
                return IsValid() ? m_feature->version : 0;
        }

        int32_t Version(int32_t version)
        {
                if (IsValid()) {
                        m_feature->version = version;
                }
                return Version();
        }

        float Compare(const Feature &that, bool with_norm = true) const
        {
                if (with_norm) {
                        return kestrel_feature_distance(this->Raw(), that.Raw());
                }
                return kestrel_feature_distance_normalized(this->Raw(), that.Raw());
        }

private:
        std::shared_ptr<kestrel_feature_t> m_feature;
        static void deltor(kestrel_feature_t *p)
        {
                kestrel_feature_free(&p);
        }
};

class Packet
{
public:
        Packet() : m_packet(nullptr)
        {
        }
        Packet(kestrel_packet_t *packet)
        {
                m_packet = std::shared_ptr<kestrel_packet_t>(
                    packet, [](kestrel_packet_t *p) { kestrel_packet_free(&p); });
        }
        bool IsValid() const
        {
                return m_packet != nullptr;
        }
        kestrel_packet_t *Raw() const
        {
                return m_packet.get();
        }

private:
        std::shared_ptr<kestrel_packet_t> m_packet;
};

class Array
{
public:
        Array() : m_arr(nullptr)
        {
        }

        Array(uint8_t keson_code, size_t element_size, size_t element_count)
        {
                kestrel_array_t *arr =
                    kestrel_array_alloc(keson_code, element_size, element_count);
                m_arr.reset(arr, deltor);
        }

        Array(uint8_t keson_code, size_t element_size, size_t element_count, uint8_t *data,
              kestrel_buf_finalizer finalizer, void *ud)
        {
                kestrel_array_t *arr = kestrel_array_make(keson_code, element_size, element_count,
                                                          data, finalizer, ud);
                m_arr.reset(arr, deltor);
        }

        Array(kestrel_array_t *arr) : m_arr(arr, deltor)
        {
        }

        bool Allocate(uint8_t keson_code, size_t element_size, size_t element_count)
        {
                if (IsValid()) {
                        kestrel_log(KESTREL_ERROR,
                                    "Array::Alloc() failed, need an empty Kestrel::Array.\n");
                        return false;
                }
                this->~Array();
                new (this) Array(keson_code, element_size, element_count);
                return IsValid();
        }

        void Free()
        {
                m_arr.reset();
        }

        bool IsValid() const
        {
                return m_arr != nullptr;
        }

        size_t ElementSize() const
        {
                return IsValid() ? m_arr->element_size : 0;
        }

        size_t ElementCount() const
        {
                return IsValid() ? m_arr->element_count : 0;
        }

        uint8_t KesonCode() const
        {
                return IsValid() ? m_arr->keson_code : KESON_INVALID;
        }

        Array Duplicate() const
        {
                return Array(kestrel_array_duplicate(m_arr.get()));
        }

        kestrel_array_t *Raw() const
        {
                return m_arr.get();
        }

        uint8_t *Data() const
        {
                return IsValid() ? m_arr->data : nullptr;
        }

private:
        std::shared_ptr<kestrel_array_t> m_arr;
        static void deltor(kestrel_array_t *p)
        {
                kestrel_array_free(&p);
        }
};

class TensorShape
{
public:
        TensorShape()
        {
                m_shape.dims_num = 0;
        }

        TensorShape(kestrel_data_type_e elem_type, const std::vector<size_t> &dims,
                    const std::vector<size_t> &strides = std::vector<size_t>())
        {
                size_t dims_num = dims.size();
                size_t strides_num = strides.size();
                if (dims_num > TENSOR_MAX_NDIMS) {
                        Log(KESTREL_WARNING, "too many dimension configura, reset to %d!\n",
                            TENSOR_MAX_NDIMS);
                        dims_num = TENSOR_MAX_NDIMS;
                }

                if (strides_num > TENSOR_MAX_NDIMS) {
                        Log(KESTREL_WARNING, "too many stride configura, reset to %d!\n",
                            TENSOR_MAX_NDIMS);
                        strides_num = TENSOR_MAX_NDIMS;
                }

                m_shape = kestrel_tensor_generate_contiguous_shape(elem_type, dims_num, &dims[0]);
                for (size_t i = 0; i < strides_num; i++) {
                        if (strides[i] < m_shape.strides[i]) {
                                Log(KESTREL_WARNING, "impertinent stride configura!\n");
                        }
                        m_shape.strides[i] = strides[i];
                }
        }

        TensorShape(kestrel_data_type_e elem_type, size_t n, size_t c, size_t h, size_t w)
                : TensorShape(elem_type, std::vector<size_t>{ n, c, h, w })
        {
        }

        kestrel_data_type_e ElementType() const
        {
                return m_shape.elem_type;
        }

        size_t Count() const
        {
                return kestrel_tensor_count(&m_shape);
        }

        size_t Capacity() const
        {
                return kestrel_tensor_capacity(&m_shape);
        }

        size_t ElementSize() const
        {
                return kestrel_data_type_size(m_shape.elem_type);
        }

        size_t DimensionNumber() const
        {
                return m_shape.dims_num;
        }

        std::vector<size_t> Dimensions() const
        {
                std::vector<size_t> dims;
                for (size_t i = 0; i < DimensionNumber(); i++) {
                        dims.push_back(m_shape.dims[i]);
                }

                return dims;
        }

        size_t Width() const
        {
                return m_shape.dims[3];
        }

        size_t Height() const
        {
                return m_shape.dims[2];
        }

        size_t Channel() const
        {
                return m_shape.dims[1];
        }

        size_t Number() const
        {
                return m_shape.dims[0];
        }

        void Number(size_t n)
        {
                m_shape.dims[0] = n;
        }

        size_t Offset(size_t n, size_t c = 0, size_t h = 0, size_t w = 0) const
        {
                return kestrel_tensor_calc_offset(&(this->m_shape), n, c, h, w);
        }

        // size must TENSOR_MAX_NDIMS
        size_t Offset(std::vector<size_t> indices) const
        {
                while (indices.size() < this->m_shape.dims_num) {
                        indices.push_back(1);
                }
                if (indices.size() > this->m_shape.dims_num) {
                        indices.resize(this->m_shape.dims_num);
                }
                return kestrel_tensor_calc_offset_ex(&(this->m_shape), indices.data());
        }

        std::vector<size_t> Strides() const
        {
                std::vector<size_t> strides;
                for (size_t i = 0; i < DimensionNumber(); i++) {
                        strides.push_back(m_shape.strides[i]);
                }
                return strides;
        }

        bool IsContiguous() const
        {
                return kestrel_tensor_is_contiguous(&m_shape) == 1;
        }

        friend class Tensor;
        friend class NeuralNetwork;

protected:
        kestrel_tensor_meta_t m_shape;
};

class Tensor
{
public:
        Tensor() : m_tensor(nullptr)
        {
        }

        Tensor(const std::string &name, const TensorShape &shape,
               kestrel_mem_type_e cat = KESTREL_MEM_HOST)
        {
                kestrel_tensor_t *t = kestrel_tensor_alloc(name.c_str(), shape.m_shape, cat);
                m_tensor = std::shared_ptr<kestrel_tensor_t>(t, deltor);
        }

        Tensor(const std::string &name, const TensorShape &shape, void *data,
               kestrel_mem_type_e type, kestrel_buf_finalizer finalizer, void *finalizer_ud)
        {
                kestrel_tensor_t *t = kestrel_tensor_make(name.c_str(), shape.m_shape, data, type,
                                                          finalizer, finalizer_ud);
                m_tensor = std::shared_ptr<kestrel_tensor_t>(t, deltor);
        }

        Tensor(kestrel_tensor_t *tensor) : m_tensor(tensor, deltor)
        {
        }

        Tensor RoI(kestrel_range_t n, kestrel_range_t c = { 0, INT_MAX },
                   kestrel_range_t h = { 0, INT_MAX }, kestrel_range_t w = { 0, INT_MAX })
        {
                std::vector<kestrel_range_t> ranges{ n, c, h, w };
                return Tensor(kestrel_tensor_roi(this->m_tensor.get(), (int32_t)ranges.size(),
                                                 ranges.data()));
        }

        k_err Reset(int8_t val)
        {
                return kestrel_tensor_reset(this->m_tensor.get(), val);
        }

        kestrel_tensor_t *Raw() const
        {
                return m_tensor.get();
        }

        bool IsValid() const
        {
                return m_tensor != nullptr;
        }

        bool Allocate(const std::string &name, const TensorShape &shape, kestrel_mem_type_e cat)
        {
                if (IsValid()) {
                        return false;
                }
                this->~Tensor();
                new (this) Tensor(name, shape, cat);
                return IsValid();
        }

        void Free()
        {
                m_tensor.reset();
        }

        TensorShape Shape() const
        {
                TensorShape shape = TensorShape();
                if (IsValid()) {
                        shape.m_shape = m_tensor->meta;
                }
                return shape;
        }

        size_t Number() const
        {
                return this->m_tensor->meta.dims[0];
        }

        size_t Channel() const
        {
                return this->m_tensor->meta.dims[1];
        }

        size_t Height() const
        {
                return this->m_tensor->meta.dims[2];
        }

        size_t Width() const
        {
                return this->m_tensor->meta.dims[3];
        }

        kestrel_data_type_e ElementType() const
        {
                return this->m_tensor->meta.elem_type;
        }

        size_t Count() const
        {
                return kestrel_tensor_count(&(this->m_tensor->meta));
        }

        size_t Capacity() const
        {
                return kestrel_tensor_capacity(&(this->m_tensor->meta));
        }

        size_t ElementSize() const
        {
                return kestrel_data_type_size(this->m_tensor->meta.elem_type);
        }

        size_t DimensionNumber() const
        {
                return this->m_tensor->meta.dims_num;
        }

        std::string Name() const
        {
                return IsValid() ? std::string(m_tensor->name) : std::string();
        }

        kestrel_mem_type_e MemType() const
        {
                return kestrel_tensor_mem_type(m_tensor.get());
        }

        Buffer GetBuffer() const
        {
                if (IsValid()) {
                        return Buffer(kestrel_buffer_ref(m_tensor->buffer));
                }
                return Buffer();
        }

        size_t Offset(size_t n, size_t c = 0, size_t h = 0, size_t w = 0) const
        {
                return kestrel_tensor_calc_offset(&m_tensor->meta, n, c, h, w);
        }

        // size must TENSOR_MAX_NDIMS
        size_t Offset(std::vector<size_t> indices) const
        {
                while (indices.size() < m_tensor->meta.dims_num) {
                        indices.push_back(1);
                }
                if (indices.size() > m_tensor->meta.dims_num) {
                        indices.resize(m_tensor->meta.dims_num);
                }
                return kestrel_tensor_calc_offset_ex(&m_tensor->meta, indices.data());
        }

        void *Data() const
        {
                return kestrel_tensor_raw_pointer(m_tensor.get());
        }

        void *DataAt(size_t n, size_t c, size_t h, size_t w) const
        {
                return kestrel_tensor_data_at(m_tensor.get(), n, c, h, w);
        }

        void *DataAt(size_t offset) const
        {
                return kestrel_tensor_data_at_ex(m_tensor.get(), offset);
        }

        bool IsContiguous()
        {
                return kestrel_tensor_contiguous(m_tensor.get()) == 1;
        }

        Tensor Contiguous()
        {
                kestrel_tensor_contiguous(m_tensor.get());
                return *this;
        }

        k_err CopyTo(Tensor *dst) const
        {
                if (!dst->IsValid()) {
                        return CV_E_INVALIDARG;
                }
                return kestrel_tensor_copy(m_tensor.get(), dst->m_tensor.get());
        }

        k_err SetBatch(size_t n)
        {
                kestrel_tensor_meta_t m = m_tensor->meta;
                m.dims[0] = n;
                return kestrel_tensor_reshape(m_tensor.get(), m);
        }

        k_err Reshape(const TensorShape &shape)
        {
                return kestrel_tensor_reshape(m_tensor.get(), shape.m_shape);
        }

        Tensor Duplicate(kestrel_mem_type_e dst_mem_type) const
        {
                return Tensor(kestrel_tensor_duplicate(m_tensor.get(), dst_mem_type));
        }

        Tensor FromNpy(const std::string &filename, kestrel_mem_type_e mem_type)
        {
                return Tensor(kestrel_tensor_from_npy(filename.c_str(), "data", mem_type));
        }

        void ToNpy(const std::string &filename)
        {
                kestrel_tensor_to_npy(m_tensor.get(), filename.c_str());
        }

private:
        std::shared_ptr<kestrel_tensor_t> m_tensor;
        static void deltor(kestrel_tensor_t *p)
        {
                kestrel_tensor_free(&p);
        }
};

class MemPool
{
public:
        MemPool() : m_mp(nullptr)
        {
        }

        MemPool(kestrel_mempool_t *mp) : m_mp(mp, deltor)
        {
        }

        MemPool(kestrel_mem_type_e type, size_t pool_capacity, size_t granularity,
                uint32_t flags = KESTREL_MP_FLAG_DEFAULT)
        {
                kestrel_mempool mp =
                    kestrel_mempool_alloc(type, pool_capacity, granularity, flags);
                m_mp.reset(mp, deltor);
        }

        bool IsValid() const
        {
                return m_mp != nullptr;
        }

        bool Allocate(kestrel_mem_type_e type, size_t pool_capacity, size_t granularity,
                      uint32_t flags)
        {
                if (IsValid()) {
                        return false;
                }
                this->~MemPool();
                new (this) MemPool(type, pool_capacity, granularity, flags);
                return IsValid();
        }

        void Free()
        {
                m_mp.reset();
        }

        kestrel_mempool Raw() const
        {
                return m_mp.get();
        }

        size_t Capacity() const
        {
                return kestrel_mempool_capacity(m_mp.get());
        }

        size_t Granularity() const
        {
                return kestrel_mempool_granularity(m_mp.get());
        }

        kestrel_mem_type_e Type() const
        {
                return kestrel_mempool_mem_type(m_mp.get());
        }

        size_t Usage() const
        {
                return kestrel_mempool_usage(m_mp.get());
        }

        size_t Idle() const
        {
                return kestrel_mempool_idle(m_mp.get());
        }

        Buffer GetBuffer(size_t size) const
        {
                kestrel_buffer b = kestrel_mempool_get_buffer(m_mp.get(), size);
                return Buffer(b);
        }

        void *Get(size_t size) const
        {
                size_t real_size = size;
                void *ret = kestrel_mempool_get(m_mp.get(), &real_size);
                if (real_size >= size) {
                        return ret;
                }
                kestrel_mempool_put(m_mp.get(), ret);
                return nullptr;
        }

        k_err Put(void *data) const
        {
                return kestrel_mempool_put(m_mp.get(), data);
        }

private:
        std::shared_ptr<kestrel_mempool_t> m_mp;
        static void deltor(kestrel_mempool p)
        {
                kestrel_mempool_free(&p);
        }
};

class NeuralNetwork
{
public:
        NeuralNetwork() : m_net(nullptr)
        {
        }

        NeuralNetwork(kestrel_nn_t *net)
                : m_net(net, [](kestrel_nn nn) { kestrel_nn_destroy(&nn); })
        {
        }

        NeuralNetwork(const std::string &backend, const Model &m, const std::string &net_name,
                      const std::string &extra_cfg)
        {
                kestrel_nn net = kestrel_nn_create(backend.c_str(), m.Raw(), net_name.c_str(),
                                                   extra_cfg.c_str());
                m_net = std::shared_ptr<kestrel_nn_t>(
                    net, [](kestrel_nn nn) { kestrel_nn_destroy(&nn); });
        }

        bool IsValid() const
        {
                return m_net != nullptr;
        }

        bool Create(const std::string &backend, const Model &m, const std::string &net_name,
                    const std::string &extra_cfg)
        {
                if (IsValid()) {
                        return false;
                }
                this->~NeuralNetwork();
                new (this) NeuralNetwork(backend, m, net_name, extra_cfg);
                return IsValid();
        }

        void Free()
        {
                m_net.reset();
        }

        kestrel_nn_properties_t Properties() const
        {
                kestrel_nn_properties_t nn_prop;
                k_err ret = kestrel_nn_get_properties(m_net.get(), &nn_prop);
                if (ret != KESTREL_OK) {
                        nn_prop.cur_batch_size = -1;
                        nn_prop.max_batch_size = -1;
                        kestrel_log(KESTREL_ERROR,
                                    "NeuralNetwork::Properties() failed, error code: %d.\n", ret);
                }
                return nn_prop;
        }

        k_err Prepare() const
        {
                return kestrel_nn_prepare(m_net.get());
        }

        k_err ExtendOutput(const std::string &tensor_name) const
        {
                return kestrel_nn_extend_output(m_net.get(), tensor_name.c_str());
        }

        TensorShape GetTensorShape(const std::string &name) const
        {
                TensorShape shape = TensorShape();
                kestrel_nn_tensor_info(m_net.get(), name.c_str(), &shape.m_shape);
                return shape;
        }

        k_err SetBatch(const std::string &name, size_t n)
        {
                kestrel_tensor_meta_t meta;
                kestrel_nn_tensor_info(m_net.get(), name.c_str(), &meta);
                meta.dims[0] = n;
                return kestrel_nn_reshape(m_net.get(), name.c_str(), &meta);
        }

        k_err Reshape(const std::string &name, const TensorShape &shape)
        {
                return kestrel_nn_reshape(m_net.get(), name.c_str(), &shape.m_shape);
        }

        void *GetTensorMemoryPointer(const std::string &name)
        {
                return (void *)GetTensorByName(name).Data();
        }

        Tensor GetTensorByName(const std::string &name) const
        {
                kestrel_tensor_t *tensor = nullptr;
                kestrel_nn_get_tensor(m_net.get(), name.c_str(), &tensor);
                return Tensor(tensor);
        }

        k_err PreProcess(kestrel_frame_transform_param_t *param)
        {
                return kestrel_nn_preprocess(m_net.get(), param);
        }

        k_err Forward()
        {
                return kestrel_nn_forward(m_net.get());
        }

        k_err ForwardAsync(kestrel_event *e)
        {
                return kestrel_nn_forward_async(m_net.get(), e);
        }

        k_err ForwardAwait(kestrel_event e)
        {
                return kestrel_nn_forward_await(m_net.get(), e);
        }

private:
        std::shared_ptr<kestrel_nn_t> m_net;
};

template <typename UserData, typename ObjType> class KesonBridge
{
public:
        virtual keson Encode(UserData *ud, const ObjType &obj) = 0;
        virtual void ReleaseEncodedData(UserData *ud, keson *encoded_data) = 0;
        virtual ObjType Decode(UserData *ud, keson k) = 0;
};

template <typename UserData, typename ObjType> class AnnotatorTemp
{
public:
        AnnotatorTemp() : err_code(KESTREL_OK)
        {
        }

        AnnotatorTemp(const std::string &annotator, const std::string &config)
        {
                kestrel_annotator hdl = kestrel_annotator_open(annotator.c_str(), config.c_str());
                m_hdl = std::shared_ptr<kestrel_annotator_t>(
                    hdl, [](kestrel_annotator p) { kestrel_annotator_close(&p); });
                name = annotator;
                err_code = IsValid() ? KESTREL_OK : KESTREL_ERR;
        }

        bool Create(const std::string &annotator, const std::string &config)
        {
                if (IsValid()) {
                        return false;
                }
                this->~AnnotatorTemp();
                new (this) AnnotatorTemp(annotator, config);
                return IsValid();
        }

        void Free()
        {
                m_hdl.reset();
        }

        bool IsValid() const
        {
                return m_hdl != nullptr;
        }

        std::string Version() const
        {
                const char *s = kestrel_plugin_version(name.c_str());
                return s == NULL ? std::string() : std::string(s);
        }

        std::string Revision() const
        {
                const char *s = kestrel_plugin_revision(name.c_str());
                return s == NULL ? std::string() : std::string(s);
        }

        std::string ConfigSchema() const
        {
                const char *s = kestrel_annotator_get_config_schema(name.c_str());
                return s == nullptr ? "" : std::string(s);
        }

        std::string ParamsSchema() const
        {
                const char *s = kestrel_annotator_get_params_schema(name.c_str());
                return s == nullptr ? "" : std::string(s);
        }

        std::string ResultSchema() const
        {
                const char *s = kestrel_annotator_get_result_schema(name.c_str());
                return s == nullptr ? "" : std::string(s);
        }

        keson Startup(keson in)
        {
                keson out = nullptr;
                err_code = kestrel_annotator_startup(m_hdl.get(), in, &out);
                return out;
        }

        ObjType Startup(UserData *ud, const ObjType &obj)
        {
                KesonBridge<UserData, ObjType> bridge;
                keson cin = bridge.Encode(ud, obj);
                keson cout = nullptr;
                err_code = kestrel_annotator_startup(m_hdl.get(), cin, &cout);
                bridge.ReleaseEncodedData(ud, &cin);
                ObjType out = bridge.Decode(ud, cout);
                return out;
        }

        ObjType Process(UserData *ud, const ObjType &obj)
        {
                KesonBridge<UserData, ObjType> bridge;
                keson cin = bridge.Encode(ud, obj);
                keson cout = nullptr;
                err_code = kestrel_annotator_process(m_hdl.get(), cin, &cout);
                bridge.ReleaseEncodedData(ud, &cin);
                ObjType out = bridge.Decode(ud, cout);
                return out;
        }

        // Keep for FFI
        keson Process(keson in)
        {
                keson out = nullptr;
                err_code = kestrel_annotator_process(m_hdl.get(), in, &out);
                return out;
        }

        keson Terminate(keson in)
        {
                keson out = nullptr;
                kestrel_annotator_terminate(m_hdl.get(), in, &out);
                return out;
        }

        ObjType Terminate(UserData *ud, const ObjType &obj)
        {
                KesonBridge<UserData, ObjType> bridge;
                keson cin = bridge.Encode(ud, obj);
                keson cout = nullptr;
                err_code = kestrel_annotator_terminate(m_hdl.get(), cin, &cout);
                bridge.ReleaseEncodedData(ud, &cin);
                ObjType out = bridge.Decode(ud, cout);
                return out;
        }

        k_err GetLastError() const
        {
                return err_code;
        }

private:
        std::shared_ptr<kestrel_annotator_t> m_hdl;
        std::string name;
        k_err err_code;
};

class Frame
{
public:
        Frame() : m_frame(nullptr)
        {
        }

        Frame(kestrel_frame_t *f) : m_frame(f, deltor)
        {
        }

        Frame(kestrel_mem_type_e type, kestrel_video_format_e fmt, int32_t width, int32_t height,
              std::vector<int32_t> strides = { 0, 0, 0, 0 }, int64_t pts = 0)
        {
                while (strides.size() < 4) {
                        strides.push_back(0);
                }
                if (strides.size() > 4) {
                        strides.resize(4);
                }
                kestrel_frame_t *f =
                    kestrel_frame_alloc(type, fmt, width, height, strides.data(), pts);

                m_frame.reset(f, deltor);
        }

        Frame(kestrel_mem_type_e type, kestrel_video_format_e fmt, uint8_t *data, int32_t width,
              int32_t height, std::vector<int32_t> strides = { 0, 0, 0, 0 }, int64_t pts = 0,
              kestrel_buf_finalizer finalizer = nullptr, void *ud = nullptr)
        {
                while (strides.size() < 4) {
                        strides.push_back(0);
                }
                if (strides.size() > 4) {
                        strides.resize(4);
                }

                kestrel_frame_t *f = kestrel_frame_make(type, fmt, data, width, height,
                                                        strides.data(), pts, finalizer, ud);
                m_frame.reset(f, deltor);
        }

        bool IsValid() const
        {
                return m_frame != nullptr;
        }

        bool Allocate(kestrel_mem_type_e type, kestrel_video_format_e fmt, int32_t width,
                      int32_t height, std::vector<int32_t> strides = { 0, 0, 0, 0 },
                      int64_t pts = 0)
        {
                if (IsValid()) {
                        kestrel_log(KESTREL_ERROR,
                                    "Frame::Alloc() failed, need an empty frame.\n");
                        return false;
                }

                this->~Frame();
                new (this) Frame(type, fmt, width, height, strides, pts);
                return IsValid();
        }

        void Free()
        {
                m_frame.reset();
        }

        kestrel_mem_type_e MemType() const
        {
                return kestrel_frame_mem_type(m_frame.get());
        }

        kestrel_video_format_e Format() const
        {
                if (IsValid()) {
                        return m_frame->video.fmt;
                }
                return KESTREL_VIDEO_NONE;
        }

        const char *FormatString() const
        {
                if (IsValid()) {
                        return kestrel_frame_pixfmt_to_string(m_frame->video.fmt);
                }
                return "none";
        }

        int32_t Width() const
        {
                return IsValid() ? m_frame->video.width : -1;
        }

        int32_t Height() const
        {
                return IsValid() ? m_frame->video.height : -1;
        }

        std::vector<int32_t> Strides() const
        {
                std::vector<int32_t> strides;
                if (IsValid()) {
                        size_t n = kestrel_frame_plane_num(m_frame->video.fmt);
                        for (size_t i = 0; i < n; i++) {
                                strides.push_back(m_frame->video.stride[i]);
                        }
                }
                return strides;
        }

        int32_t Stride(size_t index) const
        {
                if (IsValid() && index < m_frame->plane_num) {
                        return m_frame->video.stride[index];
                }
                return -1;
        }

        uint8_t *Plane(size_t index) const
        {
                if (IsValid() && index < m_frame->plane_num) {
                        return m_frame->plane[index];
                }
                return nullptr;
        }

        size_t PlaneNum() const
        {
                if (IsValid()) {
                        return kestrel_frame_plane_num(this->Format());
                }
                return 0;
        }

        uint8_t *Data() const
        {
                if (IsValid()) {
                        return m_frame->plane[0];
                }
                return nullptr;
        }

        size_t Size() const
        {
                return kestrel_frame_size(m_frame.get());
        }

        int64_t Timestamp() const
        {
                if (IsValid()) {
                        return m_frame->pts;
                }
                return -1;
        }

        int64_t StreamId() const
        {
                if (IsValid()) {
                        return m_frame->stream_id;
                }
                return -1;
        }
        void SetStreamId(int64_t stream_id)
        {
                if (!IsValid()) {
                        return;
                }
                m_frame->stream_id = stream_id;
        }

        void SetTimestamp(int64_t pts)
        {
                if (!IsValid()) {
                        return;
                }
                m_frame->pts = pts;
        }

        k_err Save(const std::string &filename) const
        {
                return kestrel_frame_save(this->Raw(), filename.c_str());
        }

        Frame Host() const
        {
                if (!IsValid()) {
                        return Frame();
                }

                if (MemType() == KESTREL_MEM_HOST) {
                        return *this;
                }

                return Download();
        }

        Frame Device() const
        {
                if (!IsValid()) {
                        return Frame();
                }

                if (MemType() == KESTREL_MEM_DEVICE) {
                        return *this;
                }

                return Upload();
        }

        Frame Download() const
        {
                kestrel_frame_t *out_frame = nullptr;
                if (IsValid() && MemType() == KESTREL_MEM_DEVICE) {
                        kestrel_frame_download(m_frame.get(), &out_frame);
                }
                return Frame(out_frame);
        }

        k_err Download(Frame *out) const
        {
                if (IsValid() && out->IsValid() && MemType() == KESTREL_MEM_DEVICE) {
                        kestrel_frame_t *out_frame = out->Raw();
                        return kestrel_frame_download(m_frame.get(), &out_frame);
                }
                return CV_E_FAIL;
        }

        Frame Upload() const
        {
                kestrel_frame_t *out_frame = nullptr;
                if (IsValid() && MemType() == KESTREL_MEM_HOST) {
                        kestrel_frame_upload(m_frame.get(), &out_frame);
                }
                return Frame(out_frame);
        }

        k_err Upload(Frame *out) const
        {
                if (IsValid() && out->IsValid() && MemType() == KESTREL_MEM_HOST) {
                        kestrel_frame_t *out_frame = out->Raw();
                        return kestrel_frame_upload(m_frame.get(), &out_frame);
                }
                return CV_E_FAIL;
        }

        bool IsContiguous() const
        {
                return kestrel_frame_is_contiguous(m_frame.get()) != 0;
        }

        Frame Contiguous() const
        {
                if (IsContiguous()) {
                        return *this;
                }
                return Duplicate();
        }

        void Swap(const Frame &that)
        {
                std::swap(this->m_frame, const_cast<Frame &>(that).m_frame);
        }

        Frame Resize(const Size2D &size, k_err *err = nullptr) const
        {
                kestrel_frame_t *out = nullptr;
                k_err r = kestrel_frame_resize(this->Raw(), &out, size);
                if (err) {
                        *err = r;
                }
                return Frame(out);
        }

        Frame Crop(const Area2D &area, k_err *err = nullptr) const
        {
                kestrel_frame_t *out = nullptr;
                k_err r = kestrel_frame_crop(this->Raw(), &out, area);
                if (err) {
                        *err = r;
                }
                return Frame(out);
        }

        Frame Scale(float scale, k_err *err = nullptr) const
        {
                kestrel_frame_t *out = nullptr;
                k_err r = kestrel_frame_scale(this->Raw(), &out, scale);
                if (err) {
                        *err = r;
                }
                return Frame(out);
        }

        Frame Rotate(kestrel_orientation_e type, k_err *err = nullptr) const
        {
                kestrel_frame_t *out = nullptr;
                k_err r = kestrel_frame_rotate(this->Raw(), &out, type);
                if (err) {
                        *err = r;
                }
                return Frame(out);
        }

        Frame CvtColor(kestrel_video_format_e type, k_err *err = nullptr) const
        {
                kestrel_frame_t *out = nullptr;
                k_err r = kestrel_frame_cvt_color(this->Raw(), &out, type);
                if (err) {
                        *err = r;
                }
                return Frame(out);
        }

        Frame operator()(const Area2D &area) const
        {
                return RoI(area);
        }

        kestrel_frame_t *Raw() const
        {
                return m_frame.get();
        }

        k_err Reset(uint8_t val)
        {
                return kestrel_frame_reset(m_frame.get(), val);
        }

        Frame RoI(const Area2D &area) const
        {
                return Frame(kestrel_frame_roi(m_frame.get(), area));
        }

        int32_t RefCount() const
        {
                return kestrel_frame_get_ref_cnt(m_frame.get());
        }

        Frame Duplicate() const
        {
                return Frame(kestrel_frame_duplicate(m_frame.get()));
        }

        k_err CopyTo(Frame *out) const
        {
                if (IsValid() && out->IsValid()) {
                        kestrel_frame_t *o = out->Raw();
                        return kestrel_frame_copy(m_frame.get(), &o);
                }
                return CV_E_HANDLE;
        }

        k_err AttachExtraInfo(const Buffer &buf)
        {
                return kestrel_frame_attach_extra_info(m_frame.get(), buf.Raw());
        }

        Buffer GetExtraInfo() const
        {
                kestrel_buffer buf = kestrel_frame_get_extra_info(m_frame.get());
                return Buffer(kestrel_buffer_ref(buf));
        }

        Buffer DetachExtraInfo()
        {
                return Buffer(kestrel_frame_detach_extra_info(m_frame.get()));
        }

        k_err CopyAsync(Frame *out, kestrel_event *e) const
        {
                if (!out->IsValid()) {
                        return CV_E_HANDLE;
                }
                kestrel_frame_t *o = out->Raw();
                return kestrel_frame_copy_async(m_frame.get(), &o, e);
        }

        k_err DownloadAsync(Frame *out, kestrel_event *e) const
        {
                if (!out->IsValid()) {
                        return CV_E_HANDLE;
                }
                kestrel_frame_t *o = out->Raw();
                return kestrel_frame_download_async(m_frame.get(), &o, e);
        }

        k_err UploadAsync(Frame *out, kestrel_event *e) const
        {
                if (!out->IsValid()) {
                        return CV_E_HANDLE;
                }
                kestrel_frame_t *o = out->Raw();
                return kestrel_frame_upload_async(m_frame.get(), &o, e);
        }

        k_err CopyAwait(kestrel_event e) const
        {
                return kestrel_frame_copy_await(e, nullptr);
        }

private:
        std::shared_ptr<kestrel_frame_t> m_frame;
        static void deltor(kestrel_frame_t *p)
        {
                kestrel_frame_free(&p);
        }
};

class FramePool
{
public:
        FramePool() : m_fp(nullptr)
        {
        }

        FramePool(kestrel_frame_pool fp) : m_fp(fp, deltor)
        {
        }

        FramePool(kestrel_mem_type_e mem_type, const kestrel_video_param_t &param,
                  size_t capacity)
        {
                kestrel_frame_pool fp = kestrel_frame_pool_alloc(mem_type, param, capacity);
                m_fp.reset(fp, deltor);
        }

        bool IsValid() const
        {
                return m_fp != nullptr;
        }

        bool Allocate(kestrel_mem_type_e mem_type, const kestrel_video_param_t &param,
                      size_t capacity)
        {
                if (IsValid()) {
                        return false;
                }

                this->~FramePool();
                new (this) FramePool(mem_type, param, capacity);
                return IsValid();
        }

        void Free()
        {
                m_fp.reset();
        }

        kestrel_frame_pool Raw() const
        {
                return m_fp.get();
        }

        size_t Capacity() const
        {
                return kestrel_frame_pool_capacity(m_fp.get());
        }

        size_t Usage() const
        {
                return kestrel_frame_pool_usage(m_fp.get());
        }

        size_t Allocated() const
        {
                return kestrel_frame_pool_allocated(m_fp.get());
        }

        kestrel_mem_type_e Type() const
        {
                return kestrel_frame_pool_mem_type(m_fp.get());
        }

        Kestrel::Frame Get() const
        {
                return Kestrel::Frame(kestrel_frame_pool_get(m_fp.get()));
        }

private:
        std::shared_ptr<kestrel_frame_pool_t> m_fp;
        static void deltor(kestrel_frame_pool p)
        {
                kestrel_frame_pool_free(&p);
        }
};

class FrameUtils
{
public:
        static Frame Load(const std::string &filename)
        {
                kestrel_frame_t *frame = kestrel_frame_load(filename.c_str());
                return Frame(frame);
        }

        static k_err Save(const Frame &in, const std::string &filename)
        {
                return kestrel_frame_save(in.Raw(), filename.c_str());
        }

        static k_err Encode(const Frame &in, kestrel_frame_enc_format_e enc, Buffer *out)
        {
                return kestrel_frame_encode(in.Raw(), enc, out->Raw());
        }

        static k_err Resize(const Frame &in, Frame *out, const Size2D &size)
        {
                if (!in.IsValid() || out == nullptr) {
                        return CV_E_UNSUPPORTED;
                }

                kestrel_frame_t *tmp = out->IsValid() ? out->Raw() : nullptr;
                k_err err = kestrel_frame_resize(in.Raw(), &tmp, size);

                if (!out->IsValid()) {
                        out->Swap(Frame(tmp));
                }

                return err;
        }

        static k_err Scale(const Frame &in, Frame *out, float scale)
        {
                if (!in.IsValid() || out == nullptr) {
                        return CV_E_UNSUPPORTED;
                }

                kestrel_frame_t *tmp = out->IsValid() ? out->Raw() : nullptr;
                k_err err = kestrel_frame_scale(in.Raw(), &tmp, scale);

                if (!out->IsValid()) {
                        out->Swap(Frame(tmp));
                }

                return err;
        }

        static k_err Rotate(const Frame &in, Frame *out, kestrel_orientation_e type)
        {
                if (!in.IsValid() || out == nullptr) {
                        return CV_E_UNSUPPORTED;
                }

                kestrel_frame_t *tmp = out->IsValid() ? out->Raw() : nullptr;
                k_err err = kestrel_frame_rotate(in.Raw(), &tmp, type);

                if (!out->IsValid()) {
                        out->Swap(Frame(tmp));
                }

                return err;
        }

        static k_err CvtColor(const Frame &in, Frame *out, kestrel_video_format_e type)
        {
                if (!in.IsValid() || out == nullptr) {
                        return CV_E_UNSUPPORTED;
                }

                kestrel_frame_t *tmp = out->IsValid() ? out->Raw() : nullptr;
                k_err err = kestrel_frame_cvt_color(in.Raw(), &tmp, type);

                if (!out->IsValid()) {
                        out->Swap(Frame(tmp));
                }

                return err;
        }

        static k_err Crop(const Frame &in, Frame *out, Area2D area)
        {
                if (!in.IsValid() || out == nullptr) {
                        return CV_E_UNSUPPORTED;
                }

                kestrel_frame_t *tmp = out->IsValid() ? out->Raw() : nullptr;
                k_err err = kestrel_frame_crop(in.Raw(), &tmp, area);

                if (!out->IsValid()) {
                        out->Swap(Frame(tmp));
                }

                return err;
        }

        static k_err WarpAffineWithBorder(const Frame &in, Frame *out, float mat[2][3],
                                          uint8_t border_value)
        {
                if (!in.IsValid() || out == nullptr || !out->IsValid()) {
                        return CV_E_UNSUPPORTED;
                }

                kestrel_frame_t *tmp = out->Raw();
                k_err err =
                    kestrel_frame_warpaffine_with_border(in.Raw(), tmp, mat, border_value);

                return err;
        }

        static k_err WarpAffine(const Frame &in, Frame *out, float mat[2][3])
        {
                return WarpAffineWithBorder(in, out, mat, 0);
        }

        static k_err WarpPerspectiveWithBorder(const Frame &in, Frame *out, float mat[3][3],
                                               uint8_t border_value)
        {
                if (!in.IsValid() || out == nullptr || !out->IsValid()) {
                        return CV_E_UNSUPPORTED;
                }

                kestrel_frame_t *tmp = out->Raw();
                k_err err =
                    kestrel_frame_warpperspective_with_border(in.Raw(), tmp, mat, border_value);

                return err;
        }

        static k_err WarpPerspective(const Frame &in, Frame *out, float mat[3][3])
        {
                return WarpPerspectiveWithBorder(in, out, mat, 0);
        }

        static k_err ToTensor(const Frame &in, Tensor *t, int32_t offset,
                              kestrel_tensor_color_e tensor_color, kestrel_pixel_t means,
                              kestrel_pixel_t stds, kestrel_pixel_t paddings)
        {
                if (!in.IsValid() || t == nullptr || !t->IsValid()) {
                        return CV_E_UNSUPPORTED;
                }

                k_err err = kestrel_frame_to_tensor(t->Raw(), offset, tensor_color, in.Raw(),
                                                    means, stds, paddings);

                return err;
        }

        size_t InferredSize(kestrel_video_format_e fmt, int32_t w, int32_t h,
                            std::vector<int32_t> strides = { 0, 0, 0, 0 })
        {
                while (strides.size() < 4) {
                        strides.push_back(0);
                }
                if (strides.size() > 4) {
                        strides.resize(4);
                }
                return kestrel_frame_inferred_size(fmt, w, h, strides.data());
        }

        static std::vector<Kestrel::Frame> TensorToFrames(const Kestrel::Tensor &tensor,
                                                          kestrel_tensor_color_e tensor_color)
        {
                size_t number = tensor.Shape().Number();
                std::vector<Kestrel::Frame> frames;

                for (size_t i = 0; i < number; i++) {
                        kestrel_frame_t *frame = NULL;
                        kestrel_tensor_to_frames(tensor.Raw(), tensor_color, i, &frame);
                        frames.push_back(Kestrel::Frame(frame));
                }

                return frames;
        }

        static k_err EqualizeHist(const Frame &in, Frame *out)
        {
                kestrel_frame_t *tmp = out->Raw();
                k_err err = kestrel_frame_equalize_hist(in.Raw(), &tmp);
                return err;
        }
};

class Transformer // NOLINT
{
public:
        Transformer(kestrel_resize_param_e resize_param, kestrel_pixel_t means = { 0, 0, 0 },
                    kestrel_pixel_t stds = { 1, 1, 1 })
                : resize_param_(resize_param), buffer_(nullptr), means_(means), stds_(stds)
        {
        }
        ~Transformer()
        {
                kestrel_buffer_free(&buffer_);
        }

        k_err ToTensor(Tensor *tensor, kestrel_tensor_color_e tensor_color,
                       const std::vector<Frame> &frames)
        {
                std::vector<kestrel_frame_t *> c_frames;
                c_frames.reserve(frames.size());
                std::vector<Area2D> rois;
                rois.reserve(frames.size());

                for (auto &&f : frames) {
                        rois.push_back(Area2D{ 0, 0, f.Width(), f.Height() });
                        c_frames.emplace_back(f.Raw());
                }

                this->scale_heights_.resize(frames.size());
                this->scale_widths_.resize(frames.size());
                k_err err = kestrel_frame_transform_to_tensor_batch(
                    tensor->Raw(), tensor_color, frames.size(), c_frames.data(), rois.data(),
                    this->resize_param_, this->means_, this->stds_, nullptr, &buffer_,
                    this->scale_heights_.data(), this->scale_widths_.data());
                return err;
        }

        k_err ToTensor(Tensor *tensor, kestrel_tensor_color_e tensor_color,
                       const std::vector<Frame> &frames, const std::vector<Area2D> &rois)
        {
                if (frames.size() != rois.size()) {
                        kestrel_log(KESTREL_ERROR,
                                    "frames size [%d] and rois size [%d] not match\n",
                                    frames.size(), rois.size());
                        return CV_E_INVALIDARG;
                }

                std::vector<kestrel_frame_t *> c_frames;
                c_frames.reserve(frames.size());

                for (auto &&f : frames) {
                        c_frames.emplace_back(f.Raw());
                }

                this->scale_heights_.resize(frames.size());
                this->scale_widths_.resize(frames.size());

                return kestrel_frame_transform_to_tensor_batch(
                    tensor->Raw(), tensor_color, frames.size(), c_frames.data(), rois.data(),
                    this->resize_param_, this->means_, this->stds_, nullptr, &buffer_,
                    this->scale_heights_.data(), this->scale_widths_.data());
        }

        k_err ToTensor(Tensor *tensor, kestrel_tensor_color_e tensor_color,
                       const std::vector<Frame> &frames, const std::vector<Area2D> &rois,
                       const std::vector<kestrel_pixel_t> &paddings)
        {
                if (frames.size() != rois.size()) {
                        kestrel_log(KESTREL_ERROR,
                                    "frames size [%d] and rois size [%d] not match\n",
                                    frames.size(), rois.size());
                        return CV_E_INVALIDARG;
                }
                if (frames.size() != paddings.size()) {
                        kestrel_log(KESTREL_ERROR,
                                    "frames size [%d] and paddings size [%d] not match\n",
                                    frames.size(), paddings.size());
                        return CV_E_INVALIDARG;
                }

                std::vector<kestrel_frame_t *> c_frames;
                c_frames.reserve(frames.size());

                for (auto &&f : frames) {
                        c_frames.emplace_back(f.Raw());
                }

                this->scale_heights_.resize(frames.size());
                this->scale_widths_.resize(frames.size());

                return kestrel_frame_transform_to_tensor_batch(
                    tensor->Raw(), tensor_color, frames.size(), c_frames.data(), rois.data(),
                    this->resize_param_, this->means_, this->stds_, paddings.data(), &buffer_,
                    this->scale_heights_.data(), this->scale_widths_.data());
        }

        const std::vector<float> &heights_scale() const
        {
                return this->scale_heights_;
        }

        const std::vector<float> &widths_scale() const
        {
                return this->scale_widths_;
        }

private:
        kestrel_resize_param_e resize_param_;
        kestrel_buffer buffer_;
        kestrel_pixel_t means_;
        kestrel_pixel_t stds_;
        std::vector<float> scale_heights_;
        std::vector<float> scale_widths_;
};

} // namespace Kestrel

#endif
