#ifndef KESTREL_KESTREL_H
#define KESTREL_KESTREL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "kestrel_core.h"

/// @defgroup kestrel Kestrel
///
/// Kestrel API provides following features:
///
/// ## Implements some useful structures
///
/// It defines @ref kestrel_struct, @ref kestrel_packet, @ref kestrel_frame and @ref
/// kestrel_tensor to facilitates Kestrel solve problems in video intelligent domain.
///
/// ## Extends Kestrel plug-in & improve plug-in management
///
/// Kestrel defines @ref kestrel_nn and @ref kestrel_annotator plug-ins, which are based on
/// kestrel core plug-in definition, and provides self management capacity, so in most situations,
/// user **DO NOT** need call kestrel_plugin_xxx APIs to manage annotator & nn, because Kestrel
/// Environment will manage them automatically, the only other thing to watch out for is that user
/// have to register static plug-ins manually by invoking kestrel_plugin_setup_builtin(), since
/// static plug-in could not be dynamic found at runtime.
///
/// In summary, Kestrel Environment manage all life cycle for shared plug-ins, and almost all
/// life cycle (besides setup phase) for static plug-in.
///
/// ## Defines Keson & KEPI protocol.
///
/// Kestrel defines @ref kestrel_keson and @ref kestrel_kepi so as to standardize communication
/// mode because plug-ins.
///
/// ## Warps Kestrel Core Environment management
///
/// Kestrel provides a high level kestrel_init() / kestrel_deinit(), it constructs/desconstucts
/// Kestrel Core Environment, and keeps some necessary information for Kestrel, e.g. keson
/// extensions, isomeric frame cache, etc.
///
/// @{

/// @defgroup kestrel_env Environment
/// Kestrel Environment API
/// @{
#include "kestrel/kestrel_env.h"
/// @}

/// @defgroup kestrel_error Error
/// Kestrel Error Definitions
/// @{
#include "kestrel/kestrel_error.h"
/// @}

/// @defgroup kestrel_struct Struct
/// Kestrel Struct Definition
/// @{
#include "kestrel/kestrel_struct.h"
/// @}

/// @defgroup kestrel_buffer Buffer
/// Kestrel Buffer API
/// @{
#include "kestrel/kestrel_buffer.h"
/// @}

/// @defgroup kestrel_mempool Mempool
/// Kestrel Mempool API
/// @{
#include "kestrel/kestrel_mempool.h"
/// @}

/// @defgroup kestrel_packet Packet
/// Kestrel Packet API
/// @{
#include "kestrel/kestrel_packet.h"
/// @}

/// @defgroup kestrel_frame Frame
/// Kestrel Frame API
/// @{
#include "kestrel/kestrel_frame.h"
/// @}

/// @defgroup kestrel_tensor Tensor
/// Kestrel Tensor API
/// @{
#include "kestrel/kestrel_tensor.h"
/// @}

/// @defgroup kestrel_nn Neural Network
/// Kestrel Neural Network API
/// @{
#include "kestrel/kestrel_nn.h"
/// @}

/// @defgroup kestrel_annotator Annotator
/// Kestrel annotator API
/// @{
#include "kestrel/kestrel_annotator.h"
/// @}

/// @defgroup kestrel_codec Codec
/// Kestrel Decode/Encoder API
/// @{
#include "kestrel/kestrel_codec.h"
/// @}

/// @defgroup kestrel_keson KesON
/// Kestrel Object Notation
/// @{
#include "kestrel/kestrel_keson.h"
/// @}

/// @defgroup kestrel_kepi Kepi Protocol
/// Kestrel Extension Plug-in Invoke Protocol
/// @{
#include "kestrel/kestrel_kepi.h"
/// @}

/// @}

#ifdef __cplusplus
}
#endif

#endif
