#ifndef KESTREL_AUX_KESTREL_NN_UTILS_H
#define KESTREL_AUX_KESTREL_NN_UTILS_H

#include <unordered_map>
#include <string>
#include <kestrel_core/kestrel_define.h>
#include <kestrel.hh>
#include <keson.hh>

#define KES_CHECK(e) ((e) == KESTREL_OK)

namespace Kestrel
{
namespace Aux
{

static const char *nn_schema = R"(
{
 "type": "object",
 "properties": {
   "net": {
     "type": "string",
     "default": ""
   },
   "backend": {
     "type": "string",
     "default": ""
   },
   "max_batch_size": {
     "type": "integer",
     "default": 0
   },
   "input": {
     "type": "object"
   },
   "output": {
     "type": "object"
   },
   "marked_output": {
     "type": "object"
   }
 },
"required": [
 "net",
 "backend"
]
}

)";

typedef struct kestrel_nn_cfg {
        std::string net;
        std::string backend;
        int32_t max_batch_size;
        std::unordered_map<std::string, std::string> input;
        std::unordered_map<std::string, std::string> output;
        std::unordered_map<std::string, std::string> marked_output;
        std::unordered_map<std::string, std::string> tensor_names;
} kestrel_nn_cfg;

class NeuralNetworkWrapper // NOLINT
{
public:
        NeuralNetworkWrapper(const Model &m, const std::string &net_name,
                             const std::string &extra_cfg, const std::string &appoint_backend)
        {
                parse_json_to_config(m, net_name.c_str());
                std::string extraCfg = extra_cfg;
                if (extraCfg.empty() || extraCfg == "{}") {
                        if (m_netcfg.max_batch_size != 0) {
                                Keson::Value obj = { { "max_batch_size",
                                                       m_netcfg.max_batch_size } };
                                extraCfg = obj.ToString();
                        }
                }
                nn_load(m, extraCfg, appoint_backend);
        }

        std::string GetBackend() const
        {
                return m_netcfg.backend;
        }

        bool IsValid() const
        {
                return m_net.IsValid();
        }

        int32_t GetMaxBatch() const
        {
                kestrel_nn_properties_t p = m_net.Properties();
                return p.max_batch_size;
        }

        // read from model/parameter.json{"model_files":{"max_batch_size":value}}
        size_t GetDefaultMaxBatch() const
        {
                return m_netcfg.max_batch_size;
        }

        kestrel_nn_properties_t GetProperties() const
        {
                return m_net.Properties();
        }

        bool Prepare() const
        {
                k_err r = m_net.Prepare();
                return KES_CHECK(r);
        }

        bool IsExistTensor(const std::string &name)
        {
                return m_netcfg.tensor_names.find(name) != m_netcfg.tensor_names.end();
        }

        Kestrel::TensorShape TensorInfo(const std::string &name) const
        {
                return m_net.GetTensorShape(m_netcfg.tensor_names.at(name));
        }

        bool SetBatch(const std::string &name, size_t n)
        {
                k_err r = m_net.SetBatch(m_netcfg.tensor_names[name], n);
                return KES_CHECK(r);
        }

        bool Reshape(const std::string &name, const Kestrel::TensorShape &shape)
        {
                k_err r = m_net.Reshape(m_netcfg.tensor_names[name], shape);
                return KES_CHECK(r);
        }

        void *GetTensorMemoryPointer(const std::string &name)
        {
                return m_net.GetTensorMemoryPointer(m_netcfg.tensor_names[name]);
        }

        Tensor GetTensorByName(const std::string &tensor_name) const
        {
                return m_net.GetTensorByName(m_netcfg.tensor_names.at(tensor_name));
        }

        bool PreProcess(kestrel_frame_transform_param_t *param)
        {
                k_err r = m_net.PreProcess(param);
                return KES_CHECK(r);
        }

        bool Forward()
        {
                k_err r = m_net.Forward();
                return KES_CHECK(r);
        }

        bool ForwardAsync(kestrel_event *e)
        {
                k_err r = m_net.ForwardAsync(e);
                return KES_CHECK(r);
        }

        bool ForwardAwait(kestrel_event e)
        {
                k_err r = m_net.ForwardAwait(e);
                return KES_CHECK(r);
        }

        ~NeuralNetworkWrapper()
        {
        }

private:
        k_err parse_json_to_config(const Model &model, const char *net)
        {
                const char *param_file = "parameters.json";

                std::string params = model.GetFile(param_file);

                if (params.empty()) {
                        kestrel_log(KESTREL_ERROR, "Malformed model, can not find meta.json!\n");
                        return CV_E_READ_FILE_FAIL;
                }
                Kestrel::Keson::Value model_cfg = Kestrel::Keson::Parse(params);

                if (!model_cfg.IsValid()) {
                        kestrel_log(KESTREL_ERROR, "Model config parse failed!\n");
                        return CV_E_READ_FILE_FAIL;
                }

                Kestrel::Keson::ValueRef model_file = model_cfg["model_files"][net];

                if (!model_file.IsValid()) {
                        kestrel_log(KESTREL_ERROR, "Model config %s key is not exist!\n", net);
                        return CV_E_READ_FILE_FAIL;
                }

                std::unordered_map<std::string, std::string> empty;
                m_netcfg.input.swap(empty);
                m_netcfg.output.swap(empty);
                m_netcfg.marked_output.swap(empty);
                m_netcfg.tensor_names.swap(empty);
                m_netcfg.net.clear();
                m_netcfg.backend.clear();
                m_netcfg.max_batch_size = 0;

                Kestrel::Keson::ValueRef knet = model_file["net"];
                if (knet.IsValid()) {
                        m_netcfg.net = knet.StringValue();
                }

                Kestrel::Keson::ValueRef backend = model_file["backend"];
                if (backend.IsValid()) {
                        m_netcfg.backend = backend.StringValue();
                }

                Kestrel::Keson::ValueRef max_batch_size = model_file["max_batch_size"];
                if (max_batch_size.IsValid()) {
                        m_netcfg.max_batch_size = (int32_t)max_batch_size.IntValue();
                }

                if (model_file.HasMember("input")) {
                        Kestrel::Keson::ValueRef input = model_file["input"];
                        for (auto kv = input.Begin(); kv != input.End(); kv = kv.Next()) {
                                if (kv.StringValue().empty()) {
                                        kestrel_log(KESTREL_WARNING,
                                                    "Empty tensor name key: %s !\n", kv.c_key());
                                        continue;
                                }
                                m_netcfg.input[kv.Key()] = kv.StringValue();
                                m_netcfg.tensor_names[kv.Key()] = kv.StringValue();
                        }
                }

                if (model_file.HasMember("output")) {

                        Kestrel::Keson::ValueRef output = model_file["output"];
                        for (auto kv = output.Begin(); kv != output.End(); kv = kv.Next()) {
                                if (kv.StringValue().empty()) {
                                        kestrel_log(KESTREL_WARNING,
                                                    "Empty tensor name key: %s !\n", kv.c_key());
                                        continue;
                                }
                                m_netcfg.output[kv.Key()] = kv.StringValue();
                                m_netcfg.tensor_names[kv.Key()] = kv.StringValue();
                        }
                }

                if (model_file.HasMember("marked_output")) {

                        Kestrel::Keson::ValueRef marked_output = model_file["marked_output"];
                        for (auto kv = marked_output.Begin(); kv != marked_output.End();
                             kv = kv.Next()) {
                                if (kv.StringValue().empty()) {
                                        kestrel_log(KESTREL_WARNING,
                                                    "Empty tensor name key: %s !\n", kv.c_key());
                                        continue;
                                }
                                m_netcfg.marked_output[kv.Key()] = kv.StringValue();
                                m_netcfg.tensor_names[kv.Key()] = kv.StringValue();
                        }
                }
                return KESTREL_OK;
        }
        void nn_load(const Model &model, const std::string &extra_cfg, const std::string &appoint)
        {
                if (m_netcfg.backend.empty() || m_netcfg.net.empty()) {
                        kestrel_log(KESTREL_ERROR,
                                    "Malfromed model file, net and backend not set!\n");
                        return;
                }
                std::string real_backend = m_netcfg.backend;
                if (!appoint.empty()) {
                        real_backend = appoint;
                }

                m_net.Create(real_backend, model, m_netcfg.net, extra_cfg);
                if (!m_net.IsValid()) {
                        kestrel_log(KESTREL_ERROR, "Create model failed!\n");
                        return;
                }

                k_err r = KESTREL_OK;
                for (auto it = m_netcfg.marked_output.begin(); it != m_netcfg.marked_output.end();
                     ++it) {
                        r |= m_net.ExtendOutput(it->second);
                }
        }

        kestrel_nn_cfg m_netcfg;
        Kestrel::NeuralNetwork m_net;
};

} // namespace Aux
} // namespace Kestrel

#endif // KESTREL_AUX_KESTREL_NN_UTILS_H
