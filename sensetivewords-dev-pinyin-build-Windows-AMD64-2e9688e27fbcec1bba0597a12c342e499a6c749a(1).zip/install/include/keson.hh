#ifndef KESON_KESONPP_HH
#define KESON_KESONPP_HH

#include <map>
#include <vector>
#include <kestrel_struct.hh>
#include <kestrel/kestrel_keson.h>

namespace Kestrel
{

template <typename T> struct extType {
};

template <> struct extType<Feature> {
        enum { value = KESON_FEATURE };
};

template <> struct extType<Buffer> {
        enum { value = KESON_BUFFER };
};

template <> struct extType<Packet> {
        enum { value = KESON_PACKET };
};

template <> struct extType<Frame> {
        enum { value = KESON_FRAME };
};

template <> struct extType<Tensor> {
        enum { value = KESON_TENSOR };
};

template <> struct extType<Model> {
        enum { value = KESON_MODEL };
};

template <> struct extType<Point2Di> {
        enum { value = KESON_POINT2I };
};

template <> struct extType<Point2Df> {
        enum { value = KESON_POINT2F };
};

template <> struct extType<Size2D> {
        enum { value = KESON_SIZE2D };
};

template <> struct extType<Area2D> {
        enum { value = KESON_AREA2D };
};

template <> struct extType<Array> {
        enum { value = KESON_ARRAY };
};

template <> struct extType<std::wstring> {
        enum { value = KESON_WSTRING };
};

template <typename T> T ExtValueProxy(keson root)
{
        KESTREL_UNUSED(root);
        kestrel_log(KESTREL_ERROR, "Keson Ext Not support type %s!\n", typeid(T).name());
        return T();
}

template <> inline Feature ExtValueProxy<Feature>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_FEATURE) {
                return Feature();
        }

        kestrel_feature_t *data = nullptr;
        keson_get_ext_data(root, (void **)&data);

        return Feature(kestrel_feature_ref(data));
}

template <> inline Buffer ExtValueProxy<Buffer>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_BUFFER) {
                return Buffer();
        }

        kestrel_buffer data = nullptr;
        keson_get_ext_data(root, (void **)&data);

        return Buffer(kestrel_buffer_ref(data));
}

template <> inline Packet ExtValueProxy<Packet>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_PACKET) {
                return Packet();
        }

        kestrel_packet_t *data = nullptr;
        keson_get_ext_data(root, (void **)&data);

        return Packet(kestrel_packet_ref(data));
}

template <> inline Frame ExtValueProxy<Frame>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_FRAME) {
                return Frame();
        }
        kestrel_frame_t *frame = nullptr;
        keson_get_ext_data(root, (void **)&frame);

        return Frame(kestrel_frame_ref(frame));
}

template <> inline Tensor ExtValueProxy<Tensor>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_TENSOR) {
                return Tensor();
        }
        kestrel_tensor_t *data = nullptr;
        keson_get_ext_data(root, (void **)&data);

        return Tensor(kestrel_tensor_ref(data));
}

template <> inline Model ExtValueProxy<Model>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_MODEL) {
                return Model();
        }
        kestrel_model_t *data = nullptr;
        keson_get_ext_data(root, (void **)&data);

        return Model(kestrel_model_ref(data));
}

template <> inline Array ExtValueProxy<Array>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_ARRAY) {
                return Array();
        }
        kestrel_array_t *data = nullptr;
        keson_get_ext_data(root, (void **)&data);
        return Array(kestrel_array_ref(data));
}

template <> inline Point2Di ExtValueProxy<Point2Di>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_POINT2I) {
                return Point2Di{ 0, 0 };
        }
        kestrel_point2d_t p;
        kestrel_point2d_t *ptr = &p;
        keson_get_ext_data(root, (void **)&ptr);
        return p;
}

template <> inline Point2Df ExtValueProxy<Point2Df>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_POINT2F) {
                return Point2Df{ 0.0f, 0.0f };
        }
        kestrel_point2df_t p;
        kestrel_point2df_t *ptr = &p;
        keson_get_ext_data(root, (void **)&ptr);
        return p;
}

template <> inline Size2D ExtValueProxy<Size2D>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_SIZE2D) {
                return Size2D{ 0, 0 };
        }
        kestrel_size2d_t size;
        kestrel_size2d_t *ptr = &size;
        keson_get_ext_data(root, (void **)&ptr);
        return size;
}

template <> inline Area2D ExtValueProxy<Area2D>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_AREA2D) {
                return Area2D{ 0, 0, 0, 0 };
        }
        kestrel_area2d_t area;
        kestrel_area2d_t *ptr = &area;
        keson_get_ext_data(root, (void **)&ptr);
        return area;
}

template <> inline std::wstring ExtValueProxy<std::wstring>(keson root)
{
        if (!keson_is_ext_object(root) || keson_get_ext_type(root) != KESON_WSTRING) {
                return std::wstring();
        }
        // wstring_size include terminating zero
        auto wstring_size = keson_get_binary_length(root) / sizeof(kestrel_wchar_t);
        std::wstring w_string(wstring_size, 0);
        kestrel_wchar_t *ptr = reinterpret_cast<kestrel_wchar_t *>(&w_string[0]);
        keson_get_ext_data(root, (void **)&ptr);
        w_string.resize(wstring_size - 1);
        return w_string;
}

class Keson
{
public:
        typedef enum kValueType { OBJECT, ARRAY, NIL } kValueType;
        typedef enum kOpFlag { NORMAL, MOVE } kOpFlag;
        class ValueRef;
        class Value;

        typedef std::vector<Value> KArray;
        typedef std::map<std::string, Value> KObject;

        // Traversal
        class Iterator
        {
        public:
                Iterator(keson ptr, keson root) : ptr_(ptr), root_(root)
                {
                        KESTREL_UNUSED(ptr);
                        KESTREL_UNUSED(root);
                }

                Iterator &operator++()
                {
                        this->ptr_ = keson_next(this->ptr_);
                        return *this;
                }

                Iterator operator++(int)
                {
                        Iterator ret(this->ptr_, this->root_);
                        this->operator++();
                        return ret;
                }

                bool operator==(const Iterator &other) const
                {
                        return this->ptr_ == other.ptr_;
                }

                bool operator!=(const Iterator &other) const
                {
                        return !(this->ptr_ == other.ptr_);
                }

                ValueRef operator*() const
                {
                        return ValueRef(this->ptr_, this->root_);
                }

        private:
                keson ptr_;
                keson root_;
        };

        class BaseType
        {
        public:
                BaseType(keson root = nullptr) : root_(root)
                {
                }

                BaseType(const BaseType &) = delete;
                BaseType &operator=(BaseType const &) = delete;
                BaseType(BaseType &&) = delete;
                BaseType &operator=(BaseType &&) = delete;

                ~BaseType()
                {
                }

                Value Duplicate(bool recurse = true) const
                {
                        return Value(keson_duplicate(this->root_, (recurse ? 1 : 0)));
                }

                bool IsDouble() const
                {
                        return keson_is_number(this->root_) == 1;
                }

                bool IsInt() const
                {
                        return keson_is_number(this->root_) == 1;
                }

                bool IsNull() const
                {
                        return keson_is_null(this->root_) == 1;
                }

                bool IsString() const
                {
                        return keson_is_string(this->root_) == 1;
                }

                bool IsArray() const
                {
                        return keson_is_array(this->root_) == 1;
                }

                bool IsObject() const
                {
                        return keson_is_object(this->root_) == 1;
                }

                bool IsValid() const
                {
                        return this->root_ != nullptr;
                }

                bool IsBool() const
                {
                        return keson_is_bool(this->root_) == 1;
                }

                template <typename T, uint8_t ext_type = extType<T>::value> bool IsExt() const
                {
                        return (keson_is_ext_object(this->root_) &&
                                keson_get_ext_type(this->root_) == ext_type);
                }

                const char *c_key() const
                {
                        return keson_key(this->root_);
                }

                std::string Key() const
                {
                        const char *ckey = this->c_key();
                        return (ckey != nullptr) ? std::string(ckey) : "";
                }

                // Value
                double DoubleValue() const
                {
                        return keson_get_double(this->root_);
                }

                int64_t IntValue() const
                {
                        return keson_get_int(this->root_);
                }

                bool BoolValue() const
                {
                        return keson_is_true(this->root_) == 1;
                }

                const char *CStringValue() const
                {
                        return keson_get_string(this->root_);
                }

                std::string StringValue() const
                {
                        const char *cstr = this->CStringValue();
                        return std::string(cstr != nullptr ? cstr : "");
                }

                template <typename T> T ExtValue() const
                {
                        return ExtValueProxy<T>(this->root_);
                }

                Iterator begin() const
                {
                        return Iterator(keson_child(this->root_), this->root_);
                }

                Iterator end() const
                {
                        return Iterator(nullptr, this->root_);
                }

                ValueRef Begin() const
                {
                        return ValueRef(keson_child(this->root_), this->root_);
                }

                ValueRef Next() const
                {
                        return ValueRef(keson_next(this->root_), this->root_);
                }

                ValueRef End() const
                {
                        return ValueRef(nullptr, this->root_);
                }

                bool operator==(const Value &rhs) const
                {
                        return this->root_ == rhs.root_;
                }

                bool operator!=(const Value &rhs) const
                {
                        return this->root_ != rhs.root_;
                }

                // modify object
                ValueRef operator[](const char *name) const
                {
                        if (!IsObject()) {
                                return ValueRef();
                        }
                        return ValueRef(keson_get_object_item(this->root_, name), this->root_);
                }

                ValueRef operator[](const std::string &name) const
                {
                        return (*this)[name.c_str()];
                }

                // no check key exist. The user can use `HasMember` ensures that the key does not
                // duplicate.
                bool AddMember(const char *key, const Value &node, kOpFlag move = kOpFlag::MOVE)
                {
                        if (!this->IsObject() || !node.IsValid()) {
                                return false;
                        }

                        if (move == kOpFlag::MOVE) {
                                keson_add_item_to_object(this->root_, key, node.root_);
                                const_cast<Value &>(node).root_ = nullptr;
                        } else {
                                keson_add_item_to_object(this->root_, key,
                                                         keson_duplicate(node.root_, 1));
                        }
                        return true;
                }

                // no check key exist. The user can use `HasMember` ensures that the key does not
                // duplicate.
                bool AddMemberCS(const char *key, const Value &node, kOpFlag move = kOpFlag::MOVE)
                {
                        if (!this->IsObject() || !node.IsValid()) {
                                return false;
                        }

                        if (move == kOpFlag::MOVE) {
                                keson_add_item_to_object_with_const_name(this->root_, key,
                                                                         node.root_);
                                const_cast<Value &>(node).root_ = nullptr;
                        } else {
                                keson_add_item_to_object_with_const_name(
                                    this->root_, key, keson_duplicate(node.root_, 1));
                        }
                        return true;
                }

                bool AddMember(const std::string &key, const Value &node,
                               kOpFlag move = kOpFlag::MOVE)
                {
                        return this->AddMember(key.c_str(), node, move);
                }

                bool HasMember(const char *key) const
                {
                        if (!this->IsObject()) {
                                return false;
                        }

                        return keson_has_child(this->root_, key) == 1;
                }

                bool HasMember(const std::string &key) const
                {
                        return this->HasMember(key.c_str());
                }

                void RemoveMember(const char *key)
                {
                        keson_delete_item_from_object(this->root_, key);
                }

                void RemoveMember(const std::string &key)
                {
                        this->RemoveMember(key.c_str());
                }

                bool Replace(const char *key, const Value &v, kOpFlag move = kOpFlag::MOVE)
                {
                        keson found = keson_get_object_item(this->root_, key);
                        if (!found) {
                                kestrel_log(KESTREL_ERROR, "Key not exists: %s!\n", key);
                                return false;
                        }

                        keson v_dup = (move == kOpFlag::MOVE) ? const_cast<Value &>(v).Detach()
                                                              : v.Duplicate().Detach();

                        return keson_replace_item_via_ptr(this->root_, found, v_dup) != 0;
                }

                bool Replace(const std::string &key, const Value &v, kOpFlag move = kOpFlag::MOVE)
                {
                        return Replace(key.c_str(), v, move);
                }

                bool Replace(int32_t index, const Value &v, kOpFlag move = kOpFlag::MOVE)
                {
                        keson found = keson_get_array_item(this->root_, index);
                        if (found == NULL) {
                                kestrel_log(KESTREL_ERROR, "Index out of range!\n");
                                return false;
                        }
                        keson v_dup = (move == kOpFlag::MOVE) ? const_cast<Value &>(v).Detach()
                                                              : v.Duplicate().Detach();
                        return keson_replace_item_via_ptr(this->root_, found, v_dup) != 0;
                }

                // modify array
                const ValueRef operator[](int32_t index) const
                {
                        if (!IsArray()) {
                                return ValueRef();
                        }
                        return ValueRef(keson_get_array_item(this->root_, index), this->root_);
                }

                ValueRef operator[](int32_t index)
                {
                        if (!IsArray()) {
                                return ValueRef();
                        }
                        return ValueRef(keson_get_array_item(this->root_, index), this->root_);
                }

                bool AppendItem(const Value &node, kOpFlag move = kOpFlag::MOVE)
                {
                        if (!this->IsArray() || !node.IsValid()) {
                                return false;
                        }
                        if (move == kOpFlag::MOVE) {
                                keson_add_item_to_array(this->root_, node.root_);
                                const_cast<Value &>(node).root_ = nullptr;
                        } else {
                                keson_add_item_to_array(this->root_,
                                                        keson_duplicate(node.root_, 1));
                        }
                        return true;
                }

                bool InsertItem(int32_t index, const Value &node, kOpFlag move = kOpFlag::MOVE)
                {
                        if (!this->IsArray()) {
                                return false;
                        }
                        // if index > array.size , it insert last
                        if (move == kOpFlag::MOVE) {
                                keson_insert_item_in_array(this->root_, index, node.root_);
                                const_cast<Value &>(node).root_ = nullptr;
                        } else {
                                keson_insert_item_in_array(this->root_, index,
                                                           keson_duplicate(node.root_, 1));
                        }
                        return true;
                }

                void RemoveItem(int32_t index)
                {
                        if (this->IsArray()) {
                                keson_delete_item_from_array(this->root_, index);
                        }
                }

                size_t Size() const
                {
                        return keson_array_size(this->root_);
                }

                bool Empty() const
                {
                        return keson_empty(this->root_) == 1;
                }

                std::string ToString(bool pretty_format = false) const
                {
                        keson_string c_str = keson_print(this->root_, (pretty_format ? 1 : 0));
                        if (c_str == nullptr) {
                                return "";
                        }
                        std::string cxx_str(c_str);
                        keson_free_string(&c_str);
                        return cxx_str;
                }

                keson c_keson() const
                {
                        return this->root_;
                }

                ValueRef Ref() const
                {
                        return ValueRef(this->root_);
                }

                std::vector<ValueRef> ToVector() const
                {
                        std::vector<ValueRef> arr;
                        arr.reserve(this->Size());
                        for (auto &&item : *this) {
                                arr.emplace_back(item);
                        }
                        return arr;
                }

                std::map<std::string, ValueRef> ToMap() const
                {
                        std::map<std::string, ValueRef> m;
                        for (auto &&item : *this) {
                                m.emplace(item.c_key(), item);
                        }
                        return m;
                }

                std::map<const char *, ValueRef> ToMapCS() const
                {
                        std::map<const char *, ValueRef> m;
                        for (auto &&item : *this) {
                                m.emplace(item.c_key(), item);
                        }
                        return m;
                }

                friend class ValueRef;
                friend class Value;

        private:
                keson root_ = nullptr;
        };

        class Value : public BaseType
        {
        public:
                Value(keson root = nullptr) : BaseType(root)
                {
                }

                Value(kValueType t) : BaseType(nullptr)
                {
                        switch (t) {
                        case OBJECT:
                                this->root_ = keson_create_object();
                                break;
                        case ARRAY:
                                this->root_ = keson_create_array();
                                break;
                        case NIL:
                                this->root_ = keson_create_null();
                                break;
                        default:
                                kestrel_log(KESTREL_ERROR, "Unsupported kValueType Type!\n");
                        }
                }

                Value(std::initializer_list<std::pair<std::string, Value>> init_list)
                        : BaseType(nullptr)
                {
                        new (this) Value(OBJECT);
                        for (const std::pair<std::string, Value> &it : init_list) {
                                this->AddMember(it.first, it.second, kOpFlag::MOVE);
                        }
                }

                // Implicit constructor: map-like objects (std::map, std::unordered_map, etc)
                template <class M,
                          typename std::enable_if<
                              std::is_constructible<std::string, typename M::key_type>::value &&
                                  std::is_constructible<Value, typename M::mapped_type>::value,
                              int>::type = 0>
                Value(const M &init_list) : BaseType(nullptr)
                {
                        new (this) Value(OBJECT);
                        for (const auto &it : init_list) {
                                this->AddMember(it.first, it.second, kOpFlag::NORMAL);
                        }
                }
                // Implicit constructor: vector-like objects (std::list, std::vector, std::set,
                // etc)
                template <class V,
                          typename std::enable_if<
                              std::is_constructible<Value, typename V::value_type>::value,
                              int>::type = 0>
                Value(const V &init_list) : BaseType(nullptr)
                {
                        new (this) Value(ARRAY);
                        for (const auto &it : init_list) {
                                this->AppendItem(it, kOpFlag::NORMAL);
                        }
                }

                Value(const ValueRef &that) : BaseType(nullptr)
                {
                        this->root_ = keson_duplicate(that.root_, 1);
                }

                Value(const Value &that) : BaseType(nullptr)
                {
                        this->root_ = keson_duplicate(that.root_, 1);
                }

                Value(Value &&that) NOEXCEPT : BaseType(nullptr)
                {
                        this->Swap(that);
                }

                Value &operator=(const Value &that)
                {
                        if (this == &that) {
                                return *this;
                        }
                        keson_deep_delete(&this->root_);
                        this->root_ = keson_duplicate(that.root_, 1);
                        return *this;
                }

                Value &operator=(Value &&that)
                {
                        if (this == &that) {
                                return *this;
                        }
                        keson_deep_delete(&this->root_);
                        this->Swap(that);
                        return *this;
                }

                Value(int32_t v) : BaseType(nullptr)
                {
                        this->root_ = keson_create_int(v);
                }

                Value(int64_t v) : BaseType(nullptr)
                {
                        this->root_ = keson_create_int(v);
                }

                Value(double v) : BaseType(nullptr)
                {
                        this->root_ = keson_create_double(v);
                }

                Value(bool v) : BaseType(nullptr)
                {
                        this->root_ = keson_create_bool((int32_t)v);
                }

                Value(const char *v) : BaseType(nullptr)
                {
                        this->root_ = keson_create_string(v);
                }

                Value(const std::string &v) : BaseType(nullptr)
                {
                        this->root_ = keson_create_string(v.c_str());
                }

                Value(const wchar_t *v) : BaseType(nullptr)
                {
                        this->root_ =
                            keson_create_ext_object(KESON_WSTRING, (kestrel_wchar_t *)(v));
                }

                Value(const std::wstring &v) : BaseType(nullptr)
                {
                        this->root_ = keson_create_ext_object(KESON_WSTRING,
                                                              (kestrel_wchar_t *)(v.c_str()));
                }

                // Packet/Frame/Model/Array/Buffer/Tensor
                template <typename T, uint8_t ext_type = extType<T>::value>
                Value(const T &v) : BaseType(nullptr)
                {
                        this->root_ = keson_create_ext_object(ext_type, v.Raw());
                }

                Value(const Point2Df &v) : BaseType(nullptr)
                {
                        this->root_ =
                            keson_create_ext_object(KESON_POINT2F, &const_cast<Point2Df &>(v));
                }

                Value(const Point2Di &v) : BaseType(nullptr)
                {
                        this->root_ =
                            keson_create_ext_object(KESON_POINT2I, &const_cast<Point2Di &>(v));
                }

                Value(const Size2D &v) : BaseType(nullptr)
                {
                        this->root_ =
                            keson_create_ext_object(KESON_SIZE2D, &const_cast<Size2D &>(v));
                }

                Value(const Area2D &v) : BaseType(nullptr)
                {
                        this->root_ =
                            keson_create_ext_object(KESON_AREA2D, &const_cast<Area2D &>(v));
                }

                void Attach(keson in)
                {
                        keson_deep_delete(&this->root_);
                        this->root_ = in;
                }

                keson Detach()
                {
                        keson out = this->root_;
                        this->root_ = nullptr;
                        return out;
                }

                void Swap(const Value &that)
                {
                        std::swap(this->root_, const_cast<Value &>(that).root_);
                }

                ~Value() NOEXCEPT
                {
                        keson_deep_delete(&this->root_);
                }
        };

        class ValueRef : public BaseType
        {
        public:
                // for STL
                ValueRef(keson root = nullptr, keson parent = nullptr)
                        : BaseType(root), parent_(parent)
                {
                }

                ValueRef(const ValueRef &that) : BaseType(that.root_), parent_(that.parent_)
                {
                }

                ValueRef(ValueRef &&that) NOEXCEPT : BaseType(nullptr), parent_(nullptr)
                {
                        this->Swap(that);
                }

                void Swap(const ValueRef &that)
                {
                        std::swap(this->root_, const_cast<ValueRef &>(that).root_);
                        std::swap(this->parent_, const_cast<ValueRef &>(that).parent_);
                }

                ValueRef &operator=(const ValueRef &that)
                {
                        this->root_ = that.root_;
                        this->parent_ = that.parent_;
                        return *this;
                }

                ValueRef &operator=(ValueRef &&that)
                {
                        this->Swap(that);
                        return *this;
                }

                ~ValueRef() NOEXCEPT = default;

                bool operator==(const ValueRef &rhs) const
                {
                        return this->root_ == rhs.root_;
                }

                bool operator!=(const ValueRef &rhs) const
                {
                        return this->root_ != rhs.root_;
                }

                bool ReplaceSelf(const Value &v, kOpFlag move = kOpFlag::MOVE)
                {
                        keson v_dup = (move == kOpFlag::MOVE) ? const_cast<Value &>(v).Detach()
                                                              : v.Duplicate().Detach();
                        bool ret =
                            keson_replace_item_via_ptr(this->parent_, this->root_, v_dup) != 0;

                        if (ret) {
                                this->root_ = v_dup;
                        }
                        return ret;
                }

                Value DetachNode()
                {
                        if (this->parent_ == nullptr) {
                                kestrel_log(KESTREL_WARNING,
                                            "DetachNode() for root has no meaning, return "
                                            "a copy of refed node.\n");
                                return Value(keson_duplicate(this->root_, 1));
                        }
                        this->root_ = keson_detach_item_via_ptr(this->parent_, this->root_);
                        return Value(this->root_);
                }

        protected:
                keson parent_ = nullptr;
        };

        static Value Parse(const char *config)
        {
                return Value(keson_parse(config));
        }

        static Value Parse(const std::string &config)
        {
                return Parse(config.c_str());
        }
};

static Keson::Value FromCKeson(keson node)
{
        kestrel_log(KESTREL_WARNING,
                    "FromCKeson() is deprecated, please use Keson::Value(node).\n");
        return Keson::Value(keson_duplicate(node, 1));
}
static keson ToCKeson(const Keson::Value &k)
{
        kestrel_log(KESTREL_WARNING,
                    "ToCKeson is deprecated, please use k.c_keson or k.Detach().\n");
        return keson_duplicate(k.c_keson(), 1);
}

} // namespace Kestrel

#endif
