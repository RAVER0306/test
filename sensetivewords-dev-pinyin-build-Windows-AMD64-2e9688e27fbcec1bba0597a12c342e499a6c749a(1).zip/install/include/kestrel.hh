#ifndef KESTREL_HH
#define KESTREL_HH

#include <kestrel_struct.hh>
#include <keson.hh>

#ifndef KESTREL_FFI
#include <kestrel_cpp_specialized.hh>
#endif

#endif // Kestrel