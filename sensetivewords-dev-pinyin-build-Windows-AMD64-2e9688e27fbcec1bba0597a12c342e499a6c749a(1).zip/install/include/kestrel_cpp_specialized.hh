#ifndef KESTREL_CPP_SPECIALIZED_HH
#define KESTREL_CPP_SPECIALIZED_HH

#include <keson.hh>

namespace Kestrel
{

template <> class KesonBridge<void, std::string>
{
public:
        keson Encode(void *dummy, const std::string &k)
        {
                KESTREL_UNUSED(dummy);
                return keson_parse(k.c_str());
        }

        void ReleaseEncodedData(void *dummy, keson *encoded_data)
        {
                KESTREL_UNUSED(dummy);
                keson_deep_delete(encoded_data);
        }

        std::string Decode(void *dummy, keson node)
        {
                KESTREL_UNUSED(dummy);
                keson_string res = keson_print(node, false);
                std::string str = (res != nullptr ? res : "");
                keson_free_string(&res);
                keson_deep_delete(&node);
                return str;
        }
};
typedef AnnotatorTemp<void, std::string> AnnotatorWithStringifyKeson;

template <> class KesonBridge<void, Keson::Value>
{
public:
        keson Encode(void *dummy, const Keson::Value &k)
        {
                KESTREL_UNUSED(dummy);
                return k.c_keson();
        }

        void ReleaseEncodedData(void *dummy, keson *encoded_data)
        {
                KESTREL_UNUSED(dummy);
                KESTREL_UNUSED(encoded_data);
        }

        Keson::Value Decode(void *dummy, keson node)
        {
                KESTREL_UNUSED(dummy);
                return Keson::Value(node);
        }
};

typedef AnnotatorTemp<void, Keson::Value> Annotator;

} // namespace Kestrel

#endif