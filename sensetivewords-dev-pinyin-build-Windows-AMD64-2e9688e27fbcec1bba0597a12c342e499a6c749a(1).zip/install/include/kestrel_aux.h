#ifndef KESTREL_CORE_KESTREL_AUX_H
#define KESTREL_CORE_KESTREL_AUX_H

#ifdef __cplusplus
extern "C" {
#endif

/// @defgroup kestrel_aux Auxiliaries
///
/// Kestrel Auxiliaries provide some extension functions that semi-independent of Kestrel
/// backbone.
///
/// @{
/// @}

#ifdef __cplusplus
}
#endif

#endif