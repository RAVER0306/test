#ifndef KESTREL_CORE_KESTREL_CORE_H
#define KESTREL_CORE_KESTREL_CORE_H

#ifdef __cplusplus
extern "C" {
#endif

/// @defgroup kestrel_core Kestrel Core
///
/// Kestrel Core is core part of Kestrel that provides internal runtime environment management,
/// heterogeneous memory management, resource pool, log, etc.
///
/// Some security-sensitive function also included, like license authentication and encrypted
/// model load.
///
/// @{

#include "kestrel_core/kestrel_core_env.h"

/// @defgroup kestrel_log Log
/// Kestrel Log API
/// @{
#include "kestrel_core/kestrel_log.h"
/// @}

/// @defgroup kestrel_atomic Atomic
/// Kestrel Atomic API
/// @{
#include "kestrel_core/kestrel_atomic.h"
/// @}

/// @defgroup kestrel_license License
/// Kestrel License API
/// @{
#include "kestrel_core/kestrel_license.h"
/// @}

/// @defgroup kestrel_model Model
/// Kestrel Model API
/// @{
#include "kestrel_core/kestrel_model.h"
/// @}

/// @defgroup kestrel_plugin Plug-in
/// Kestrel Plug-in API
/// @{
#include "kestrel_core/kestrel_plugin.h"
/// @}

/// @defgroup kestrel_device Device
/// Kestrel Device API
/// @{
#include "kestrel_core/kestrel_device.h"
/// @}

/// @}

#ifdef __cplusplus
}
#endif

#endif
