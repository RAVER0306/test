#ifndef KESTREL_VIDEO_DECODER_HH
#define KESTREL_VIDEO_DECODER_HH
#include <atomic>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <kestrel.hh>

namespace Kestrel
{

template <class T> class BlockQueue
{
public:
        typedef std::unique_lock<std::mutex> TLock;

        explicit BlockQueue(const int maxCapacity = -1) : m_maxCapacity(maxCapacity)
        {
        }

        size_t size()
        {
                TLock lock(m_mutex);
                return m_list.size();
        }

        void push_back(const T &item)
        {
                TLock lock(m_mutex);
                if (true == hasCapacity()) {
                        while ((int32_t)m_list.size() >= m_maxCapacity) {
                                m_notFull.wait(lock);
                        }
                }

                m_list.push_back(item);
                m_notEmpty.notify_all();
        }

        T pop()
        {
                TLock lock(m_mutex);
                while (m_list.empty()) {
                        m_notEmpty.wait(lock);
                }

                T temp = *m_list.begin();
                m_list.pop_front();

                m_notFull.notify_all();

                lock.unlock();
                return temp;
        }

        bool empty()
        {
                TLock lock(m_mutex);
                return m_list.empty();
        }

        bool full()
        {
                if (false == hasCapacity()) {
                        return false;
                }

                TLock lock(m_mutex);
                return m_list.size() >= m_maxCapacity;
        }

private:
        bool hasCapacity() const
        {
                return m_maxCapacity > 0;
        }

        typedef std::deque<T> TList;
        TList m_list;

        const int m_maxCapacity;

        std::mutex m_mutex;
        std::condition_variable m_notEmpty;
        std::condition_variable m_notFull;
};

void MergeKeson(const Keson::ValueRef src, Keson::ValueRef dst)
{
        if (src.IsObject()) {
                for (auto m : src) {
                        if (dst.HasMember(m.c_key())) {
                                MergeKeson(m, dst[m.c_key()]);
                        } else {
                                dst.AddMember(m.c_key(), m);
                        }
                }
        } else {
                dst.ReplaceSelf(src);
        }
}

class VideoHandle
{
public:
        std::unordered_map<std::string, Annotator> modules_;
        std::thread demuxer_thread_;
        BlockQueue<Keson::Value> demuxer_queue_;
        std::atomic<bool> demuxer_continue_;
        int32_t choosed_stream_id_;
};

class VideoDecoder
{
public:
        VideoDecoder() = default;
        ~VideoDecoder()
        {
                Release();
        };
        k_err Init(const std::string &video_name, const std::string &lib_demuxer = "demuxer",
                   const std::string &lib_decoder = "decoder",
                   const std::string &demuxer_options = "",
                   const std::string &decoder_params = "")
        {
                if (handle) {
                        Log(KESTREL_WARNING, "double init!\n");
                        Release();
                }
                handle = new VideoHandle;
                auto &video_handle = *static_cast<VideoHandle *>(handle);
                auto &module_map = video_handle.modules_;
                Keson::Value demuxer_config{ Keson::OBJECT };
                demuxer_config.AddMemberCS("filename", video_name, Keson::MOVE);
                if (!demuxer_options.empty()) {
                        demuxer_config.AddMemberCS("options", Keson::Parse(demuxer_options),
                                                   Keson::MOVE);
                }
                module_map["demuxer"] = Annotator(lib_demuxer, demuxer_config.ToString());
                if (!module_map["demuxer"].IsValid()) {
                        err = CV_E_INVALIDARG;
                        Release();
                }
                if (err != KESTREL_OK) {
                        kestrel_log(KESTREL_ERROR, "failed to open %s", lib_demuxer.c_str());
                        return err;
                }
                auto stream_info = module_map["demuxer"].Startup(nullptr, Keson::Value());
                Keson::Value choosed_stream;
                for (int i = 0; i < (int)stream_info.Size(); i++) {
                        kestrel_frame_type_e stream_type =
                            (kestrel_frame_type_e)stream_info[i]["type"].IntValue();
                        if (stream_type == KESTREL_VIDEO_FRAME) {
                                video_handle.choosed_stream_id_ =
                                    (int32_t)stream_info[i]["stream_id"].IntValue();
                                choosed_stream = stream_info[i];
                        }
                }
                if (!decoder_params.empty()) {
                        auto param_keson = Keson::Parse(decoder_params);
                        if (!param_keson.IsValid()) {
                                kestrel_log(KESTREL_ERROR, "decoder parameter is invalid %s",
                                            decoder_params.c_str());
                                return CV_E_INVALIDARG;
                        }
                        MergeKeson(param_keson.Ref(), choosed_stream.Ref());
                }
                module_map["decoder"] = Annotator(lib_decoder, choosed_stream.ToString());
                if (!module_map["decoder"].IsValid()) {
                        err = CV_E_INVALIDARG;
                        Release();
                        return err;
                }
                video_handle.demuxer_continue_ = true;
                video_handle.demuxer_thread_ = std::thread(
                    [this](Annotator demuxer_plugin) {
                            Keson::Value demuxer_in{ { "id", 0 }, { "command", "packet" } };
                            auto &video_handle = *static_cast<VideoHandle *>(this->handle);
                            while (video_handle.demuxer_continue_) {
                                    auto packet_out = demuxer_plugin.Process(nullptr, demuxer_in);
                                    this->err = demuxer_plugin.GetLastError();
                                    if (this->err != KESTREL_OK) {
                                            if (this->err == KPLUGIN_E_EOF) {
                                                    this->err = KESTREL_OK;
                                                    // null packet
                                                    if (video_handle.choosed_stream_id_ ==
                                                        packet_out["stream_id"].IntValue()) {
                                                            video_handle.demuxer_queue_.push_back(
                                                                packet_out);
                                                    }
                                            }
                                            break;
                                    }
                                    if (video_handle.choosed_stream_id_ !=
                                        packet_out["stream_id"].IntValue()) {
                                            continue;
                                    }
                                    video_handle.demuxer_queue_.push_back(packet_out);
                            }
                            while (!video_handle.demuxer_queue_.empty()) {
                            };
                            video_handle.demuxer_continue_ = false;
                    },
                    module_map.at("demuxer"));
                video_handle.demuxer_thread_.detach();
                return err;
        }

        Frame GetFrame(int32_t delay = 0)
        {
                if (!handle) {
                        err = KESTREL_ERR;
                        return Frame();
                }
                auto &video_handle = *static_cast<VideoHandle *>(handle);
                auto &module_map = video_handle.modules_;
                auto err_ = this->err;
                while (true) {
                        if (video_handle.demuxer_queue_.empty() &&
                            video_handle.demuxer_continue_) {
                                continue;
                        }
                        if (delay > 0) {
                                std::this_thread::sleep_for(std::chrono::milliseconds(delay));
                        }
                        Kestrel::Keson::Value packet{ { "id", 0 },
                                                      { "stream_id",
                                                        video_handle.choosed_stream_id_ },
                                                      { "packet", Kestrel::Packet() } };
                        if (!video_handle.demuxer_queue_.empty()) {
                                packet = video_handle.demuxer_queue_.pop();
                        }
                        auto out = module_map.at("decoder").Process(nullptr, packet);
                        err_ = module_map.at("decoder").GetLastError();
                        if (err_ == KESTREL_OK) {
                                return out["image"].ExtValue<Frame>();
                        }
                        if (err_ != KPLUGIN_E_AGAIN) {
                                break;
                        }
                }
                this->err = video_handle.demuxer_continue_ ? err_ : KPLUGIN_E_EOF;
                return Frame();
        }

        void Release()
        {
                auto video_handle = static_cast<VideoHandle *>(handle);
                if (video_handle) {
                        video_handle->demuxer_continue_ = false;
                        delete video_handle;
                        handle = nullptr;
                }
        }

        k_err GetLastError()
        {
                return err;
        }

private:
        k_err err = KESTREL_OK;
        void *handle = nullptr;
};

} // namespace Kestrel

#endif