#ifndef KESTREL_CORE_HH
#define KESTREL_CORE_HH

#include <kestrel_core.h>
#include <memory>
#include <fstream>
#include <string>

namespace Kestrel
{

class Device
{
public:
        static k_err Bind(const std::string &device, const std::string &config)
        {
                return kestrel_device_bind(device.c_str(), config.c_str());
        }

        static k_err Attach(kestrel_dev_hdl hdl)
        {
                return kestrel_device_attach(hdl);
        }

        static void Detach()
        {
                kestrel_device_detach();
        }

        static void Unbind()
        {
                kestrel_device_unbind();
        }

        static kestrel_mem_type_e Type()
        {
                return kestrel_device_get_type();
        }

        static std::string Name()
        {
                const char *name = kestrel_device_get_name();
                return name == NULL ? std::string() : std::string(name);
        }

        static int32_t ID()
        {
                return kestrel_device_get_id();
        }

        static kestrel_dev_hdl Handle()
        {
                return kestrel_device_get_handle();
        }
};

class License
{
public:
        static void SetUdidGetter(kestrel_udid_getter getter)
        {
                kestrel_license_set_udid_getter(getter);
        }

        static void ResetUdidGetter()
        {
                kestrel_license_reset_udid_getter();
        }

        static k_err Add(const std::string &license,
                         const std::string &signed_code = std::string(""))
        {
                return kestrel_license_add(license.c_str(), signed_code.c_str());
        }

        static k_err AddFromFile(const std::string &license_file, const std::string &signed_code)
        {
                // const char *sc = signed_code.empty() ? NULL : signed_code.c_str();
                return kestrel_license_add_from_file(license_file.c_str(), signed_code.c_str());
        }

        static int32_t GetLimit(const std::string &item)
        {
                return kestrel_license_get_limit(item.c_str());
        }

        static std::string GetLimitStr(const std::string &item)
        {
                char *c_str = kestrel_license_get_limit_str(item.c_str());
                if (c_str != NULL) {
                        std::string str(c_str);
                        free(c_str);
                        return str;
                }
                return std::string();
        }

        static k_err Checkin(const std::string &item)
        {
                return kestrel_license_checkin(item.c_str());
        }

        static void Checkout(const std::string &item)
        {
                kestrel_license_checkout(item.c_str());
        }
};

class PluginInfo // NOLINT
{
public:
        bool IsValid() const
        {
                return m_plugin != nullptr;
        }

        const kestrel_plugin_t *Raw() const
        {
                return m_plugin;
        }

        std::string Name() const
        {
                if (m_plugin != nullptr) {
                        return std::string(m_plugin->plugin_name);
                }
                return std::string();
        }

        const char *CName() const
        {
                if (m_plugin != nullptr) {
                        return m_plugin->plugin_name;
                }
                return nullptr;
        }

        int32_t Type() const
        {
                if (m_plugin != nullptr) {
                        return m_plugin->type;
                }
                return KESTREL_UNKNOWN_PLUGIN_TYPE;
        }

        std::string Version() const
        {
                if (m_plugin != nullptr) {
                        return std::string(m_plugin->version());
                }
                return std::string();
        }

        std::string Revision() const
        {
                if (m_plugin != nullptr) {
                        return std::string(m_plugin->revision());
                }
                return std::string();
        }

private:
        PluginInfo(const kestrel_plugin_t *p)
        {
                m_plugin = p;
        }
        PluginInfo() = default;

        const kestrel_plugin_t *m_plugin = nullptr;

        friend class Plugin;
};

class Plugin
{
public:
        static PluginInfo SetupBuiltin(const kestrel_plugin_t *p, const std::string &signature)
        {
                kestrel_plugin_setup_builtin(p, signature.c_str());
                return Find(p->plugin_name);
        }

        static PluginInfo Load(const std::string &file, const std::string &signature)
        {
                const char *s = kestrel_plugin_load(file.c_str(), signature.c_str());
                return Find(s == nullptr ? "" : s);
        }

        static bool Exist(const std::string &name)
        {
                return kestrel_plugin_exist(name.c_str()) == 1;
        }

        static PluginInfo Find(const std::string &name)
        {
                return PluginInfo(kestrel_plugin_find(name.c_str(), NULL));
        }

        static PluginInfo FindIfNotExistTryLoad(const std::string &name)
        {
                return PluginInfo(kestrel_plugin_find_if_not_exist_try_load(name.c_str(), NULL));
        }

        static PluginInfo Begin()
        {
                return PluginInfo(kestrel_plugin_get_next(NULL, NULL));
        }

        static PluginInfo Next(const PluginInfo &plg)
        {
                if (plg.IsValid()) {
                        return PluginInfo(kestrel_plugin_get_next(plg.CName(), NULL));
                }
                return PluginInfo(nullptr);
        }

        static void Unload(const std::string &name)
        {
                kestrel_plugin_unload(name.c_str());
        }
};

class Log
{
public:
        static void SetCallback(kestrel_log_callback cb, kestrel_log_callback *old)
        {
                kestrel_log_set_callback(cb, old);
        }

        static void ResetCallback()
        {
                kestrel_log_reset_callback();
        }

        static void SetLevel(kestrel_log_level_e level)
        {
                kestrel_log_set_level(level);
        }

        static kestrel_log_level_e GetLevel()
        {
                return kestrel_log_get_level();
        }

        static int32_t GetConfig()
        {
                return kestrel_log_get_config();
        }

        static void SetConfig(int32_t config)
        {
                return kestrel_log_set_config(config);
        }

        static void ResetConfig()
        {
                return kestrel_log_reset_config();
        }

        Log(kestrel_log_meta_t meta, const char *fmt, ...)
        {
                va_list vl;
                va_start(vl, fmt);
                kestrel_log_va(meta, fmt, vl);
                va_end(vl);
        }
};

class Model
{
public:
        Model()
        {
                m_model = nullptr;
        }

        Model(const std::string &file)
        {
                kestrel_model m = NULL;
                k_err r = kestrel_model_load(file.c_str(), &m);
                if (r != KESTREL_OK) {
                        m_model = nullptr;
                }
                m_model = std::shared_ptr<kestrel_model_t>(
                    m, [](kestrel_model p) { kestrel_model_unload(&p); });
        }

        Model(kestrel_model model)
        {
                m_model = std::shared_ptr<kestrel_model_t>(
                    model, [](kestrel_model p) { kestrel_model_unload(&p); });
        }

        Model(uint8_t *data, void (*finalizer)(void *ud, void *data), void *finalizer_ud,
              size_t data_size)
        {
                kestrel_model m = NULL;
                k_err r =
                    kestrel_model_map_from_memory(data, data_size, finalizer, finalizer_ud, &m);
                if (r != KESTREL_OK) {
                        m_model = nullptr;
                }
                m_model = std::shared_ptr<kestrel_model_t>(
                    m, [](kestrel_model p) { kestrel_model_unload(&p); });
        }

        bool IsValid() const
        {
                return m_model != nullptr;
        }

        bool Create(const std::string &file)
        {
                if (IsValid()) {
                        return false;
                }
                new (this) Model(file);
                return IsValid();
        }

        bool Create(uint8_t *data, void (*finalizer)(void *ud, void *data), void *finalizer_ud,
                    size_t data_size)
        {
                if (IsValid()) {
                        return false;
                }
                new (this) Model(data, finalizer, finalizer_ud, data_size);
                return IsValid();
        }

        void Free()
        {
                m_model.reset();
        }

        std::string Register() const
        {
                kestrel_model_register(m_model.get());
                return Oid();
        }

        k_err Unregister() const
        {
                return kestrel_model_unregister(Oid().c_str());
        }

        k_err ForceUnregister() const
        {
                return kestrel_model_force_unregister(Oid().c_str());
        }

        kestrel_model Raw() const
        {
                return m_model.get();
        }

        int32_t Version() const
        {
                return kestrel_model_version(m_model.get());
        }

        std::string Type() const
        {
                const char *s = kestrel_model_type(m_model.get());
                return s == NULL ? std::string() : std::string(s);
        }

        std::string Oid() const
        {
                const char *s = kestrel_model_oid(m_model.get());
                return s == NULL ? std::string() : std::string(s);
        }

        std::string GetFile(const std::string &file) const
        {
                std::string buf;
                size_t file_size = kestrel_model_file_size(m_model.get(), file.c_str());
                if (file_size > 0) {
                        buf.resize(file_size, 0);
                        kestrel_model_get_file(m_model.get(), file.c_str(), (uint8_t *)&buf[0],
                                               &file_size);
                }
                return buf;
        }

        k_err RunCallbackWithFile(const std::string &file, kestrel_shibboleth_fx shibboleth,
                                  kestrel_model_file_cb cb, void *ud) const
        {
                return kestrel_model_run_cb_with_file(m_model.get(), file.c_str(), shibboleth, cb,
                                                      ud);
        }

private:
        std::shared_ptr<kestrel_model_t> m_model;
};

} // namespace Kestrel

#endif
