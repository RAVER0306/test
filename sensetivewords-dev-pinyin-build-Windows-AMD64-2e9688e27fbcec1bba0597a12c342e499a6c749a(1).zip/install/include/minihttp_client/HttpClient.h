#pragma once

#include <string>
#include <unordered_map>
#include <minihttp_client/Connection.h>
#include <minihttp_client/http_parser.h>

struct http_parser;

namespace minihttp_client {

using HeaderFields = std::unordered_map<std::string, std::string>;
class HttpRequest {
public:

private:
    std::string path_;
    HeaderFields headers_;
};


class HttpRequestWriter {
public:
    HttpRequestWriter(std::shared_ptr<Connection> conn)
        : conn_(conn) {}

    bool WriteRequest(const char *method, const std::string &path);
    bool WriteHeader(const std::string &key, const std::string &value);
    int GetErrMode() {return conn_->ErrMode();}

    virtual bool FinishHeader();
    virtual bool WriteBodyChunk(const unsigned char *data, int size);

    virtual bool Finish();
    virtual ~HttpRequestWriter() {}

protected:
    std::shared_ptr<Connection> conn_;
    std::string buf_;
};

class GZIPHttpRequestWriter : public HttpRequestWriter {
public:
    GZIPHttpRequestWriter(std::shared_ptr<Connection> conn)
        : HttpRequestWriter(conn) {}

    virtual bool WriteBodyChunk(const unsigned char *data, int size);
    virtual bool Finish();
private:
    // XXX buffer all compressed chunk, avoid using HTTP Chunk mode
    std::string buf_;
};

class HttpResponseReader {
public:
    HttpResponseReader(std::shared_ptr<Connection> conn);
    ~HttpResponseReader();

    const HeaderFields &GetHeaders() const { return headers_; }
    int GetContentLenght() const { return content_length_; }
    int GetHttpErrorCode() const { return status_code_; }
    int GetParserError() const { return parser_.http_errno; }

    bool ReadHeaders();
    bool ReadAllBody(std::string *out);
    int GetErrMode() {return conn_->ErrMode();}

    bool IsEOF() const { return eof_; }

    std::ostream &Dump(std::ostream &os);
private:
    enum State {
        INIT,
        HEADER,
        VALUE,
    };


    std::shared_ptr<Connection> conn_;
    HeaderFields headers_;

    http_parser_settings settings_;
    http_parser parser_;

    HttpResponseReader(const HttpResponseReader&) = delete;
    HttpResponseReader& operator=(const HttpResponseReader&) = delete;

    std::string path_;
    int content_length_ = 0;
    unsigned int status_code_ = 200;
    bool header_completed_ = false;
    bool eof_ = false;

    static int url_cb(http_parser* parser, const char *at, size_t length);
    static int header_field_cb(http_parser* parser, const char *at, size_t length);

    static int header_value_cb(http_parser* parser, const char *at, size_t length);

    static int body_cb(http_parser* parser, const char *at, size_t length);

    static int header_complete_cb(http_parser *parser);
    static int message_begin_cb(http_parser* parser);

    static int message_complete_cb(http_parser* parser);

    std::string field_;
    std::string value_;
    State s_ = INIT;

    std::string body_;
};

class HttpClient {
public:
    HttpClient(std::shared_ptr<Connection> conn);

    void NewRequest(const char *method, const std::string &host,
            const std::string &path);

    void Request();

private:
};

}
