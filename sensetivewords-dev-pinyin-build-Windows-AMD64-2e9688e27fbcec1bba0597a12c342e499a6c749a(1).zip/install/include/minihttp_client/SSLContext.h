#pragma once

#include <bearssl/bearssl.h>

#include <string>

namespace minihttp_client
{

class SSLContext
{
public:
        SSLContext()
        {
        }

        ~SSLContext()
        {
        }

        // bool SetCACert(const std::string &ca);

private:
        // bool use_default_ca_ = true;
};

} // namespace minihttp_client
