#pragma once

#include <string>

namespace minihttp_client {

class JWTHeader {
public:
    std::string alg;
    std::string typ;
    std::string jku;
    std::string kid;
    std::string x5u;
    std::string x5t;
};

class JWTEncoder {
public:
    enum Algorithm {
        HS256,
    };
    JWTEncoder(Algorithm alg)
        : alg_(alg) {}

    bool Sign(const JWTHeader& header, const std::string &customClaims, const std::string key, std::string *out);

private:
    Algorithm alg_;
};

};
