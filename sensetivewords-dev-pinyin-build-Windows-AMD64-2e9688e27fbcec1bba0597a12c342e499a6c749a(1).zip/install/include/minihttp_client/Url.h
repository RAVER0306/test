#pragma once

#include <string>

namespace minihttp_client {

struct Url {
    std::string schema;
    std::string host;
    unsigned short port;
    std::string path;

    static bool Parse(const std::string& url, Url *out);
};


}
