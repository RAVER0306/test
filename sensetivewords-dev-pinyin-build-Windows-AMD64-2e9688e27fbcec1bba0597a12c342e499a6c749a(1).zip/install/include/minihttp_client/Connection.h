#pragma once

#include <string>
#include <memory>
#include <minihttp_client/SSLContext.h>

namespace minihttp_client
{

#ifdef _WIN32
#if defined(_WIN64)
typedef unsigned __int64 socket_t;
#else
typedef _W64 unsigned int socket_t;
#endif
#ifndef INVALID_SOCKET
#define INVALID_SOCKET (socket_t)(~0)
#endif
#else
typedef int socket_t;
#ifndef INVALID_SOCKET
#define INVALID_SOCKET (-1)
#endif
#endif

class Connection
{
public:
        enum State {
                S_INITED,
                S_CONNECTED,
                S_CLOSED,
                S_ERROR,
        };

        virtual ~Connection();
        Connection()
        {
        }

        State GetState() const
        {
                return state_;
        }
        socket_t GetFd() const
        {
                return fd_;
        }

        virtual bool Connect(const char *hostname, int port);

        virtual void Close();
        virtual int Write(const unsigned char *buf, int len);
        virtual int Read(unsigned char *buf, int len);
        virtual int ErrMode()
        {
                return 0;
        }
        virtual bool Flush();
        virtual bool EncryptRequestBody(std::string &encrypt_request_body)
        {
                return false;
        }
        virtual bool DecryptResponse(std::string &decrypt_response)
        {
                return false;
        }

        virtual bool IsGood() const
        {
                return state_ == S_CONNECTED;
        }

        void SetWriteTimeout(int sec)
        {
                write_timeout_ = sec;
        }
        void SetReadTimeout(int sec)
        {
                read_timeout_ = sec;
        }
        void SetConnectTimeout(int sec)
        {
                connect_timeout_ = sec;
        }

protected:
        State state_ = S_INITED;
        socket_t fd_ = INVALID_SOCKET;

        int connect_timeout_ = 0;
        int write_timeout_ = 0;
        int read_timeout_ = 0;
};

class SSLConnection : public Connection
{
public:
        SSLConnection();
        ~SSLConnection();

        bool Connect(const char *hostname, int port);

        void Close();
        int Write(const unsigned char *buf, int len);
        int Read(unsigned char *buf, int len);
        int ErrMode()
        {
                return ioc_.engine ? ioc_.engine->err : 0;
        }
        bool Flush();
        void SetServerNameCheck(bool check)
        {
                server_name_check_ = check;
        }

private:
        SSLContext ctx_;
        // XXX windows use SOCKET and INVALID_SOCKET

        br_ssl_client_context sc_;
        br_x509_minimal_context xc_;
        unsigned char iobuf_[BR_SSL_BUFSIZE_BIDI];

        br_sslio_context ioc_;
        bool server_name_check_;

        void checkSSLError(int ret);
        void forceClose();
};

} // namespace minihttp_client
