﻿#include <kestrel.hh>
#include <kestrel_core.hh>
#include <iostream>
#include "timehelper.hpp"
using namespace Kestrel;

#define PLUGIN_NAME "sensetivewords"

int main(int argc, char **argv)
{
        std::string str_content;

        Env::Init("sensetivewords");
        k_err r = License::AddFromFile("KESTREL.lic", "");
        if (r != KESTREL_OK) {
                Log(KESTREL_ERROR, "add license failed, errcode: %d\n", r);
        }

        Kestrel::Log::SetLevel(KESTREL_LL_TRACE);
        Kestrel::Log(KESTREL_INFO, "正在加载...\n");

        Kestrel::Plugin::Load(PLUGIN_NAME ".kep", "");
        Kestrel::Annotator annotator(
            PLUGIN_NAME,
            R"({"model":"./model/sensetivewords/KM_sensetivewords_ppl_1.0.5.tar","max_batch_size":1})");
        Kestrel::Log(KESTREL_INFO, "revision : %s\n", annotator.Revision().c_str());
        Kestrel::Log(KESTREL_INFO, "version : %s\n", annotator.Version().c_str());

        Kestrel::Keson::Value input_data{ Kestrel::Keson::ARRAY };
        Kestrel::Log(KESTREL_INFO, "加载成功！\n");
        Kestrel::Log(KESTREL_INFO, "请输入待检测文本(可输入多行，连续两个回车结束输入)：\n");
        for (int i = 0; std::getline(std::cin, str_content) && !str_content.empty(); i++) {
                Kestrel::Keson::Value data = { { "content", str_content }, { "content_id", i } };
                input_data.AppendItem(data);
        }
        Kestrel::Keson::Value result;
        {
                Timehepler process("process");
                result = annotator.Process(NULL, { { "id", 0 }, { "targets", input_data } });
        }

        Kestrel::Log(KESTREL_TRACE, "outout : %s\n", result.ToString(true).c_str());
        return 1;
}
