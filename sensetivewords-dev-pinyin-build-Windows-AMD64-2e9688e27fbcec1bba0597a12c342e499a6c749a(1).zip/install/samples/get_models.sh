#!/bin/bash

# Usage: ./get_models.sh [user.yml] <models.yml>

devcenter_user="model_download_robot"
devcenter_secret="downloader"

adela_user="kestrel-robot"
adela_secret="602bcdab78074fe0bbffd33262b6d917"

config() {
    while read -r line
    do
        config=(${line//:/ })
        if [[ ${#config[@]} -lt 2 ]]; then
            continue
        fi
        if [[ ${config[0]} = "api_user" ]]; then
            user="${config[1]}"
        elif [[ ${config[0]} = "api_secret" ]]; then
            secret="${config[1]}"
        fi
    done < $1
}

if [[ $# -eq 1 ]]; then
    models_file=$1
elif [[ $# -eq 2 ]]; then
    config $1
    models_file=$2
else
    echo "Usage: $0 [user.yml] <models.yml|models.json>"
    exit
fi

subdir=""
if [[ "$models_file" =~ ".json" ]]; then
    python -c 'import sys, yaml, json; print(yaml.dump(json.loads(sys.stdin.read())))' < $models_file > '.model.tmp'
    models_file='.model.tmp'
fi

cat $models_file | while read line
do
    model=(${line//:/ })
    if [[ ${#model[@]} -lt 2 ]]; then
        subdir="model/${model[0]}"
        `mkdir -p ${subdir}`
        continue
    fi

    oid_md5_file_path="${subdir}/${model[0]}.oid_md5~"

    if test -e ${subdir}/${model[0]} && test -e ${oid_md5_file_path}
    then
        model_md5=`md5sum ${subdir}/${model[0]}`
        oid=`head ${oid_md5_file_path} -n 1`
        md5=`tail ${oid_md5_file_path} -n 1`
        if [[ "${oid}" == "${model[1]}" && "${md5}" == "${model_md5:0:32}" ]]
        then
            echo -e "[${subdir}/${model[0]}] \e[32mis up to date.\e[0m"
            continue
        fi
    fi

    success_flag=false
    if ! ${success_flag}; then
        if [[ $# -lt 2 ]]; then
            user=${adela_user}
            secret=${adela_secret}
        fi
        url="http://adela.sensetime.com/api/v1/models/${model[1]}?token=${user}:${secret}"
        ret=`wget ${url} -O ${subdir}/${model[0]} -nv -t 2 -q`
        if [[ $? -eq 0 ]]; then
            success_flag=true
        fi
    fi
    if ! ${success_flag}; then
        if [[ $# -lt 2 ]]; then
            user=${devcenter_user}
            secret=${devcenter_secret}
        fi
        url="http://devcenter.bj.sensetime.com/api/v1/data_models/download?api_user=${user}&api_secret=${secret}&uuid=${model[1]}&encryption=v1"
        ret=`wget ${url} -O ${subdir}/${model[0]} -nv -t 2 -q`
        if [[ $? -eq 0 ]]; then
            success_flag=true
        fi
    fi
    if ! ${success_flag}; then
        rm -f ${subdir}/${model[0]} ${oid_md5_file_path}
        echo -e "\e[31m!!!Failed to download [${subdir}/${model[0]}] with oid: ${model[1]}\e[0m"
        continue;
    fi

    if [[ -s ${subdir}/${model[0]} ]]; then
        echo ${model[1]} > ${oid_md5_file_path}
        md5=`md5sum ${subdir}/${model[0]}`
        echo ${md5:0:32} >> ${oid_md5_file_path}
        echo -e "\033[1;92m${subdir}/${model[0]} with oid ${model[1]} is downloaded successfully."
    else
        rm -f ${subdir}/${model[0]} ${oid_md5_file_path}
        echo -e "\e[31m!!!Failed to download [${subdir}/${model[0]}] with oid: ${model[1]}\e[0m"
    fi
done

rm -rf .model.tmp