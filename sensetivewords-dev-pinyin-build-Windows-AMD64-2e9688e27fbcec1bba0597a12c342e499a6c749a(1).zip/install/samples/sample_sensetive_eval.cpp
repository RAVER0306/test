﻿#include <kestrel.hh>
#include <kestrel_core.hh>
#include <iostream>
#include "timehelper.hpp"
#include "common.hpp"
using namespace Kestrel;

#define PLUGIN_NAME "sensetivewords"

int main(int argc, char **argv)
{
        std::string file_name = "positive.json";
        if (argc == 2) {
                file_name = argv[1];
        }

        std::string words = load_file(file_name);
        Kestrel::Keson::Value sensetivewords = Kestrel::Keson::Parse(words);

        Env::Init("sensetivewords");
        k_err r = License::AddFromFile("KESTREL.lic", "");
        if (r != KESTREL_OK) {
                Log(KESTREL_ERROR, "add license failed, errcode: %d\n", r);
        }

        Kestrel::Log::SetLevel(KESTREL_LL_TRACE);
        Kestrel::Plugin::Load(PLUGIN_NAME ".kep", "");
        Kestrel::Annotator annotator(
            PLUGIN_NAME,
            R"({"model":"./model/sensetivewords/KM_sensetivewords_ppl_1.0.5.tar","max_batch_size":1})");
        Kestrel::Log(KESTREL_INFO, "revision : %s\n", annotator.Revision().c_str());
        Kestrel::Log(KESTREL_INFO, " version : %s\n", annotator.Version().c_str());

        Kestrel::Keson::ValueRef words_list = sensetivewords["targets"];

        Kestrel::Keson::Value input_data{ Kestrel::Keson::ARRAY };
        if (words_list.IsValid() && words_list.IsArray() && words_list.Size() >= 1) {

                for (size_t i = 0; i < words_list.Size(); i++) {

                        Kestrel::Keson::ValueRef ele = words_list[i];
                        Kestrel::Keson::Value data = { { "content",
                                                         ele["content"].StringValue() },
                                                       { "content_id", (int)i } };
                        input_data.AppendItem(data);
                }
        }

        Kestrel::Keson::Value result;
        {
                Timehepler process("process");
                result = annotator.Process(NULL, { { "id", 0 }, { "targets", input_data } });
        }

        Kestrel::Keson::ValueRef out_list = result["targets"];

        std::cout << "number is:" << out_list.Size();

        std::ofstream ofs("outreseut.txt");
        if (!ofs.is_open()) {
                exit(-1);
        }
        ofs << result.ToString(true);
        ofs.close();
        return 1;
}
