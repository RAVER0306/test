#pragma once
#include <cmath>
#include <fstream>
#include <functional>
#include <sstream>
#include <string>

static std::string load_file(const std::string &filename)
{
        std::ifstream fin(filename);
        if (!fin.is_open()) {
                exit(-1);
        }
        return std::string{ std::istreambuf_iterator<char>(fin),
                            std::istreambuf_iterator<char>() };
}