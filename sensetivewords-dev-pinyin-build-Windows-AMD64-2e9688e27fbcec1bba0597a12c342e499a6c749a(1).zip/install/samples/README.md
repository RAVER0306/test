## Build
### On Linux
- gcc 5.5 or later is required.
- `cd samples`
- `cmake .`
- `make`

### On Macos
- apple clang 11.0 or later is required.
- `cd samples`
- `cmake .`
- `make`

### On Windows
- visual studio 2015 is required.
- `cd samples`
- `cmake -A x64 -T v140 .`
- `cmake --build . --target install --config Release`

## Get Licence
- From sensetime

## Get Model
- From sensetime

## Run sample
- ./sample_sensetivewords

## Open API Json Format
```json
{
  "model" : "model/sensetivewords/KM_sensetivewords_ppl_1.0.2.tar",
  "max_batch_size" : 1
}
```

## Process Input

```json
{
    "id": 0,
    "targets": [
        {
            "content": "XDD爱着PMM",
            "content_id": 0
        },
        {
            "content": "你TM就是个ZZ，还敢和老子抢",
            "content_id": 1
        },
        {
            "content": "尽快注销平台学生账号，以免日后影响征信",
            "content_id": 2
        }
    ]
}
```

## Process Output
```json
{
    "id": 0,
    "targets": [
        {
            "content_id": 0,
            "confidence": 1.0,
            "data": [
                {
                    "text": "XDD", "type": 1, "sub_type": 0,
                    "start": 0, "end": 2, "confidence": 1.0
                },
                {
                    "text": "PMM", "type": 1, "sub_type": 0,
                    "start": 5, "end": 7, "confidence": 1.0
                }
            ]
        },
        {
            "content_id": 1,
            "confidence": 1.0,
            "data": [
                {
                    "text": "TM", "type": 2, "sub_type": -1,
                    "start": 1, "end": 2, "confidence": 1.0
                },
                {
                    "text": "ZZ", "type": 2, "sub_type": -1,
                    "start": 6, "end": 7, "confidence": 1.0
                }
            ]
        },
        {
            "content_id": 2,
            "confidence": 1.0,
            "data": []
        }
    ]
}
```

## 修改敏感词词库
- 解压tar包，例如model/sensetivewords/KM_sensetivewords_ppl_1.0.2.tar，其中的public/sensetivewords.json文件即为词库文件，修改此文件后，重新打tar包即可，注意打包时需要在KM_sensetivewords_ppl_1.0.2根目录下打包，确保压缩包只有一级目录。