﻿#pragma once
#include <chrono>
#include <iostream>

class Timehepler
{
private:
        double start;
        double end;
        const char *time_name;

public:
        Timehepler(const char *timename)
        {
                start = std::chrono::duration_cast<std::chrono::microseconds>(
                            std::chrono::system_clock::now().time_since_epoch())
                            .count() /
                        (1000.0);
                time_name = timename;
        }
        ~Timehepler()
        {
                end = std::chrono::duration_cast<std::chrono::microseconds>(
                          std::chrono::system_clock::now().time_since_epoch())
                          .count() /
                      (1000.0);

                std::cout << time_name << " time is " << end - start << " ms" << std::endl;
        }
};
